<?php
get_instance()->gui->get_table( );
?>