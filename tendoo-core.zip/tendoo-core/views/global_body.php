<body class="login-page">
	<?php echo get_core_vars( 'body' );?>    
	<?php echo output('js');?>
</body>
</html>
<?php return; ?>
    <br>
    <footer id="footer"> 
        <div class="text-center padder clearfix"> 
            <p> 
                <small><a href="https://github.com/Blair2004/tendoo-cms"><?php echo get('core_version');?></a>
                © 2015</small> 
            </p>
        </div>
    </footer>
<body cz-shortcut-listen="true" id="backgroundLogin">
	<section class="vbox">
    	<section class="hbox stretch">
        	<section class="vbox">
		<section class="scrollable">
			<section id="content" class="wrapper-md animated fadeInUp"> 
				
				<?php echo get_core_vars( 'body' );?>
				 
			</section>
			<!-- footer -->
		</section>
        
        	</section>
        </section>
	</section>
    <?php echo output('js');?>
</body>
</html>