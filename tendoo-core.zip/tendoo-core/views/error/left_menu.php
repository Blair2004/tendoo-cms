<div id="Tendoo_admin_left_menu">
    <div class="left_menu_content">
    	<ul>
        	<li><a href="<?php echo site_url('admin/home');?>">Accueil</a></li>
            <li><a href="<?php echo site_url('admin/pages');?>">Gestion des pages</a></li>
            <li><a href="<?php echo site_url('admin/plugin');?>">Gestion des plugIn</a></li>
            <li><a href="<?php echo site_url('admin/setting');?>">Param&ecirc;tres</a></li>
            <li><a href="<?php echo site_url('index/index');?>">Retour Au site</a></li>
        </ul>
    </div>
</div>