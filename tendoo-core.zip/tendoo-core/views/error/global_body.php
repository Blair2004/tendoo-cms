<body class="login-page">
	<?php echo $body;?>    
	<?php echo output('js');?>
</body>
</html>