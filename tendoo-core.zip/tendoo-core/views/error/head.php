<div id="Tendoo_admin_header">
	<div class="logo_section">Tendoo</div>
    <div class="menu_section">
    	<ul>
        	<li><a href="<?php echo site_url('admin/index');?>">Accueil</a></li>
            <li><a href="<?php echo site_url('admin/pages');?>">Gestion des pages</a></li>
            <li><a href="<?php echo site_url('admin/plugin');?>">Gestion des plugIn</a></li>
            <li><a href="<?php echo site_url('admin/setting');?>">Param&ecirc;tres</a></li>
            <li><a href="<?php echo site_url('index/index');?>">Retour Au site</a></li>
        </ul>
    </div>
</div>