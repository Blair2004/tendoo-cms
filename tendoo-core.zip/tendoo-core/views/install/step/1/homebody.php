
					<section class="panel"> 
						<?php echo $this->load->the_view( 'install/step/step.menu.php' , true );?>
						<div class="step-content"> 
							<div class="step-pane active" id="step1">
								<div class="row">
									<div class="col-lg-4">
										<h4><i class="fa fa-group"></i><?php echo translate('Building Robust Web App');?></h4>
										<div>
											<?php echo translate('Tendoo offer you a really easy to use interface and easy to learn documentation. This cms is using almost every CodeIgniter features to work.');?>
										</div>
										
									</div>
									<div class="col-lg-4">
										<h4><i class="fa fa-mobile-phone"></i> <?php echo translate('Managing Your team Easily');?></h4>
										<div>
											<?php echo translate('Tendoo let you manage your');?>
										</div>
									</div>
									<div class="col-lg-4">
										<?php echo translate('T01');?>
									</div>
									<div class="col-lg-12">
										<hr class="line line-dashed">
										<input type="submit" class="btn btn-info" value="Continuer" style="float:right;" name="submit">
									</div>
								</div>
								
							</div> 						
						</div> 
					</section>
