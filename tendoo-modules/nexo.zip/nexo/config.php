<?php
declare_module( 'nexo' , array( 
	'name'		=>		'Next By Olivia',
	'author'			=>		'Blair Jersyer',
	'description'		=>		'...',
	'has_widget'		=>		FALSE,
	'has_api'			=>		FALSE,
	'has_icon'			=>		FALSE,
	'handle'			=>		'APP',
	'compatible'		=>		1.3,
	'version'			=>		0.1,
	'require'			=>		array( 'gui' )
) ); 

// Bon d'avoir
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'bon_davoir` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(11) NOT NULL,  
  `REF_CLIENT` int(11) NOT NULL,
  `REF_COMMAND` int(11) NOT NULL,
  `MONTANT` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

// Facture d'achat
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_input_output` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `MONTANT` int(50) NOT NULL,
  `TYPE` int(50) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL,  
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_commandes` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,
  `CODE` varchar(250) NOT NULL,
  `REF_CLIENT` int(50) NOT NULL,
  `TYPE` int(50) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AVANCE` int(50) NOT NULL,
  `PAYMENT_TYPE` int(50) NOT NULL,
  `CHARGE` int(50) NOT NULL,
  `AUTHOR` varchar(200) NOT NULL,  
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_commandes_ref_article` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `REF_COMMANDE` int(50) NOT NULL, 
  `REF_ARTICLE` int(50) NOT NULL,
  `REF_BON_DAVOIR` int(50) NOT NULL,
  `AVALABLE` int(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

// Facture d'achat
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_factures_dachats` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITLE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `REF` varchar(200) NOT NULL,
  `MONTANT` int(50) NOT NULL,
  `NATURE_SOCIALE` varchar(200) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL,  
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

// Articles tables
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_articles` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `DESIGN` varchar(200) NOT NULL,
  `PRIX_TTC` int(50) NOT NULL,
  `REF_CATEGORIE` int(50) NOT NULL,
  `REF_RAYON` int(50) NOT NULL,
  `REF_SHIPPING` int(50) NOT NULL,
  `TAILLE` int(50) NOT NULL,
  `PRIX_UNITAIRE` int(50) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `QUANTITY` int(50) NOT NULL,
  `DEFECTUEUX` int(50) NOT NULL,
  `COULEUR` varchar(200) NOT NULL,
  `AUTHOR` int(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_articles_vars` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `REF_ARTICLE` int(11) NOT NULL,
  `PRIX_DACHAT` int(50) NOT NULL,
  `FRAIS_ACCESSOIRES` int(50) NOT NULL,
  `TAUX_DE_MARGE` int(50) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(11) NOT NULL,  
  `TAUX_SOLDE` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');


// ARticles catgorie
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_categories` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL,
  `PARENT_REF_ID` int(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

// ARticles catgorie
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_articles_categories_relation` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `REF_ARTICLE` varchar(200) NOT NULL,
  `REF_CATEGORIE` int(50) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Fournisseurs table
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_fournisseurs` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(200) NOT NULL,
  `BP` text NOT NULL,
  `TEL` varchar(200) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` varchar(200) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Fournisseurs table
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_evenements` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `REF_PC` varchar(200) NOT NULL, 
  `DESIGNATION_STD` text NOT NULL,
  `VALEUR_EV` varchar(200) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Log Modification
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_historique` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DETAILS` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
//
// Gestion de la paie
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_gestion_paie` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DETAILS` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Employés
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_employes` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(200) NOT NULL, 
  `PRENOM` varchar(200) NOT NULL, 
  `EM_EMP` varchar(200) NOT NULL, 
  `MAT_EMP` varchar(200) NOT NULL, 
  `MAT_CNPS` varchar(200) NOT NULL, 
  `NAT_EMP` varchar(200) NOT NULL,
  `NE_EMP` varchar(200) NOT NULL,
  `SITAFA_EMP` varchar(200) NOT NULL, 
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Livre de paie
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_livre_de_paie` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL, 
  `REF_EMPLOYE_ID` int(50) NOT NULL,  
  `REF_ELEMENT_PAIE` int(50) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Element de paie
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_element_de_paie` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `SAL_BASE` varchar(200) NOT NULL,  
  `IN_TRANSP` varchar(200) NOT NULL,  
  `AU_PRIM` varchar(200) NOT NULL,  
  `BASE_IRPP` varchar(200) NOT NULL,  
  `BASE_CFC` varchar(200) NOT NULL,  
  `BASE_TC` varchar(200) NOT NULL,  
  `BASE_RAV` varchar(200) NOT NULL,  
  `BASE_PVI` varchar(200) NOT NULL,  
  `AS_SAL` varchar(200) NOT NULL,  
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Taux/bareme
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_taux_bareme` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `PVI` varchar(200) NOT NULL,  
  `CAC` varchar(200) NOT NULL,  
  `IRPP_RS` varchar(200) NOT NULL,  
  `TAXE_COM` varchar(200) NOT NULL,  
  `RAV_CRTV` varchar(200) NOT NULL,  
  `CFC` varchar(200) NOT NULL,  
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Bulletin de Paie
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'bulletin_de_paie` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `REF_EMPLOYE_ID` varchar(200) NOT NULL,  
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');
// Dummy table to remove later
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'dummy` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `REF_EMPLOYE_ID` varchar(200) NOT NULL,  
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

// Arrivage
push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_arrivages` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL, 
  `FOURNISSEUR_REF_ID` int(50) NOT NULL, 
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_rayons` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL, 
  `DESCRIPTION` varchar(200) NOT NULL,   
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL, 
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

push_module_sql( 'nexo' , 	'CREATE TABLE IF NOT EXISTS `'.DB_ROOT.'nexo_code_barre` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `CODE` text NOT NULL,   
  `FILE_PATH` text NOT NULL,
  `REF_ARTICLE` int(50) NOT NULL,
  `AUTHOR` int(50) NOT NULL, 
  `DATE_CREATION` datetime NOT NULL, 
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;');

push_module_action( 'nexo' , array(
	'action'				=>	'commandes',
	'action_name'			=>	__( 'Gestion des commandes' ),
	'action_description'	=>	__( 'Cette permission vous permet de vendre des produits.' ),
));

push_module_action( 'nexo' , array(
	'action'				=>	'gestion_client',
	'action_name'			=>	__( 'Gestion Clients' ),
	'action_description'	=>	__( 'Cette permission vous permet de supprimer des produits.' ),
));

push_module_action( 'nexo' , array(
	'action'				=>	'compta_gestion',
	'action_name'			=>	__( 'Compabilité & Fiscalité' ),
	'action_description'	=>	__( 'Cette permission vous permet de superviser les résultats.' ),
));

push_module_action( 'nexo' , array(
	'action'				=>	'gestion_commerciale',
	'action_name'			=>	__( 'Gestion Commerciale' ),
	'action_description'	=>	__( 'Cette action donne droit au différent actions sur la gestion commerciale.' ),
));

push_module_action( 'nexo' , array(
	'action'				=>	'gestion_des_factures',
	'action_name'			=>	__( 'Gestion des Factures d\'achats' ),
	'action_description'	=>	__( 'Cette action donne droit au différent actions sur la gestion commerciale.' ),
));

push_module_action( 'nexo' , array(
	'action'				=>	'manage_shipping_and_articles',
	'action_name'			=>	__( 'Gestion des arrivages & des articles' ),
	'action_description'	=>	__( 'Cette action vous donne accès aux différents arrivages & articles.' ),
));

push_module_action( 'nexo' , array(
	'action'				=>	'access_report',
	'action_name'			=>	__( 'Accéder aux rapports de la boutique' ),
	'action_description'	=>	__( 'Cette action vous permet d\'accerder aux rapports d\'activité.' ),
));