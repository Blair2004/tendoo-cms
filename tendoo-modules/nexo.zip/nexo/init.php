<?php
class nexo_init_class
{
	function __construct(){
		
		bind_filter( 'user_form_fields' , array( $this , 'user_fields' ) );
		// Nom_emp
		foreach( array( 
		'client_name' , 'client_bp' , 'num_cli' , 'client_tel' , 'client_email' , 'lieu_de_travail_client' , 'domicile_client' , 'preference_client' , 'preference_vestimentaire_client' , 'alert_pub' , 'mode' , 'tt_command_count' , // tt_command_count compte le nbr de commande effectuer par un client avant d'effectuer uen RRR
		
		'nom_emp' , 'prenom_emp' , 'mat_emp' , 'mat_cnps' , 'nat_emp' , 'sifa_emp' , 'ne_emp' ) as $field ){
			register_fields( 'user_form_fields' , array(
				'name'		=>	$field,
				'purify'	=>	function( $input ){
					return $input;
				} ) 
			);
		}
		
		$this->notices();
		
		if( is_admin() )
		{	
			$this->salaire_personnel		=		new PostType( array(
				'namespace'					=>		'posts',
				'label'						=>		__( 'Salaire Personnel' )
			) );
			
			$this->salaire_personnel->define_taxonomy( 'category' , __( 'Catégorie' ) , array(
				'is_hierarchical'			=>		true
			) );
					
			$this->salaire_personnel->run();
			
			// Operator Working space
			if( current_user()->can( 'nexo@commandes' ) ){
				/**
				 * Sub privileges : edit_commands, delete_commands
				**/
				create_admin_menu( 'nexo_vente' , 'after' , 'dashboard' );
				add_admin_menu( 'nexo_vente' , array(
					'title'	=>	__( 'Caisse' ), 
					'href'	=>	'#',
					'is_submenu'	=>	false,
					'icon'	=>	'fa fa-calculator'
				) );
				add_admin_menu( 'nexo_vente' ,array(
					'title'	=>	__( 'Nouvelle commande' ), 
					'href'	=>	module_url( array( 'commands' , 'new' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo_vente' , array(
					'title'	=>	__( 'Historique des commandes' ), 
					'href'	=>	module_url( array( 'commands' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo_vente' ,array(
					'title'	=>	__( 'Liste des bons d\'avoir' ), 
					'href'	=>	module_url( array( 'bondavoir' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo_vente' ,array(
					'title'	=>	__( 'Créer un nouveau bon d\'avoir' ), 
					'href'	=>	module_url( array( 'bondavoir' , 'new' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo_vente' ,array(
					'title'	=>	__( 'Nouvelle entrée extraordinaire' ), 
					'href'	=>	module_url( array( 'flux' , 'input' , 'new' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo_vente' ,array(
					'title'	=>	__( 'Entrées extraordinaires' ), 
					'href'	=>	module_url( array( 'flux' , 'input' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo_vente' ,array(
					'title'	=>	__( 'Nouvelle sortie extraordinaire' ), 
					'href'	=>	module_url( array( 'flux' , 'output' , 'new' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo_vente' ,array(
					'title'	=>	__( 'Sorties extraordinaires' ), 
					'href'	=>	module_url( array( 'flux' , 'output' ) , 'nexo' )
				) );
			}
			// Gestion des clients
			if( current_user()->can( 'nexo@gestion_client' ) ){
				create_admin_menu( 'gestion_client' , 'after' , 'dashboard' );
				add_admin_menu( 'gestion_client' , array(
					'title'	=>	__( 'Clients' ), 
					'href'	=>	'#',
					'icon'	=>	'fa fa-user',
					'is_submenu'	=>	false
				) );	
				add_admin_menu( 'gestion_client' , array(
					'title'	=>	__( 'Liste des clients' ), 
					'href'	=>	module_url( array( 'clients' ) , 'nexo' )
				) );			
				add_admin_menu( 'gestion_client' , array(
					'title'	=>	__( 'Ajouter client' ), 
					'href'	=>	module_url( array( 'clients' , 'new' ) , 'nexo' )
				) );
				add_admin_menu( 'gestion_client' , array(
					'title'	=>	__( 'Campagne Publicitaires' ), 
					'href'	=>	module_url( array( 'ads' ) , 'nexo' )
				) );
				add_admin_menu( 'gestion_client' , array(
					'title'	=>	__( 'Nouvelle campagne publicitaire' ), 
					'href'	=>	module_url( array( 'ads' , 'new' ) , 'nexo' )
				) );
			}
			if( current_user()->can( 'nexo@manage_shipping_and_articles' ) ){
				create_admin_menu( 'manage_shipping_and_articles' , 'after' , 'dashboard' );
				// Livraison
				
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Arrivages' ), 
					'href'	=>	'#',
					'is_submenu'	=>	false,
					'icon'	=>	'fa fa-archive'
				) );
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Historique des arrivages' ), 
					'href'	=>	module_url( array( 'shipping' ) , 'nexo' )
				) );		
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Nouvel arrivage' ), 
					'href'	=>	module_url( array( 'shipping' , 'new' ) , 'nexo' )
				) );
				// Liste des produits
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Liste des articles' ), 
					'href'	=>	module_url( array( 'articles' ) , 'nexo' )
				) );
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Ajouter un nouvel article' ), 
					'href'	=>	module_url( array( 'articles' , 'new' ) , 'nexo' )
				) );
				// Rayonnage
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Liste des rayons' ), 
					'href'	=>	module_url( array( 'rayons' ) , 'nexo' )
				) );
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Ajouter un nouveau rayon' ), 
					'href'	=>	module_url( array( 'rayons' , 'new' ) , 'nexo' )
				) );
				// Catégorie Produit
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Liste des catégories des articles' ), 
					'href'	=>	module_url( array( 'category' ) , 'nexo' )
				) );
				add_admin_menu( 'manage_shipping_and_articles' , array(
					'title'	=>	__( 'Ajouter une nouvelle catégorie' ), 
					'href'	=>	module_url( array( 'category' , 'new' ) , 'nexo' )
				) );
			}
			// Gestion Commerciale
			if( current_user()->can( 'nexo@gestion_commerciale' ) ){
				create_admin_menu( 'nexo_commercial' , 'after' , 'dashboard' );
				add_admin_menu( 'nexo_commercial' , array(
					'title'	=>	__( 'Remunération' ), 
					'href'	=>	'#',
					'is_submenu'	=>	false,
					'icon'	=>	'fa fa-credit-card'
				) );				
				//
				add_admin_menu( 'nexo_commercial' , array(
					'title'	=>	__( 'Historique de la rémunération du personnel' ), 
					'href'	=>	module_url( array( 'remuneration_personnel' ) , 'nexo' )
				) );				
				add_admin_menu( 'nexo_commercial' , array(
					'title'	=>	__( 'Rémunération du personnel' ), 
					'href'	=>	module_url( array( 'remuneration_personnel' , 'new' ) , 'nexo' )
				) );
				
			}
			if( current_user()->can( 'nexo@access_report' ) ){
				
				create_admin_menu( 'nexo@access_report' , 'after' , 'dashboard' );
				add_admin_menu( 'nexo@access_report' , array(
					'title'	=>	__( 'Rapports' ), 
					'href'	=>	'#',
					'is_submenu'	=>	false,
					'icon'	=>	'fa fa-area-chart'
				) );
				
				add_admin_menu( 'nexo@access_report' , array(
					'title'	=>	__( 'Rapports Journalier' ), 
					'href'	=>	module_url( array( 'reports' , 'daily' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo@access_report' , array(
					'title'	=>	__( 'Fiche de référence des PPA' ), 
					'href'	=>	module_url( array( 'reports' , 'ppa' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo@access_report' , array(
					'title'	=>	__( 'Rendement Mensuel' ), 
					'href'	=>	module_url( array( 'reports' , 'monthly' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo@access_report' , array(
					'title'	=>	__( 'Recap. Caisse Annuel' ), 
					'href'	=>	module_url( array( 'reports' , 'annuel' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo@access_report' , array(
					'title'	=>	__( 'Statistiques des ventes' ), 
					'href'	=>	module_url( array( 'reports' , 'statistiques-ventes' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo@access_report' , array(
					'title'	=>	__( 'Fiche de suivi de stocks Générale' ), 
					'href'	=>	module_url( array( 'update' ) , 'nexo' )
				) );
			}
			if( current_user()->can( 'nexo@gestion_des_factures' ) ){
				
				create_admin_menu( 'nexo_buying_bills' , 'after' , 'dashboard' );
				// Factures d'achats
				
				add_admin_menu( 'nexo_buying_bills' , array(
					'title'	=>	__( 'Factures' ), 
					'href'	=>	'#',
					'is_submenu'	=>	false
				) );
				add_admin_menu( 'nexo_buying_bills' , array(
					'title'	=>	__( 'Historiques des factures d\'achats' ), 
					'href'	=>	module_url( array( 'buying_bill' ) , 'nexo' )
				) );
				add_admin_menu( 'nexo_buying_bills' , array(
					'title'	=>	__( 'Nouvelle facture d\'achat' ), 
					'href'	=>	module_url( array( 'buying_bill' , 'new' ) , 'nexo' )
				) );
			}
			// Compatibilité et Fiscalité
			if( current_user()->can( 'nexo@compta_gestion' ) ){
				create_admin_menu( 'compta_gestion' , 'after' , 'dashboard' );
				add_admin_menu( 'compta_gestion' , array(
					'title'	=>	__( 'Comptabilité' ), 
					'href'	=>	'#',
					'is_submenu'	=>	false,
					'icon'	=>	'fa fa-suitcase'
				) );				
				add_admin_menu( 'compta_gestion' , array(
					'title'	=>	__( 'Livre journal des ventes' ), 
					'href'	=>	module_url( array( 'compta' , 'daily-selling-book' ) , 'nexo' )
				) );
				add_admin_menu( 'compta_gestion' , array(
					'title'	=>	__( 'Liste des pièces comptables' ), 
					'href'	=>	module_url( array( 'compta' , 'pieces' ) , 'nexo' )
				) );
				add_admin_menu( 'compta_gestion' , array(
					'title'	=>	__( 'Etat périodique' ), 
					'href'	=>	module_url( array( 'compta' , 'state' ) , 'nexo' )
				) );
				add_admin_menu( 'compta_gestion' , array(
					'title'	=>	__( 'Impôts payées' ), 
					'href'	=>	module_url( array( 'compta' , 'impot' , 'list' ) , 'nexo' )
				) );
				add_admin_menu( 'compta_gestion' , array(
					'title'	=>	__( 'Paiement des Impôts' ), 
					'href'	=>	module_url( array( 'compta' , 'impot' , 'payment' ) , 'nexo' )
				) );				
			}
			if( current_user()->can( 'nexo@gestion_fournisseurs' ) ){
				create_admin_menu( 'nexo_fournisseurs' , 'after' , 'dashboard' );
				add_admin_menu( 'nexo_fournisseurs' , array(
					'title'	=>	__( 'Fournisseurs' ), 
					'href'	=>	module_url( array( 'providers' ) , 'nexo' ),
					'icon'	=>	'fa fa-shopping-cart'
				) );				
				add_admin_menu( 'nexo_fournisseurs' , array(
					'title'	=>	__( 'Ajouter un fournisseur' ), 
					'href'	=>	module_url( array( 'providers' , 'new' ) , 'nexo' )
				) );
			}
			// Regalges
			if( current_user()->can( 'nexo@reglages' ) ){
				create_admin_menu( 'nexo_reglages' , 'after' , 'dashboard' );
				add_admin_menu( 'nexo_reglages' , array(
					'title'	=>	__( 'Nexo Reglages' ), 
					'href'	=>	module_url( array( 'settings' ) , 'nexo' ),
					'icon'	=>	'fa fa-gear'
				) );				
			}
			
			$this->create_admin_widget();
		}
	}
	function user_fields( $fields , $user_id = NULL )
	{
		$user				=	get_user( $user_id , 'as_id' );
		// Nom
		$fields[]			=	array(
			'name'			=>	'nom_emp',
			'placeholder'	=>	__( 'Nom Employé' ),
			'label'			=>	__( 'Nom Employé' ),
			'type'			=>	'text',
			'description'	=>	__( 'Entrez le nom' ),
			'value'			=>	get_instance()->meta_datas->get_user_meta( 'nom_emp' , riake( 'PSEUDO' , $user ) )
		);
		// Prénom employé
		$fields[]			=	array(
			'name'			=>	'prenom_emp',
			'placeholder'	=>	__( 'Prénom Employé' ),
			'label'			=>	__( 'Prénom Employé' ),
			'type'			=>	'text',
			'description'	=>	__( 'Entrez le prénom' ),
			'value'			=>	get_instance()->meta_datas->get_user_meta( 'prenom_emp' , riake( 'PSEUDO' , $user ) )
		);
		// Matricule employé
		$fields[]			=	array(
			'name'			=>	'mat_emp',
			'placeholder'	=>	__( 'Matricule Employé' ),
			'label'			=>	__( 'Matricule Employé' ),
			'type'			=>	'text',
			'description'	=>	__( 'Entrez le Matricule' ),
			'value'			=>	get_instance()->meta_datas->get_user_meta( 'mat_emp' , riake( 'PSEUDO' , $user ) )
		);
		
		// Matricule CNPS employé
		$fields[]			=	array(
			'name'			=>	'mat_cnps',
			'placeholder'	=>	__( 'Matricule CNPS Employé' ),
			'label'			=>	__( 'Matricule CNPS Employé' ),
			'type'			=>	'text',
			'description'	=>	__( 'Entrez le Matricule CNPS' ),
			'value'			=>	get_instance()->meta_datas->get_user_meta( 'mat_cnps' , riake( 'PSEUDO' , $user ) )
		);
		
		// Nationalité employé
		$fields[]			=	array(
			'name'			=>	'nat_emp',
			'placeholder'	=>	__( 'Nationalité Employé' ),
			'label'			=>	__( 'Nationalité Employé' ),
			'type'			=>	'text',
			'description'	=>	__( 'Enregistrer une nationalité pour l\'employé' ),
			'value'			=>	get_instance()->meta_datas->get_user_meta( 'nat_emp' , riake( 'PSEUDO' , $user ) )
		);
		
		// Situation Familiale
		$fields[]			=	array(
			'name'			=>	'sifa_emp',
			'placeholder'	=>	__( 'Situation Familiale' ),
			'label'			=>	__( 'Situation Familiale' ),
			'type'			=>	'select',
			'value'			=>	array( 'married' , 'single' , 'widower' ),
			'text'			=>	array( __( 'Marié' ) , __( 'Celibataire' ) , __( 'Veuf(ve)' ) ),
			'description'	=>	__( 'Définir la situation familiale de l\'employé' ),
			'active'		=>	get_instance()->meta_datas->get_user_meta( 'sifa_emp' , riake( 'PSEUDO' , $user ) )
		);
		
		for( $i = 0 ; $i < 100 ; $i++ ){
			$custom_keys	[]	=	$i;
			if( $i < 2 ){
				$custom_value	[]	=	$i . ' enfant';
			} else {
				$custom_value	[]	=	$i . ' enfants';
			}
		}
		// Nombre d'enfant
		$fields[]			=	array(
			'name'			=>	'ne_emp',
			'placeholder'	=>	__( 'Choisir un chiffre' ),
			'label'			=>	__( 'Nombre d\'enfants' ),
			'type'			=>	'select',
			'value'			=>	$custom_keys,
			'text'			=>	$custom_value,
			'description'	=>	__( 'Choisir le nombre d\'enfants de l\'employé.' ),
			'active'		=>	get_instance()->meta_datas->get_user_meta( 'ne_emp' , riake( 'PSEUDO' , $user ) )
		);
		
		return $fields;
	}
	function create_admin_widget()
	{
		declare_admin_widget( array(
			'widget_namespace'		=>	'nexo_stats',
			'module_namespace'		=>	'nexo',
			'widget_title'			=>	__( 'Etat de la boutique' ),
			'widget_description'	=>	__( 'Vous permet d\avoir une vue d\'ensemble sur la boutique' ),
			'widget_content'		=>	module_view( 'views/widgets/stats' , true , 'nexo' )
		) );
		declare_admin_widget( array(
			'widget_namespace'		=>	'nexo_cash',
			'module_namespace'		=>	'nexo',
			'widget_title'			=>	__( 'Cash' ),
			'widget_description'	=>	__( 'Vous permet de voir le solde de la caise' ),
			'widget_content'		=>	module_view( 'views/widgets/cash' , true , 'nexo' )
		) );
	}
	function notices()
	{
		declare_notice( 'quantity-error' , tendoo_error( 'Le nombre de produit défectueux ne peux pas être supérieur à la quantité totale des produits' ) );
		declare_notice( 'error-occured' , tendoo_error( 'Une erreur s\'est produit durant l\'opération' ) );
		// Bon d'avoir
		declare_notice( 'bondav-already-exists-for-this-command' , tendoo_error( 'Un bon d\'avoir existe déjà pour cette commande' ) );
		declare_notice( 'unknow-bon-davoir' , tendoo_error( 'Bon d\'avoir introuvable.' ) );
		declare_notice( 'bon-davoir-deleted' , tendoo_success( 'Le bon d\'avoir a correctement été supprimé. La commande à retrouvé ses produits.' ) );
		declare_notice( 'bondav-set' , tendoo_success( 'Le bon d\'avoir a correctement été défini. Les produits de la commande concernée ont été remis en stock.' ) ); 
		// Flux
		declare_notice( 'unknow-flux' , tendoo_error ( 'Flux introuvable ou incorrect.' ) );
		declare_notice( 'flux-already-exists' , tendoo_error( 'Un entrée similaire existe déjà' ) );
		declare_notice( 'flux-deleted' , tendoo_success( 'Le flux a correctement été supprimé.' ) );
		declare_notice( 'flux-successfully-set' , tendoo_success( 'Le flux a correctement été défini.' ) );
		// Commands
		declare_notice( 'command-deleted' , tendoo_success( 'La commande a correctement été supprimée' ) );
		declare_notice( 'unknow-command' , tendoo_error( 'Commande introuvable.' ) );
		// Product
		declare_notice( 'require-product' , tendoo_error( 'Vous devez nécessairement ajouter un produit pour enregistrer une commande' ) );
		declare_notice( 'commands-successfully-done' , tendoo_success( 'La commande a correctement été enregistrée/modifiée' ) );
		// Clients
		declare_notice( 'client-deleted' , tendoo_success( 'Le client a correctement été supprimé.' ) );
		declare_notice( 'set-role-id-first' , tendoo_error( 'Vous devez choisir le rôle qui servira de client avant de créer un client.' ) );
		declare_notice( 'cannot-delete-unclient' , tendoo_error( 'Vous ne pouvez pas supprimer un utilisateur qui n\'est pas client.' ) );
		// Bills
		declare_notice( 'unknow-bill' , tendoo_error( 'Facture d\'achat introuvable' ) );
		declare_notice( 'bill-deleted' , tendoo_success( 'La facture d\'achat a correctement été supprimée' ) );
		declare_notice( 'bill-already-exists' , tendoo_error( 'La facture d\'achat existe déjà. S\'il vous plait veuillez choisir un titre unique' ) );
		declare_notice( 'bill-set' , tendoo_success( 'La facture a correctement été créée/modifiée.' ) );
		declare_notice( 'not-enough-cash' , tendoo_error( 'Impossible d\'enregistrer la facture. Il n\'y a pas assez de fond pour autoriser l\'enregistrement.' ) );
		// Code bar
		declare_notice( 'code-bar-creation-failed' , tendoo_error( 'La création du code barre à échoué' ) );
		// Category
		declare_notice( 'categoy-name-already-taken' , tendoo_error( 'Le nom de cette catégorie est déjà utilisé, veuillez en choisir un autre, ou ajouter un signe distinctif.' ) );
		declare_notice( 'category-updated' , tendoo_success( 'La catégorie a correctement été mise à jour.' ) );
		declare_notice( 'category-created' , tendoo_success( 'La catégorie a correctement été créée.' ) );
		declare_notice( 'parent-category-unknow' , tendoo_error( 'Entité parente introuvable' ) );
		declare_notice( 'hierarchy-error' , tendoo_error( 'Une erreur s\'est produit, une catégorie ne peut pas être son propre parent.' ) );
		// Produits
		declare_notice( 'stock-added' , tendoo_success( 'Le stock a correctement été approvisionné.' ) );
		declare_notice( 'stock-updated' , tendoo_success( 'Le stock a correctement été modifié.' ) );
		declare_notice( 'update-stock' , tendoo_info( 'Si votre modification n\'affecte pas l\'arrivage, la modification de la quantité ne sera pas considérée comme un approvisionnement du stock.' ) );
		declare_notice( 'product-exists' , tendoo_error( 'Impossible de créer le produit, le nom de ce dernier est déjà utilisé par un autre.' ) );
		declare_notice( 'product-has-been-created' , tendoo_success( 'Le produit a correctement été crée' ) );
		declare_notice( 'unknow-product' , tendoo_error( 'Impossible d\'accéder au produit.' ) );
		declare_notice( 'product-deleted' , tendoo_success( 'Le produit a correctement été supprimé.' ) );
		declare_notice( 'product-code-refreshed' , tendoo_success( 'Les codebarres des produits ont été reinitialisés.' ) );
		declare_notice( 'only-array-is-supported' , tendoo_error( 'Une erreur s\'est produite durant la regénération des codes barres.' ) );
		// Rayon
		declare_notice( 'rayon-has-been-deleted' , tendoo_success( 'Le rayon a correctement été supprimé.' ) );		
		declare_notice( 'rayon-has-been-created' , tendoo_success( 'Le rayon a correctement été crée.' ) );
		declare_notice( 'unable-to-create-or-edit-rayon' , tendoo_error( 'Impossible de créer ou de modifier le rayon.' ) );		
		declare_notice( 'unable-to-find-meta-data' , tendoo_error( 'Impossible de trouver une information nécessaire à l\'opération.' ) );
		declare_notice( 'unknow-rayon' , tendoo_error( 'Rayon indisponible ou introuvable.' ) );
		declare_notice( 'numeric-value-required' , tendoo_error( 'Une valeur numérique requise n\'a pas été effectivement publiée.' ) );		
		// Fournisseurs
		declare_notice( 'provider-updated' , tendoo_success( 'Le Fournisseur a correctement été mis à jour.' ) );	
		declare_notice( 'provider-created' , tendoo_success( 'Le Fournisseur a correctement été créé.' ) );
		declare_notice( 'provider-already-exists' , tendoo_error( 'Une fournisseur ayant le même nom existe déjà. Veuillez spécifier un autre nom.' ) );
		declare_notice( 'unknow-provider' , tendoo_error( 'Fournisseur introuvable.' ) );
		declare_notice( 'provider-deleted' , tendoo_success( 'Le fournisseur a correctement été supprimé.' ) );
		// Livraison		
		declare_notice( 'shipping-already-exists-or-unknow-provider' , tendoo_error( 'Nom d\'arrivage déjà occupé ou fournisseur introuvable.' ) );		
		declare_notice( 'shipping-created' , tendoo_success( 'L\'arrivage a correctement été créée.' ) );
		declare_notice( 'shipping-updated' , tendoo_success( 'L\'arrivage a correctement été modifiée.' ) );
		declare_notice( 'shipping-deleted' , tendoo_success( 'L\'arrivage a correctement été supprimée.' ) );
		declare_notice( 'unknow-shipping' , tendoo_error( 'L\'arrivage a introuvable.' ) );
		declare_notice( 'underupdate' , tendoo_info( 'Cette page est en cours de maintenance.' ) );
	}
}