<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<title>Fiche de suivi de stock</title>
</head>
<?php
$format				=	'A5';
if( $format == 'A5' )
{
	$width	=	792;
	$height	=	560;
	$css	=	'font-size:80% !important;';
}
?>
<body>
    <div class="container" style="width:<?php echo $width;?>px;height:<?php echo $height;?>px;<?php echo $css;?>">
    <div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3>FICHE DE SUIVI DE STOCK POUR L'ARRIVAGE : <?php echo riake( 'TITRE' , $shipping );?></h3>
            </div>
            <hr style="margin:0 1%;">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <td><strong>DATES</strong></td>
                            <td class="text-center"><strong>CATEGORIES</strong></td>
                            <td colspan="2" class="text-center"><strong>STOCK INITIAL</strong></td>
                            <td colspan="2" class="text-center"><strong>ENTREES (ACHAT)</strong></td>
                            <td colspan="2" class="text-center"><strong>SORTIES (VENTES)</strong></td>
                            <td colspan="2" class="text-right"><strong>STOCK FINAL</strong></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td class="text-center"></td>
                            <td class="text-center"><strong>QTE</strong></td>
                            <td class="text-center"><strong>MONTANT</strong></td>
                            <td class="text-center"><strong>QTE</strong></td>
                            <td class="text-center"><strong>MONTANT</strong></td>
                            <td class="text-center"><strong>QTE</strong></td>
                            <td class="text-center"><strong>MONTANT</strong></td>
                            <td class="text-center"><strong>QTE</strong></td>
                            <td class="text-center"><strong>MONTANT</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
					
					/**
					$product_hidden		=	$lib->get_product( array(
						'shipping_id'	=>	riake( 'ID' , $shipping ),
						'category_id'	=>	riake( 'ID' , $_category )
					), 'as_category_different_and_shipping' );
					
					print_array( $product_hidden );
					**/	
					$total_collection_stock		=	0;
					$total_collection_entree	=	0;
					$total_collection_sortie	=	0;
					
					$total_montant_stock		=	0;
					$total_montant_entree		=	0;
					$total_montant_sortie		=	0;
					
					foreach( force_array( $latest_categories ) as $_category )
					{
						$products_before	=	$lib->get_product( array(
							'shipping_id'	=>	riake( 'ID' , $shipping ), 
							'category_id'	=>	riake( 'ID' , $_category )
						) , 'as_category_and_before_shipping' );
						$quantity			=	0;
						$montant			=	0;
						foreach( $products_before as $__product )
						{
							$quantity		+=	( ( int ) riake( 'QUANTITY' , $__product , 0 ) - ( int ) riake( 'DEFECTUEUX' , $__product , 0 ) );
							$count_dachat	=	( 
								( int ) riake( 'PRIX_DACHAT' , $__product , 0 ) + ( int ) riake( 'FRAIS_ACCESSOIRES' , $__product , 0 ) 
							);
							$pdVu			=	$count_dachat * ( float ) riake( 'TAUX_DE_MARGE' , $__product , 0 );
							$pdVg			=	$pdVu	* ( ( int ) riake( 'QUANTITY' , $__product , 0 ) - ( int ) riake( 'DEFECTUEUX' , $__product , 0 ) );							
							$montant		+=	$pdVg;
						}
						// Récupération Stock Actuel
						$quantity_now		=	0;
						$montant_now		=	0;
						$quantity_sold		=	0;
						$montant_sold		=	0;
						
						$product_now		=	$lib->get_product( array(
							'shipping_id'	=>	riake( 'ID' , $shipping ),
							'category_id'	=>	riake( 'ID' , $_category )
						), 'as_category_and_shipping' );						
						
						foreach( $product_now as $__product_now )
						{
							// Récupération Stock Actuel
							$quantity_now		+=	( ( riake( 'QUANTITY' , $__product_now , 0 ) - riake( 'DEFECTUEUX' , $__product_now , 0 ) ) );
							$count_dachat	=	( 
								( int ) riake( 'PRIX_DACHAT' , $__product_now , 0 ) + ( int ) riake( 'FRAIS_ACCESSOIRES' , $__product_now , 0 ) 
							);
							$_pdVu			=	$count_dachat * ( float ) riake( 'TAUX_DE_MARGE' , $__product_now , 0 );
							$_pdVg			=	$_pdVu	* ( ( int ) riake( 'QUANTITY' , $__product_now , 0 ) - ( int ) riake( 'DEFECTUEUX' , $__product_now , 0 ) );							
							$montant_now	+=	$_pdVg;
							// Récupération Stock Vendu
							// var_dump( $__product_now );
							$product_iCo	=	$lib->get_products_in_commands( riake( 'REF_RELATION' , $__product_now ) , true , 'as_relation' );
							$_pQv			=	count( $product_iCo ); // Produit Quantité Vendue
							$_pMtotal		=	0; // Produit Montant Total
							foreach( $product_iCo as $_produit )
							{
								$_pMtotal			+=	$lib->get_product_selling_price( riake( 'REF_ARTICLE' , $_produit ) );
							}
							$quantity_sold	+=	$_pQv;
							$montant_sold	+=	$_pMtotal;
							
						}
						
						// Stock Final
						$quantity_final		=	( $quantity	+ $quantity_now ) - $quantity_sold;
						$montant_final		=	( $montant + $montant_now ) - $montant_sold;
						
						
					?>
                        <tr>
                            <td></td>
                            <td class="text-center"><?php echo riake( 'NOM' , $_category );?></td>
                            <td class="text-center"><?php echo $quantity;?></td>
                            <td class="text-center"><?php echo $montant;?></td>
                            <td class="text-center"><?php echo $quantity_now;?></td>
                            <td class="text-center"><?php echo $montant_now;?></td>                            
                            <td class="text-center"><?php echo $quantity_sold;?></td>
                            <td class="text-center"><?php echo $montant_sold;?></td>
                            <td class="text-center"><?php echo $quantity_final;?></td>
                            <td class="text-center"><?php echo $montant_final;?></td>
                        </tr>
					<?php
						$total_collection_stock		+=	$quantity;
						$total_collection_entree	+=	$quantity_now;
						$total_collection_sortie	+=	$quantity_sold;
						
						$total_montant_stock		+=	$montant;
						$total_montant_entree		+=	$montant_now;
						$total_montant_sortie		+=	$montant_sold;
					}
					
					$total_collection_final		=	( $total_collection_stock + $total_collection_entree ) - $total_collection_sortie;
					$total_montant_final		=	( $total_montant_stock + $total_montant_entree ) - $total_montant_sortie;
					?>
                        <tr>
                            <td class="text-center" colspan="2">Total Collection</td>
                            <td class="text-center"><?php echo $total_collection_stock;?></td>
                            <td class="text-center"><?php echo $total_montant_stock;?></td>
                            
                            <td class="text-center"><?php echo $total_collection_entree;?></td>
                            <td class="text-center"><?php echo $total_montant_entree;?></td>
                            
                            <td class="text-center"><?php echo $total_collection_sortie;?></td>
                            <td  class="text-center"><?php echo $total_montant_sortie;?></td>
                            
                            <td class="text-center"><?php echo $total_collection_final;?></td>
                            <td class="text-center"><?php echo $total_montant_final;?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>
    </div>
</div>
<style type="text/css">
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>
