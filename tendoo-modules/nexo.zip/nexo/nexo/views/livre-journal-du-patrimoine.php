<?php
$prefs	=	array (
   'show_next_prev'  => TRUE,
   'next_prev_url'   => module_url( array( 'reports' , 'daily' ) , 'nexo' )
 );
 $prefs['template'] = '

   {table_open}<table border="0" cellpadding="0" cellspacing="0" class="table table-bordered">{/table_open}

   {heading_row_start}<tr>{/heading_row_start}

   {heading_previous_cell}<th><a href="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
   {heading_title_cell}<th colspan="{colspan}">{heading}</th>{/heading_title_cell}
   {heading_next_cell}<th><a href="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}

   {heading_row_end}</tr>{/heading_row_end}

   {week_row_start}<tr>{/week_row_start}
   {week_day_cell}<td class="text-right">{week_day}</td>{/week_day_cell}
   {week_row_end}</tr>{/week_row_end}

   {cal_row_start}<tr>{/cal_row_start}
   {cal_cell_start}<td class="text-right">{/cal_cell_start}

   {cal_cell_content}<a href="{content}">{day}</a>{/cal_cell_content}
   {cal_cell_content_today}<div class="highlight"><a href="{content}">{day}</a></div>{/cal_cell_content_today}

   {cal_cell_no_content}{day}{/cal_cell_no_content}
   {cal_cell_no_content_today}<div class="highlight">{day}</div>{/cal_cell_no_content_today}

   {cal_cell_blank}&nbsp;{/cal_cell_blank}

   {cal_cell_end}</td>{/cal_cell_end}
   {cal_row_end}</tr>{/cal_row_end}

   {table_close}</table>{/table_close}
';
get_instance()->load->library( 'calendar' , $prefs );
$date		=	get_instance()->date->time( '' , true );
$date_now	=	get_instance()->date->datetime();
$YEAR		=	( $YEAR  === 'DEFAULT' ) ? riake( 'y' , $date ) : $YEAR;
$MONTH		=	( $MONTH  === 'DEFAULT' ) ? riake( 'm' , $date ) : $MONTH;
$DAY		=	( $DAY	=== 'DEFAULT' ) ? unsinglerize( riake( 'd' , $date ) ) : $DAY;

$timestamp	=	strtotime( $YEAR .'-' . $MONTH . '-01' ) ;
$NBR_DAYS	=	cal_days_in_month( CAL_GREGORIAN , $MONTH , $YEAR );
$date_start	=	date( 'Y-m-' , $timestamp ) . $DAY . ' 00:00:00';
$date_end	=	date( 'Y-m-' , $timestamp ) . $DAY . ' 23:59:59';

$final_array				=	array();
		
for( $i = 0 ; $i<= $NBR_DAYS ; $i++ )
{
	$final_array[]			=	module_url( array( 'compta' , 'daily-selling-book' , $YEAR , $MONTH , unsinglerize( $i ) ) , 'nexo' );
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<title><?php echo get_page( 'title' );;?></title>
</head>
<body>
    <div class="container" style="width:60%; min-height:1170px;">
    <div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3><?php echo get_page( 'title' );;?></h3>
            </div>
            <hr style="margin:0 1%;">
        </div>
    </div>
    <?php
	$months		=	array( 'Janvier' , 'Février' , 'Mars' , 'Avril' , 'Mai' , 'Juin' , 'Juillet' , 'Aout' , 'Septembre' , 'Octobre' , 'Novembre' , 'Decembre' );
	?>
    <div class="row">
    	<div class="col-lg-6 col-lg-offset-3 noPrint">
        	<?php		
				// echo get_instance()->calendar->generate( $YEAR , $MONTH , $final_array );
			?>
            <form method="post">
            	<h4>Actif Immobilisé (AI)</h4>
				<div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Charges Immobilisées</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ai][chargeimmobil]" value="">
                </div>
           		<div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Bâtiments, Installation</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ai][batiinstall]" value="">
                </div>
           		<div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Materiels</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ai][materiel]" value="">
                </div>
                
                
                <h4>Actif Circulant (AC)</h4>
				<div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Stocks Marchandises</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ac][stockmarcha]" value="">
                </div>
                <div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Stocks de matière et Approv</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ac][stockmatetapprov]" value="">
                </div>
                <div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Créances Fournisseurs</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ac][creancefourniss]" value="">
                </div>
                <div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Créances Clients (Bon Avoir)</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ac][creanceclientbonavoir]" value="">
                </div>	
                
                <h4>Trésorerie-Actif (TA)</h4>
				<div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Compte Bancaire</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ta][comptbanc]" value="">
                </div>
                <div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Caisse</span>
                  <input type="text" class="form-control" placeholder="" name="charge[actif][ta][caisse]" value="">
                </div>
                
                <h4>Capitaux Propres (CP)</h4>
				<div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Capital</span>
                  <input type="text" class="form-control" placeholder="" name="charge[passif][cp][capital]" value="">
                </div>
                <div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Ecarts de réévaluation</span>
                  <input type="text" class="form-control" placeholder="" name="charge[passif][cp][ecartreevaluation]" value="">
                </div>
                <div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Résultat net de l’Exercice</span>
                  <input type="text" class="form-control" placeholder="" name="charge[passif][cp][result_de_lexo]" value="">
                </div>
                
                
                <h4>Passif Circulant (PC)</h4>
				<div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Clients, Avances reçues</span>
                  <input type="text" class="form-control" placeholder="" name="charge[passif][pc][clientavanceresu]" value="">
                </div>
                <div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Fournisseurs (factures non payées)</span>
                  <input type="text" class="form-control" placeholder="" name="charge[passif][pc][fournisseurs]" value="">
                </div>
                
                <h4>Trésorerie Passif (TP)</h4>
				<div class="input-group input-group-lg">
                  <span class="input-group-addon" id="sizing-addon1">Banques (Crédits)</span>
                  <input type="text" class="form-control" placeholder="" name="charge[passif][tp][clientavanceresu]" value="">
                </div>
                <br />
                <input type="submit" class="btn btn-default" value="Générer le Bilan" />	
                <br />
                <br />
            </form>
        </div>
        <?php if( isset( $_POST[ 'charge' ] ) )
		{
			// print_array( $_POST[ 'charge' ] );
			?>
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                    	<tr>
                        	<td colspan="18">JOURNAL DU PATRIMOINE</td>
                        </tr>
                        <tr>
                        	<td width="150"><strong>DATE</strong></td>
                            <td class="text-center"><strong>LIBELLES</strong></td>
                            <td class="text-center"><strong>ACTIF</strong></td>
                            <td class="text-center"><strong>PASSIF</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
					$total_actif	=	0;
					$total_passif	=	0;
					foreach( $_POST[ 'charge' ] as $type	=> $charge )
					{
						foreach( $charge as $key =>	$_subcharge )
						{
							$title		=	'';
							$total		=	'';
							$ttotal		=	'';
							if( $key	===	'ai' )
							{
								$title	=	'Actif Immobilisé (AI)';
								$total	=	'Total AI';
							}
							if( $key	===	'ac' )
							{
								$title	=	'Actif Circulant (AC)';
								$total	=	'Total AC';
							}
							if( $key	===	'ta' )
							{
								$title	=	'Trésorerie Actif (TA)';
								$total	=	'Total TA';
							}
							if( $key	===	'cp' )
							{
								$title	=	'Capitaux Propres (CP)';
								$ttotal	=	'Total CP';
							}
							if( $key	===	'pc' )
							{
								$title	=	'Passif Circulant (PC)';
								$ttotal	=	'Total PC';
							}
							if( $key	===	'tp' )
							{
								$title	=	'Trésorerie Passif (TP)';
								$ttotal	=	'Total TP';
							}
							?>
                        <tr>
                            <td class="text-center"><?php echo $date_now;?></td>
                            <td class="text-left"><strong><?php echo $title;?></strong></td>
                            <td class="text-left"><strong><?php echo $total;?></strong></td>
                            <td class="text-left"><strong><?php echo $ttotal;?></strong></td>
                        </tr>
                            <?php
							foreach( $_subcharge as $key_schar => $__sscharge )
							{
								$charge_title	=	'';
								if( $key_schar	=== 'chargeimmobil' )
								{
									$charge_title	=	'Charges Immobilisées';
								}
								if( $key_schar	=== 'batiinstall' )
								{
									$charge_title	=	'Bâtiments, Installation';
								}	
								if( $key_schar	=== 'materiel' )
								{
									$charge_title	=	'Materiels';
								}
								if( $key_schar	=== 'stockmarcha' )
								{
									$charge_title	=	'Stocks Marchandises';
								}
								if( $key_schar	=== 'stockmatetapprov' )
								{
									$charge_title	=	'Stocks de matière et Approv';
								}
								if( $key_schar	=== 'creancefourniss' )
								{
									$charge_title	=	'Créances Fournisseurs';
								}
								if( $key_schar	=== 'creanceclientbonavoir' )
								{
									$charge_title	=	'Créances Clients (Bon Avoir)';
								}
								if( $key_schar	=== 'comptbanc' )
								{
									$charge_title	=	'Compte Bancaire';
								}
								if( $key_schar	=== 'caisse' )
								{
									$charge_title	=	'Caisse';
								}
								if( $key_schar	=== 'capital' )
								{
									$charge_title	=	'Capital';
								}
								if( $key_schar	=== 'ecartreevaluation' )
								{
									$charge_title	=	'Ecarts de réévaluation';
								}
								if( $key_schar	=== 'result_de_lexo' )
								{
									$charge_title	=	'Résultat net de l’Exercice';
								}
								if( $key_schar	=== 'clientavanceresu' )
								{
									$charge_title	=	'Clients, Avances reçues';
								}
								if( $key_schar	=== 'fournisseurs' )
								{
									$charge_title	=	'Fournisseurs (factures non payées)';
								}
								if( $key_schar	=== 'clientavanceresu' )
								{
									$charge_title	=	'Banques (Crédits)';
								}
												
								if( $type == 'actif' )
								{
									$total_actif	+=	$__sscharge;
														?>
                        <tr>
                            <td class="text-center"><?php echo $date_now;?></td>
                            <td class="text-left"><?php echo $charge_title;?></td>
                            <td class="text-right"><?php echo $lib->money_format( $__sscharge , '' );?></td>
                            <td class="text-right"><?php echo $lib->money_format( 0 , '' );?></td>
                        </tr>
					<?php

								}
								else
								{
									$total_passif	+=	$__sscharge;
														?>
                        <tr>
                            <td class="text-center"><?php echo $date_now;?></td>
                            <td class="text-left"><?php echo $charge_title;?></td>
                            <td class="text-right"><?php echo $lib->money_format( 0 , '' );?></td>
                            <td class="text-right"><?php echo $lib->money_format( $__sscharge , '' );?></td>
                        </tr>
					<?php

								}
							}
						}
					}
					?>
                    	<tr>	
                        	<td class="text-center"><?php echo $date_now;?></td>
                         	<td class="text-left"><strong></strong></td> 
                            <td class="text-right"><strong>  Totaux Actif</strong></td>
                            <td class="text-right"><strong>  Totaux Passif</strong></td>
                        </tr>
                    	<tr>	
                         	<td class="text-center"><?php echo $date_now;?></td>
                         	<td class="text-left"><strong> </strong></td> 
                            <td class="text-right"><?php echo $lib->money_format( $total_actif , '' );?></td>
                            <td class="text-right"><?php echo $lib->money_format( $total_passif , '' );?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
		}
		?>
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>
    </div>
</div>
<style type="text/css">
@media print { .noPrint { display:none; } }
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>
