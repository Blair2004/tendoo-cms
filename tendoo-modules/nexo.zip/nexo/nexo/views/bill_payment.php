<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_bill_list',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des factures d\'achats' )
) )->push_to( 1 );

$bills_array		=	array();

foreach( $bills as $_bill )
{
	$author			=	get_user( riake( 'AUTHOR' , $_bill ) , 'as_id' );
	$bills_array[]	=	array( 
		'<a href="' . module_url( array( 'buying_bill' , 'edit' , riake( 'ID' , $_bill ) ) ) . '">' . riake( 'TITLE' , $_bill ) . '</a>' , 
		riake( 'REF' , $_bill ),
		riake( 'MONTANT' , $_bill ),
		riake( 'DATE_CREATION' , $_bill ) ,
		timespan( riake( 'DATE_MODIFICATION' , $_bill ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer cette facture ?<br> Cette opération aura des conséquences sur le calcul de la caisse.' ) . '" href="' . module_url( array( 'buying_bill' , 'delete' , riake( 'ID' , $_bill ) ) ) . '"> Supprimer la facture </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Raison Sociale' ) , __( 'Référence' ) , __( 'Montant' ) ,__( 'Date de création' ) , __( 'Modifié' ) , __( 'Par' ) , __( 'Supprimer' ) ),
	'rows'			=>  $bills_array
) )->push_to( 'nexo_bill_list' );

$this->gui->get();