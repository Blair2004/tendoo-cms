<?php
$this->gui->cols_width( 1 , 3 );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'create' , 'buying_bill' ) ),
	'title'		=>	__( 'Ajouter une nouvelle facture d\'achat' ),
	'form_wrap'	=>	array(
		'type'	=>	'post',
		'submit_text'	=>	__( 'Enregistrer la facture' )
	)
) )->push_to( 1 );

$this->gui->set_item( array( 
	'type'		=>	'select',
	'name'		=>	'ref',
	'placeholder'	=>	__( 'Référence' ),
	'label'		=>	__( 'Référence' ),
	'text'		=>	array( __( 'Loyer' ) , __( 'Impôts' ) , __( 'Achat m/se' ) , __( 'Clientèle' ) , __( 'Factures' ) , __( 'Mat/Amg' ) , __( 'Admin' ) , __( 'Securite DAK' ) , __( 'Cable TV' ) , __( 'FAA' ) , __( 'RRR' ) , __( 'Fourbur' ) , __( 'Services Après Vente' ) , __( 'Pressing' ) , __( 'Publicité' ) , __( 'Eau' ) , __( 'Electricité' ) , __( 'Produits D\'entretien' ) , __( 'Frais Bancaires' ) , __( 'Internet' ) , __( 'Emballages' ) ),
	'value'		=>	array( 'loyer' , 'impots' , 'achatmse' , 'clients' , 'factures' , 'matsamg' , 'admin' , 'securitydak' , 'cabletv' , 'faa' , 'rrr' , 'fourbur' , 'sav' , 'pressing' , 'pub' , 'eau' , 'electricite' , 'productdentretien' , 'fraisbanc' , 'internet' , 'emballages' ),
	'description'	=>	__( 'Veuillez ajouter une référence assez claire et précise pour la facture.' )
) )->push_to( meta_namespace( array( 'create' , 'buying_bill' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'raison_sociale',
	'placeholder'	=>	__( 'Raison Sociale' ),
	'label'		=>	__( 'Raison Sociale' ),
	'description'	=>	__( 'Veuillez ajouter une raison sociale assez clair et précise pour la facture.' )
) )->push_to( meta_namespace( array( 'create' , 'buying_bill' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'nature_operation',
	'placeholder'	=>	__( 'Nature de l\'opération' ),
	'label'		=>	__( 'Nature de l\'opération' ),
) )->push_to( meta_namespace( array( 'create' , 'buying_bill' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'montant_de_loperation',
	'placeholder'	=>	__( 'Montant de l\'opération' ),
	'label'		=>	__( 'Montant de l\'opération' ),
	'description'	=>	__( 'Veuillez enregistrer une valeur numérique' ),
) )->push_to( meta_namespace( array( 'create' , 'buying_bill' ) ) );

// Description
$this->gui->set_item( array( 
	'type'			=>	'textarea',
	'name'			=>	'description_operation',
	'placeholder'	=>	__( 'Ajouter une description pour l\'operation' ),
	'label'			=>	__( 'Description de l\'opération' ),
	'description'	=>	__( 'La description n\'est pas obligatoire, mais nécessaire.' )
) )->push_to( meta_namespace( array( 'create' , 'buying_bill' ) ) );

$this->gui->get();