<?php
$prefs	=	array (
   'show_next_prev'  => TRUE,
   'next_prev_url'   => module_url( array( 'reports' , 'daily' ) , 'nexo' )
 );
 $prefs['template'] = '

   {table_open}<table border="0" cellpadding="0" cellspacing="0" class="table table-bordered">{/table_open}

   {heading_row_start}<tr>{/heading_row_start}

   {heading_previous_cell}<th><a href="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
   {heading_title_cell}<th colspan="{colspan}">{heading}</th>{/heading_title_cell}
   {heading_next_cell}<th><a href="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}

   {heading_row_end}</tr>{/heading_row_end}

   {week_row_start}<tr>{/week_row_start}
   {week_day_cell}<td class="text-right">{week_day}</td>{/week_day_cell}
   {week_row_end}</tr>{/week_row_end}

   {cal_row_start}<tr>{/cal_row_start}
   {cal_cell_start}<td class="text-right">{/cal_cell_start}

   {cal_cell_content}<a href="{content}">{day}</a>{/cal_cell_content}
   {cal_cell_content_today}<div class="highlight"><a href="{content}">{day}</a></div>{/cal_cell_content_today}

   {cal_cell_no_content}{day}{/cal_cell_no_content}
   {cal_cell_no_content_today}<div class="highlight">{day}</div>{/cal_cell_no_content_today}

   {cal_cell_blank}&nbsp;{/cal_cell_blank}

   {cal_cell_end}</td>{/cal_cell_end}
   {cal_row_end}</tr>{/cal_row_end}

   {table_close}</table>{/table_close}
';
get_instance()->load->library( 'calendar' , $prefs );
$date		=	get_instance()->date->time( '' , true );
$YEAR		=	( $YEAR  === 'DEFAULT' ) ? riake( 'y' , $date ) : $YEAR;
$MONTH		=	( $MONTH  === 'DEFAULT' ) ? riake( 'm' , $date ) : $MONTH;
$DAY		=	( $DAY	=== 'DEFAULT' ) ? unsinglerize( riake( 'd' , $date ) ) : $DAY;

$timestamp	=	strtotime( $YEAR .'-' . $MONTH . '-01' ) ;
$NBR_DAYS	=	cal_days_in_month( CAL_GREGORIAN , $MONTH , $YEAR );
$date_start	=	date( 'Y-m-' , $timestamp ) . $DAY . ' 00:00:00';
$date_end	=	date( 'Y-m-' , $timestamp ) . $DAY . ' 23:59:59';

$final_array				=	array();
		
for( $i = 0 ; $i<= $NBR_DAYS ; $i++ )
{
	$final_array[]			=	module_url( array( 'compta' , 'daily-selling-book' , $YEAR , $MONTH , unsinglerize( $i ) ) , 'nexo' );
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<title><?php echo get_page( 'title' );;?></title>
</head>
<body>
    <div class="container" style="width:100%; min-height:1170px;">
    <div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3><?php echo get_page( 'title' );;?></h3>
            </div>
            <hr style="margin:0 1%;">
        </div>
    </div>
    <div class="row">
    	<div class="col-lg-4 col-lg-offset-4 noPrint">
        	<?php		
				echo get_instance()->calendar->generate( $YEAR , $MONTH , $final_array );
			?>
        </div>
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                    	<tr>
                        	<td colspan="18">JOURNAL DE LA CAISSE</td>
                        </tr>
                        <tr>
                        	<td width="200"><strong>DATE</strong></td>
                            <td class="text-center"><strong>N° FACT</strong></td>
                            <td class="text-center"><strong>LIBELLES</strong></td>
                            <td class="text-center" width="200"><strong>RECETTES</strong></td>
                            <td class="text-center" width="200"><strong>DEPENSES</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-right"><?php echo $date_start;?></td>
                            <td></td>
							<td class="text-right">Solde Initial</td>
                            <td class="text-right"><?php echo $lib->money_format( riake( 'solde_de_base' , $nexo_settings ) , '' );?></td>
                            <td class="text-right"><?php echo $lib->money_format( 0 , '' );?></td>
                        </tr>
                        <?php
						$commandes				=		$lib->get_commands( 'between' , $date_start , $date_end , 'exclude_devis_et_avances' ); // 
						$commandes_total		=		0;
						$total_charge			=		0;
						foreach( force_array( $commandes ) as $_commande )
						{
							$total_charge		+=	riake( 'CHARGE' , $_commande );
							$_command_price		=	$lib->get_command_real_price( riake( 'ID' , $_commande ) , 'as_id' );
							$commandes_total	+=	$_command_price;
							$products			=	$lib->get_products_in_commands( riake( 'ID' , $_commande ) ); // Double Compta Ready										
							$category			=	array();
							foreach( force_array( $products ) as $_product )
							{
								$relation		=	farray( $lib->__get_product_relationship( riake( 'REF_RELATION' , $_product ) ) );
								$category[]		=	farray( $lib->get_category( riake( 'REF_CATEGORIE' , $relation ) , 'as_id' ) );
							}
						?>
                        <tr>
                            <td class="text-right"><?php echo riake( 'DATE_CREATION' , $_commande );?></td>
                            <td><?php echo riake( 'CODE' , $_commande );?></td>
							<td class="text-right">
							<?php 
							foreach( force_array( $category ) as $key	=>	$_cat )
							{
								if( $key + 1 < count( $category ) )
								{
									echo riake( 'NOM' , $_cat ) . ', ';
								}
								else
								{
									echo riake( 'NOM' , $_cat );
								}
							}
							?>
                            </td>
                            <td class="text-right"><?php echo $lib->money_format( $_command_price );?></td>
                            <td class="text-right"><?php echo $lib->money_format( riake( 'CHARGE' , $_commande ) , '' );?></td>
                        </tr>
                        <?php
						}
						$factures				= 		$lib->get_bill( 'between_date_asc' , $date_start , $date_end ); // 'between' , $date_start , $date_end
						foreach( force_array( $factures ) as $_facture )
						{
							$total_charge		+=		riake( 'MONTANT' , $_facture );
							?>
                        <tr>
                            <td class="text-right"><?php echo riake( 'DATE_CREATION' , $_facture );?></td>
                            <td></td>
							<td class="text-right"><?php echo riake( 'NATURE_SOCIALE' , $_facture );?></td>
                            <td class="text-right"><?php echo $lib->money_format( 0 , '' );?></td>
                            <td class="text-right"><?php echo $lib->money_format( riake( 'MONTANT' , $_facture ) , '' );?></td>
                        </tr>
                            <?php
						}
						?>
                        <tr>
                            <td class="text-right"><?php echo $date_end;?></td>
                            <td></td>
							<td class="text-right">Versement à Mr le trésorier</td>
                            <td class="text-right"><?php echo $lib->money_format( 0 , '' );?></td>
                            <td class="text-right"><?php echo ( $commandes_total - $total_charge ) < 0 ? '(-) ' : '' ; echo $lib->money_format( abs( $commandes_total - $total_charge ) , '' );?></td>
                        </tr>
                        <tr>
                            <td class="text-right"><?php echo $date_end;?></td>
                            <td></td>
							<td class="text-right">Solde Final</td>
                            <td class="text-right"><?php echo $lib->money_format( riake( 'solde_de_base' , $nexo_settings ) , '' );?></td>
                            <td class="text-right"><?php echo $lib->money_format( 0 , '' );?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>
    </div>
</div>
<style type="text/css">
@media print { .noPrint { display:none; } }
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>
