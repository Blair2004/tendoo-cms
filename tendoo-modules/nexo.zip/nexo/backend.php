<?php
class nexo_backend extends Libraries
{
	public function __construct($data)
	{
		parent::__construct();
		__extends($this);
		$this->load->library( 'gui' );
		$this->_config();
		$this->data						=	$data;
		$this->instance					=	get_instance();
		$this->opened_module			=	get_core_vars( 'opened_module' );
		$this->data['module']			=	get_core_vars( 'opened_module' );
		$this->lib						=	new nexo_class();
		set_core_vars( 'lib' , $this->lib );
		$this->options					=	get_meta( 'nexo_settings' );
		set_core_vars( 'nexo_settings'	, $this->options );
		// -=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	}
	function update()
	{
		get_instance()->url->redirect( array( 'error' , 'code' , 'underupdate' ) );
	}
	function reports( $type = 'daily' , $x = 'DEFAULT' , $y = 'DEFAULT' , $day = 'DEFAULT' )
	{
		if( $type == 'daily' )
		{
			set_core_vars( 'YEAR' , $x );
			set_core_vars( 'MONTH' , $y );
			set_core_vars( 'DAY' , $day );
			
			set_page( 'title' , 'Rapport Journalier ' . get( 'core_version' ) );
			
			module_view( 'views/daily-report' , false , 'nexo' );
		}
		else if( $type == 'statistiques-ventes' )
		{
			set_core_vars( 'date' , $x );
			set_core_vars( 'month' , $y );
			set_core_vars( 'day' , $day );
			set_core_vars( 'parent_categories' , $pc	=	$this->lib->get_category( 'only_parents' , null , 0 , 'name_asc' ) );	
			
			set_page( 'title' , 'Statistiques des Ventes' );
			
			module_view( 'views/statistiques-de-ventes' , false , 'nexo' );
		}
		else if( $type == 'ppa' )
		{
			$global_stats				=	$this->lib->get_product_related( 'categories' , 'optional' , 'sum' );
			
			// print_array( $global_stats );die;
			
			$product_list				=	$this->lib->get_product_inside_big_category( $global_stats );
			
			// print_array( $product_list );
			
			set_core_vars( 'product_list' , $product_list );
			
			set_core_vars( 'facture_dachats' , $this->lib->daily_report( 'recap-bills' ) );
			
			set_page( 'title' , 'Rapport Journalier ' . get( 'core_version' ) );
			
			module_view( 'views/recap-ppa' , false , 'nexo' );
		}
		else if( $type == 'monthly' )
		{
			set_core_vars( 'YEAR' , $x );
			set_core_vars( 'MONTH' , $y );
						
			set_page( 'title' , 'Rendement Mensuel ' );
			
			module_view( 'views/rendement-mensuel' , false , 'nexo' );
		}
		else if( $type == 'annuel' )
		{
			set_core_vars( 'YEAR' , $x );
			set_core_vars( 'MONTH' , $y );
						
			set_page( 'title' , 'Recapitulatif Caisse Annuel' );
			
			module_view( 'views/recapitulatif-annuel' , false , 'nexo' );
		}
	}
	function code_bar() // Experiment
	{
		$mbox = imap_open("{localhost:143}INBOX", "user_id", "password");
		$imap = imap_open("{pop.example.com:995/pop3/ssl/novalidate-cert}", "username", "password"); 
		if( $imap ) { 
			
			 //Check no.of.msgs 
			 $num = imap_num_msg($imap); 
		
			 //if there is a message in your inbox 
			 if( $num >0 ) { 
				  //read that mail recently arrived 
				  echo imap_qprint(imap_body($imap, $num)); 
			 } 
		
			 //close the stream 
			 imap_close($imap); 
		} 
	}
	private function _config()
	{
	}
	public function index()
	{				
		set_page( 'title' , 'Next By Olivia | ' . get( 'core_version' ) );
		
		set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
		
		return $this->load->view( $this->opened_module[ 'uri_path' ].'views/body', $this->data , true , true );
	}
	function providers( $page = 1 , $arg2 = null ) // Done
	{
		// Checking privilege.
		if( current_user()->cannot( 'nexo@manage_providers' ) ): module_url( array( '?notice=access-denied' ) );endif;
		
		if( is_numeric( $page ) )
		{
			// Counting Providers
			$nbr_provider		=	count( $this->lib->get_providers() );
			// Generating Pagination Data
			$pagination			=	pagination_helper( 
				riake( 'provider_pp' , $this->options , 10 ), 
				$nbr_provider , 
				$page , 
				module_url( array( 'providers' ) , 'nexo' ),
				$this->url->site_url( array( 'error' , 'code' , 'page-404' ) ) 
			); 
			set_core_vars( 'pagination_data' , $pagination );
			// get provider using pagination data
			$providers			=	$this->lib->get_providers( $pagination[ 'start' ] , $pagination[ 'end' ] );
			set_core_vars( 'providers' , $providers );
			// 
			set_page( 'title' , 'Next By Olivia - Fournisseurs' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			return module_view( 'views/providers', false , 'nexo' );
		}
		else if( $page == 'new' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'provider_name' , 'Le nom du fournisseur' , 'required|min_length[3]' );
			$this->form_validation->set_rules( 'provider_bp' , 'La boite postale du fournisseur' , 'required' );
			$this->form_validation->set_rules( 'provider_tel' , 'le numéro de téléphone du fournisseur' , 'required' );
			$this->form_validation->set_rules( 'provider_email' , 'L\'adresse email du fournisseur' , 'valid_email' );
			if( $this->form_validation->run() )
			{
				$result	=	$this->lib->create_providers( 
					$this->input->post( 'provider_name' ) , 
					$this->input->post( 'provider_bp' ) , 
					$this->input->post( 'provider_tel' ) , 
					$this->input->post( 'provider_email' ) , 
					'create' 
				);
				switch( $result )
				{
					case 'provider-created' : module_location( array( 'providers?notice=' . $result ) ); break;
					default : $this->notice->push_notice( fetch_notice_output( $result ) );
				}
			}
			set_page( 'title' , 'Next By Olivia - Ajouter un fournisseur' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			module_view( 'views/providers-new', false , 'nexo' );
		}
		else if( $page == 'edit' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'provider_name' , 'Le nom du fournisseur' , 'required|min_length[3]' );
			$this->form_validation->set_rules( 'provider_bp' , 'La boite postale du fournisseur' , 'required' );
			$this->form_validation->set_rules( 'provider_tel' , 'le numéro de téléphone du fournisseur' , 'required' );
			$this->form_validation->set_rules( 'provider_email' , 'L\'adresse email du fournisseur' , 'valid_email' );
			if( $this->form_validation->run() )
			{
				$result	=	$this->lib->create_providers( 
					$this->input->post( 'provider_name' ) , 
					$this->input->post( 'provider_bp' ) , 
					$this->input->post( 'provider_tel' ) , 
					$this->input->post( 'provider_email' ) , 
					'edit',
					$arg2
				);
				$this->notice->push_notice( fetch_notice_output( $result ) );
			}
			
			// Get provider
			$providers		=	$this->lib->get_providers( $arg2 , 'as_id' );
			// if provider doesn't exists
			if( ! $providers ): module_location( array( 'providers?notice=unknow-provider' ) );endif;
			// SaVing provider
			set_core_vars( 'providers' , $providers );
			
			set_page( 'title' , 'Next By Olivia - Modifier un fournisseur' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			module_view( 'views/providers-edit', false , 'nexo' );
		}	
		else if( $page == 'delete' )
		{
			module_location( array( 'providers?notice=' . $this->lib->delete_provider( $arg2 ) ) );
		}
	}
	function clients( $page = 1 , $id = null )
	{
		if( ! riake( 'client_privilege' , $this->options ) )
		{
			module_location( array( 'settings?notice=set-role-id-first' ) );
		}
		if( is_numeric( $page ) )
		{
			$clients	=	$this->roles->get_users_with_role( riake( 'client_privilege' , $this->options ) );
			set_core_vars( 'clients' , $clients );
			
			set_core_vars( 'clients' , $this->lib->get_clients() );
			
			set_page( 'title' , 'Nexo - Clients' );
						
			return module_view( 'views/clients', false , 'nexo' );
		}
		else if( $page == 'new' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'client_email' , 'Email du client' , 'valid_email' );
			$this->form_validation->set_rules( 'client_name' , 'Nom du client' , 'required' );
			if( $this->form_validation->run() )
			{
				$exec 	=	$this->lib->set_client( 
					$this->input->post( 'client_email' )
				);
				module_location( array( 'clients?notice=' . $exec ) );
			}
			set_page( 'title' , 'Next By Olivia - Ajouter un client' );
			
			module_view( 'views/clients-new', false , 'nexo' );
		}
		else if( $page == 'edit' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'client_email' , 'Email du client' , 'valid_email' );
			$this->form_validation->set_rules( 'client_name' , 'Nom du client' , 'required' );
			if( $this->form_validation->run() )
			{
				$exec 	=	$this->lib->set_client( 
					$this->input->post( 'client_email' ),
					'edit',
					$id
				);
				module_location( array( 'clients?notice=' . $exec ) );
			}
			$user	=	get_user( $id , 'as_id' );
			if( ! $user ): module_location( array( 'clients?notice=unknow-client' ) );endif;
			set_core_vars( 'client' , $user );			
			
			set_page( 'title' , 'Nexo - Modifier un client' );
			
			module_view( 'views/clients-edit', false , 'nexo' );
		}		
		else if( $page == 'delete' )
		{
			$user	=	get_user( $id , 'as_id' );
			if( riake( 'REF_ROLE_ID' , $user ) == riake( 'client_privilege' , $this->options ) )
			{
				if( current_user()->deleteSpeAdmin( $user[ 'PSEUDO' ] ) )
				{
					module_location( array( 'clients?notice=client-deleted' ) );
				}				
				module_location( array( 'clients?notice=error-occured' ) );
			}
			module_location( array( 'clients?notice=cannot-delete-unclient' ) );
		}
	}
	function bondavoir( $page = 1 , $id = null )
	{
		if( is_numeric( $page ) )
		{
			$nbr_bondav	=	count( $this->lib->get_bondavoir() );
			
			$pagination	=	pagination_helper( riake( 'bonavoir_pp' , $this->options , 10 ) , $nbr_bondav , $page , module_url( array( 'bondavoir' ) ) , $this->url->site_url( array( 'error' , 'code' , 'page-404' ) ) );
			set_core_vars( 'pagination_data' , $pagination );
			
			$bondavoirs	=	$this->lib->get_bondavoir( $pagination[ 'start' ] , $pagination[ 'end' ] );
			set_core_vars( 'bondavoirs' , $bondavoirs );
			
			set_page( 'title' , 'Liste des bons d\'avoir' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			return module_view( 'views/bondavoir', false , 'nexo' );
		}
		else if( $page == 'delete' )
		{
			$exec		=	$this->lib->delete_bondavoir( $id );
			module_location( array( 'bondavoir?notice=' . $exec ) );
		}
		else if( $page == 'printable' )
		{
			set_core_vars( 'bon_dachat' , $bon_dachat = farray( $this->lib->get_bondavoir( $id , 'as_id' ) ) );
			if( get_core_vars( 'bon_dachat' ) )
			{
				$distinct_product	=	$this->lib->get_distinct_from_command( $bon_dachat[ 'REF_COMMAND' ] , true );
				
				set_core_vars( 'distinct_product' , $distinct_product );
				return module_view( 'views/bondavoir-print-invoice', false , 'nexo' );
			}
			else
			{
				$this->url->redirect( array( 'error' , 'code' , 'unknow-bon-davoir' ) );
			}			
		}
		else if( $page == 'new' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'command_id' , 'Identifiant de la commande' , 'required|numeric' );
			if( $this->form_validation->run() )
			{
				$exec	=	$this->lib->set_bondavoir( $this->input->post( 'command_id' ) );
				if( $exec == 'bondav-set' )
				{
					module_location( array( 'bondavoir?notice=' . $exec ) );
				}
				$this->notice->push_notice( fetch_notice_output( $exec ) );
			}
			set_page( 'title' , 'Créer un nouveau bon d\'avoir' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			return module_view( 'views/bondavoir-new', false , 'nexo' );
		}
	}
	function commands( $page = 1 , $id = null )
	{
		if( $page == 'new' )
		{
			$this->load->library( 'form_validation' );
			// $this->form_validation->set_rules( 'command_type' , 'Type de la commande' , 'required|numeric' );
			$this->form_validation->set_rules( 'client_id' , 'Client concerné' , 'required|numeric' );
			$this->form_validation->set_rules( 'payment_type' , 'Mode de règlement' , 'required|numeric' );
			// $this->form_validation->set_rules( 'rrr' , 'Mode de règlement' , 'required|numeric' );
			// $this->form_validation->set_rules( 'montant_avancee' , 'Montant avancé' , 'required|numeric' );
			if( $this->form_validation->run() )
			{
				$exec	=	$this->lib->set_commandes( 
					$this->input->post( 'client_id' ) ,
					( int ) $this->input->post( 'rrr' ) , 
					$this->input->post( 'montant_command' ) , 
					$this->input->post( 'montant_avancee' ) , 
					riake( 'product_list_id' , $_POST , array() ) , 
					$this->input->post( 'payment_type' ),
					$mode = 'create' 
				);
				$exec == 'commands-successfully-done' ? 
					module_location( array( 'commands?notice=' . $exec ) ) : 
						get_instance()->notice->push_notice( fetch_notice_output( $exec ) );
			}
			
			set_page( 'title' , 'Nouvelle commande' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			return module_view( 'views/commands-new', false , 'nexo' );
		}
		else if( $page == 'delete' )
		{
			$exec	=	$this->lib->delete_command( $id );
			module_location( array( 'commands?notice=' . $exec ) );
		}
		else if( $page == 'printable' )
		{
			$command	=	$this->lib->get_commands( $id , 'as_id' );
			if( $command )
			{
				set_core_vars( 'command' , farray( $command ) );
				
				return module_view( 'views/commands-print-invoice' , false , 'nexo' );
			}
			else
			{
				get_instance()->url->redirect( array( 'error' , 'code' , 'unknow-command' ) );
			}
		}
		else if( $page == 'ticket' )
		{
			$command	=	$this->lib->get_commands( $id , 'as_id' );
			if( $command )
			{
				set_core_vars( 'command' , farray( $command ) );
				
				return module_view( 'views/commands-print-ticket' , false , 'nexo' );
			}
			else
			{
				get_instance()->url->redirect( array( 'error' , 'code' , 'unknow-command' ) );
			}
		}
		else if( $page == 'ajax-print' )
		{
			$command		=	farray( $this->lib->get_commands( $id , 'as_id' ) );
			$command_value	=	$this->lib->get_command_real_price( $id , 'as_id' );
			$client			=	get_user( riake( 'REF_CLIENT' , $command ) , 'filter_id' ) == '' ? 'Compte Client' : get_user( riake( 'REF_CLIENT' , $command ) , 'filter_id' );
			echo json_encode( array(
				'command_price'		=>		$command_value,
				'avance'			=>		riake( 'AVANCE' , $command ),
				'code'				=>		riake( 'CODE' , $command ),
				'client_name'		=>		$client_name 	=	in_array( riake( 'client_name' , $client ) , array( 'false' , '' ) ) ? 'Compte Client' : $client_name,
				'client_bp'			=>		$client_bp 		=	in_array( riake( 'client_bp' , $client ) , array( 'false' , '' ) ) ? 'Non défini' : $client_bp,
				'client_email'		=>		$client_email	=	in_array( riake( 'client_email' , $client ) , array( 'false' , '' ) ) ? 'Non défini' : $client_email,
				'client_tel'		=>		$client_tel		=	in_array( riake( 'num_client' , $client ) , array( 'false' , '' ) ) ? 'Non défini' : $client_tel,
			) , JSON_FORCE_OBJECT );
		}
		else if( is_numeric( $page ) )
		{
			$nbr_commands	=	count( $this->lib->get_commands() );
			$pagination		=	pagination_helper( riake( 'commands_pp' , $this->options , 10 ) , $nbr_commands , $page , module_url( array( 'commands' ) ) , get_instance()->url->site_url( array( 'error' , 'code' , 'page-404' ) ) );
			set_core_vars( 'pagination_data' , $pagination );
			$commands		=	$this->lib->get_commands( $pagination[ 'start' ] , $pagination[ 'end' ] );

			set_core_vars( 'commands' , $commands );
			
			set_page( 'title' , 'Liste des commandes' );
			
			return module_view( 'views/commands', false , 'nexo' );
		}
	}
	/**
	 * 
	**/
	function flux( $type = 'input', $page = 1 , $id = null ) // unfinished
	{
		if( $type == 'input' )
		{
			if( is_numeric( $page ) )
			{
				$nbr_input	=	count( $this->lib->get_flux( 'input' ) );
				$pagination	=	pagination_helper( riake( 'input_pp' , $this->options , 10 ) , $nbr_input , $page , module_url( array( 'flux' , 'input' ) ) , get_instance()->url->site_url( array ( 'error' , 'code' , 'page-404' ) ) );
				set_core_vars( 'pagination_data' , $pagination );
				
				$inputs		=	$this->lib->get_flux( 'input' , $pagination[ 'start' ] , $pagination[ 'end' ] );
				set_core_vars( 'inputs' , $inputs );
				
				set_page( 'title' , 'Liste des entrées extraordinaires' );
				
				return module_view( 'views/inputs', false , 'nexo' );
			}
			else if( $page == 'new' )
			{
				$this->load->library( 'form_validation' );
				$this->form_validation->set_rules( 'entre_name' , 'Désignation de l\'entrée' , 'required' );
				$this->form_validation->set_rules( 'entre_amount' , 'Montant de l\'entrée' , 'required|numeric' );
				if( $this->form_validation->run() )
				{
					$exec	=	$this->lib->set_flux( 
						'input',
						$this->input->post( 'entre_name' ),
						$this->input->post( 'entre_amount' ),
						$this->input->post( 'entre_desc' ),
						'create'
					);
					if( $exec == 'flux-successfully-set' )
					{
						module_location( array( 'flux' , 'input?notice=' . $exec ) );
					}
					$this->notice->push_notice( fetch_notice_output( $exec ) );
				}
				
				set_page( 'title' , 'Nouvelle entrée extraordinaire' );
				
				return module_view( 'views/inputs-new', false , 'nexo' );
			}
			else if( $page == 'edit' )
			{
				$this->load->library( 'form_validation' );
				$this->form_validation->set_rules( 'entre_name' , 'Désignation de l\'entrée' , 'required' );
				$this->form_validation->set_rules( 'entre_amount' , 'Montant de l\'entrée' , 'required|numeric' );
				if( $this->form_validation->run() )
				{
					$exec	=	$this->lib->set_flux( 
						'input',
						$this->input->post( 'entre_name' ),
						$this->input->post( 'entre_amount' ),
						$this->input->post( 'entre_desc' ),
						'edit',
						$id
					);
					$this->notice->push_notice( fetch_notice_output( $exec ) );
				}
				
				$entre	=	farray( $this->lib->get_flux( 'input' , $id , 'as_id' ) );
				if( ! $entre ): get_instance()->url->redirect( array( 'error' , 'code' , 'unknow-flux' ) ); endif;
				
				set_core_vars( 'input' , $entre );
				
				set_page( 'title' , 'Liste des entrées extraordinaires' );
				
				return module_view( 'views/inputs-edit', false , 'nexo' );
			}
			else if( $page == 'delete' )
			{
				$exec	=	$this->lib->delete_flux( $id );
				module_location( array( 'flux' , 'input?notice='. $exec ) );
			}
		}
		else if( $type == 'output' )
		{
			if( is_numeric( $page ) )
			{
				$nbr_input	=	count( $this->lib->get_flux( 'output' ) );
				$pagination	=	pagination_helper( riake( 'output_pp' , $this->options , 10 ) , $nbr_input , $page , module_url( array( 'flux' , 'output' ) ) , get_instance()->url->site_url( array ( 'error' , 'code' , 'page-404' ) ) );
				set_core_vars( 'pagination_data' , $pagination );
				
				$inputs		=	$this->lib->get_flux( 'output' , $pagination[ 'start' ] , $pagination[ 'end' ] );
				set_core_vars( 'inputs' , $inputs );
				
				set_page( 'title' , 'Liste des sorties extraordinaires' );
				
				return module_view( 'views/output', false , 'nexo' );
			}
			else if( $page == 'new' )
			{
				$this->load->library( 'form_validation' );
				$this->form_validation->set_rules( 'entre_name' , 'Désignation de la sortie' , 'required' );
				$this->form_validation->set_rules( 'entre_amount' , 'Montant de la sortie' , 'required|numeric' );
				if( $this->form_validation->run() )
				{
					$exec	=	$this->lib->set_flux( 
						'output',
						$this->input->post( 'entre_name' ),
						$this->input->post( 'entre_amount' ),
						$this->input->post( 'entre_desc' ),
						'create'
					);
					if( $exec == 'flux-successfully-set' )
					{
						module_location( array( 'flux' , 'output?notice=' . $exec ) );
					}
					$this->notice->push_notice( fetch_notice_output( $exec ) );
				}
				
				set_page( 'title' , 'Nouvelle sortie extraordinaire' );
				
				return module_view( 'views/inputs-new', false , 'nexo' );
			}
			else if( $page == 'edit' )
			{
				$this->load->library( 'form_validation' );
				$this->form_validation->set_rules( 'entre_name' , 'Désignation de la sortie' , 'required' );
				$this->form_validation->set_rules( 'entre_amount' , 'Montant de la sortie' , 'required|numeric' );
				if( $this->form_validation->run() )
				{
					$exec	=	$this->lib->set_flux( 
						'output',
						$this->input->post( 'entre_name' ),
						$this->input->post( 'entre_amount' ),
						$this->input->post( 'entre_desc' ),
						'edit',
						$id
					);
					$this->notice->push_notice( fetch_notice_output( $exec ) );
				}
				
				$entre	=	farray( $this->lib->get_flux( 'output' , $id , 'as_id' ) );
				if( ! $entre ): get_instance()->url->redirect( array( 'error' , 'code' , 'unknow-flux' ) ); endif;
				
				set_core_vars( 'input' , $entre );
				
				set_page( 'title' , 'Liste des sorties extraordinaires' );
				
				return module_view( 'views/inputs-edit', false , 'nexo' );
			}
			else if( $page == 'delete' )
			{
				$exec	=	$this->lib->delete_flux( $id );
				module_location( array( 'flux' , 'output?notice='. $exec ) );
			}
		}
	}
	/**
	 * Gestion des arrivage
	**/
	function shipping( $page = 1 , $arg2 = null , $arg3 = null , $arg4 = null )
	{
		if( $page === 'new' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'shipping_name' , 'Ajouter un nom' , 'required|min_length[3]' );
			$this->form_validation->set_rules( 'shipping_provider' , 'Choisissez un fournisseur.' , 'required' );
			if( $this->form_validation->run() )
			{
				$result		=	$this->lib->create_shipping( 
					$this->input->post( 'shipping_name' ),
					$this->input->post( 'shipping_provider' ),
					$this->input->post( 'shipping_description' )
				);
				if( $result == 'shipping-created' && $this->input->post( 'create_new_product' ) )
				{
					module_location( array( 'articles' , 'new?notice=' . $result ) );
				} 
				else if( $result == 'shipping-created' && $this->input->post( 'create' ) )
				{
					module_location( array( 'shipping?notice=' . $result ) );
				}
				else if( $result == 'shipping-created' && $this->input->post( 'create_new_category' ) )
				{
					module_location( array( 'category' , 'new?notice=' . $result ) );
				}
				else
				{
					$this->notice->push_notice( fetch_notice_output( $result ) );
				}
			}
						
			set_core_vars( 'providers' , $this->lib->get_providers() );
			/**
			 * Head
			**/
						
			set_page( 'title' , 'Nouvel Arrivage' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			return module_view( 'views/shipping-new', false , 'nexo' );
		}
		else if( $page === 'edit' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'shipping_name' , 'Ajouter un nom' , 'required|min_length[3]' );
			$this->form_validation->set_rules( 'shipping_provider' , 'Choisissez un fournisseur.' , 'required' );
			if( $this->form_validation->run() )
			{
				$result		=	$this->lib->create_shipping( 
					$this->input->post( 'shipping_name' ),
					$this->input->post( 'shipping_provider' ),
					$this->input->post( 'shipping_description' ),
					'edit',
					$arg2
				);
				if( $result == 'shipping-updated' )
				{
					if( $this->input->post( 'create_new_product' ) )
					{
						module_location( array( 'articles' , 'new?notice=' . $result ) );
					} 
					else if( $this->input->post( 'create' ) )
					{
						module_location( array( 'shipping?notice=' . $result ) );
					}
					else if( $this->input->post( 'create_new_category' ) )
					{
						module_location( array( 'category' , 'new?notice=' . $result ) );
					}
				}
				else 
				{
					$this->notice->push_notice( fetch_notice_output( $result ) ) ;
				}
			}
			set_core_vars( 'shipping' , $this->lib->get_shipping( $arg2 , 'as_id' ) );
			set_core_vars( 'providers' , $this->lib->get_providers() );
			
			set_page( 'title' , 'Modifier un arrivage' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			return module_view( 'views/shipping-edit', false , 'nexo' );
		}
		else if( $page === 'delete' )
		{
			$exec	=	$this->lib->delete_shipping( $arg2 );
			module_location( array( 'shipping?notice=' . $exec ) );
		}
		else if( $page === 'fiche' )
		{
			$shipping	=	farray( $this->lib->get_shipping( $arg2 , 'as_id' ) );
			set_core_vars( 'shipping' , $shipping );
			
			$produits	=	$this->lib->get_product( riake( 'ID' , $shipping ) , 'as_shipping' , 'distinct' , 'name_asc' );
			set_core_vars( 'produits' , $produits );
			
			return module_view( 'views/shipping-list', false , 'nexo' );
		}
		else if( $page === 'test' )
		{
			$array	=	array( 'blue' , 'rouge' , 'vert' , 'jaun' );
		}
		else if( $page === 'fiche-stock' )
		{
			
			$shipping					=	farray( $this->lib->get_shipping( $arg2 , 'as_id' ) );
			set_core_vars( 'shipping' , $shipping );
			set_core_vars( 'current_shipping_id' , $arg2 );
			
			$previous_shippings			=	$this->lib->get_shipping( $arg2 , 'as_excluded_id' );
			set_core_vars( 'previous_shippings' , $previous_shippings );
			
			$previous_products	=	$this->lib->get_shippings_products( $previous_shippings );
			
			// print_array( $previous_products );
			
			$latest_categories	=	$this->lib->__get_latest_category();
			
			set_core_vars( 'latest_categories' , $latest_categories );
			
			$products	=	farray( $this->lib->get_product( $arg2 , 'as_shipping' ) );
			
			// set_core_vars( 'shipping' , $shippings );
			
			// $produits	=	$this->lib->get_product( riake( 'ID' , $shipping ) , 'as_shipping' );
			// set_core_vars( 'produits' , $produits );
			
			return module_view( 'views/shipping-list-stock', false , 'nexo' );
		}
		else if( $page === 'fiche-recap' )
		{
			$shipping					=	farray( $this->lib->get_shipping( $arg2 , 'as_id' ) );
			
			if( ! $shipping )
			{
				get_instance()->url->redirect( array( 'error' , 'code' , 'unknow-shipping' ) );
			}
			set_core_vars( 'shipping' , $shipping );
			set_core_vars( 'shipping_id' , $arg2 );
			
			set_core_vars( 'parent_categories' , $pc	=	$this->lib->get_category( 'only_parents' , null , 0 , 'name_asc' ) );
			// set_core_vars( 'famille_categories' , $this->lib->get_category( 'only_parents' , null , 0 , 'name_asc' ) );
			
			// set_core_vars( 'shipping' , $shippings );
			
			// $produits	=	$this->lib->get_product( riake( 'ID' , $shipping ) , 'as_shipping' );
			// set_core_vars( 'produits' , $produits );
			
			return module_view( 'views/shipping-recap', false , 'nexo' );
		}
		else if( $page === 'ecarts-commerciaux' )
		{
			$shipping					=	farray( $this->lib->get_shipping( $arg2 , 'as_id' ) );
			
			if( ! $shipping )
			{
				get_instance()->url->redirect( array( 'error' , 'code' , 'unknow-shipping' ) );
			}
			
			if( $arg3 == null )
			{
				$date_array	=	get_instance()->date->time( '' , true );
				$arg3		=	$date_array[ 'y' ];
			}
			
			set_core_vars( 'page' , $arg2 );
			set_core_vars( 'date', $arg3 );
			
			set_core_vars( 'shipping' , $shipping );
			set_core_vars( 'shipping_id' , $arg2 );
			
			set_core_vars( 'parent_categories' , $pc	=	$this->lib->get_category( 'only_parents' , null , 0 , 'name_asc' ) );
			
			return module_view( 'views/ecart-commerciaux', false , 'nexo' );
		}
		else
		{
			// Count Shipping
			$nbr_shipping	=	count( $this->lib->get_shipping() );
			
			// Do paginate
			// var_dump( $page );
			$paginate		=	pagination_helper( riake( 'shipping_pp' , $this->options , 10 ) , $nbr_shipping , $page , module_url( array( 'shipping' ) ) , $this->url->site_url( array( 'error' , 'code' ,'page-404' ) ) );			
			
			set_core_vars( 'pagination_data' , $paginate );
			// Get Shippings
			$shippings		=	$this->lib->get_shipping( $paginate[ 'start' ] , $paginate[ 'end' ] );
			set_core_vars( 'shippings' , $shippings );

			// Setting Title
			set_page( 'title' , 'Liste des arrivages' );
			
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			return module_view( 'views/shipping', false , 'nexo' );
		}
	}
	/**
	 * Gestion des produits
	**/
	function articles( $page = 1 , $id = null )
	{
		if( !is_numeric( $page ) && $page == 'new' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'designation_produit' , 'Désignation du produit' , 'required' );
			$this->form_validation->set_rules( 'shipping_id' , 'Choisir un arrivage' , 'required' );
			// $this->form_validation->set_rules( 'prix_ttc' , 'Prix TTC' , 'required|numeric' );
			
			$this->form_validation->set_rules( 'prix_dachat' , 'Prix d\'achat' , 'required|numeric' );
			$this->form_validation->set_rules( 'frais_access' , 'Frais accessoires' , 'required|numeric' );
			$this->form_validation->set_rules( 'taux_marge' , 'Taux de marge' , 'required|numeric' );
			
			// $this->form_validation->set_rules( 'cu' , 'Coût unitaire' , 'required' );
			$this->form_validation->set_rules( 'cat_aa' , 'Catégorie Article' , 'required' );
			$this->form_validation->set_rules( 'rayon' , 'Rayon' , 'required' );
			$this->form_validation->set_rules( 'taille' , 'Taille' , 'required' );
			$this->form_validation->set_rules( 'couleur' , 'Couleur du produit' , 'required' );
			$this->form_validation->set_rules( 'quantity' , 'Quantité' , 'required|numeric' );
			$this->form_validation->set_rules( 'defectueux' , 'Quantité défectueuse' , 'required|numeric' );
			$this->form_validation->set_rules( 'taux_solde' , 'Taux de solde' , 'required|is_natural|less_than[101]' );
			if( $this->form_validation->run() )
			{
				$exec	=	$this->lib->set_product( 
					$this->input->post( 'designation_produit' ) , 
					$this->input->post( 'shipping_id' ) , 
					$this->input->post( 'prix_ttc' ) , 
					$this->input->post( 'cu' ) , 
					$this->input->post( 'cat_aa' ) , 
					$this->input->post( 'rayon' ) ,
					$this->input->post( 'shipping_id' ), 
					$this->input->post( 'taille' ) , 
					$this->input->post( 'couleur' ) , 
					$this->input->post( 'quantity' ) ,
					$this->input->post( 'prix_dachat' ),
					$this->input->post( 'frais_access' ),
					$this->input->post( 'taux_marge' ), 
					$this->input->post( 'taux_solde' ), 
					$this->input->post( 'defectueux' ),
					$this->input->post( 'enable_discount' ),
					'create' 
				);
				if( $exec == 'product-has-been-created' )
				{
					$this->notice->push_notice( fetch_notice_output( $exec ) );
					if( $this->input->post( 'create_new_product' ) )
					{
						module_location( array( 'articles' , 'new?notice=' . $exec ) );
					} 
					else if( $this->input->post( 'create_and_back' ) )
					{
						module_location( array( 'articles?notice=' . $exec ) ) ;
					}
				}
			}
			$categories	=	$this->lib->get_category( 'only-latest' , null , 0 , 'name_asc' );
			set_core_vars( 'categories' , $categories );
			
			$rayons		=	$this->lib->get_rayons();
			set_core_vars( 'rayons' , $rayons );
			
			$shippings	=	$this->lib->get_shipping();
			set_core_vars( 'shippings' , $shippings );
						
			set_page( 'title' , 'Ajouter un nouvel article' );
						
			return module_view( 'views/product-new', false , 'nexo' );
		}
		if( $page == 'edit' )
		{
			$this->load->library( 'form_validation' );
			$this->form_validation->set_rules( 'designation_produit' , 'Désignation du produit' , 'required' );
			$this->form_validation->set_rules( 'shipping_id' , 'Choisir un arrivage' , 'required' );
			// $this->form_validation->set_rules( 'prix_ttc' , 'Prix TTC' , 'required|numeric' );
			// $this->form_validation->set_rules( 'cu' , 'Coût unitaire' , 'required' );
			$this->form_validation->set_rules( 'cat_aa' , 'Catégorie Article' , 'required' );
			
			$this->form_validation->set_rules( 'prix_dachat' , 'Prix d\'achat' , 'required|numeric' );
			$this->form_validation->set_rules( 'frais_access' , 'Frais accessoires' , 'required|numeric' );
			$this->form_validation->set_rules( 'taux_marge' , 'Taux de marge' , 'required|numeric' );
			
			$this->form_validation->set_rules( 'rayon' , 'Rayon' , 'required' );
			$this->form_validation->set_rules( 'taille' , 'Taille' , 'required' );
			$this->form_validation->set_rules( 'couleur' , 'Couleur du produit' , 'required' );
			$this->form_validation->set_rules( 'quantity' , 'Quantité' , 'required|numeric' );
			$this->form_validation->set_rules( 'defectueux' , 'Quantité défectueuse' , 'required|numeric' );
			$this->form_validation->set_rules( 'taux_solde' , 'Taux de solde' , 'required|is_natural|less_than[101]' );
			if( $this->form_validation->run() )
			{
				$exec	=	$this->lib->set_product( 
					$this->input->post( 'designation_produit' ) , 
					$this->input->post( 'shipping_id' ) , 
					$this->input->post( 'prix_ttc' ) , 
					$this->input->post( 'cu' ) , 
					$this->input->post( 'cat_aa' ) , 
					$this->input->post( 'rayon' ) , 
					$this->input->post( 'shipping_id' ),
					$this->input->post( 'taille' ) , 
					$this->input->post( 'couleur' ) , 
					$this->input->post( 'quantity' ) , 
					$this->input->post( 'prix_dachat' ),
					$this->input->post( 'frais_access' ),
					$this->input->post( 'taux_marge' ), 
					$this->input->post( 'taux_solde' ), 
					$this->input->post( 'defectueux' ),
					$this->input->post( 'enable_discount' ),
					'edit',
					$id
				);
				$this->notice->push_notice( fetch_notice_output( $exec ) );
				if( $this->input->post( 'create_new_product' ) )
				{
					module_location( array( 'articles' , 'new?notice=' . $exec ) );
				} 
				else if( $this->input->post( 'create_and_back' ) )
				{
					module_location( array( 'articles?notice=' . $exec ) ) ;
				}
			}
			
			$product		=	$this->lib->get_product( $id , 'as_relation_id' );
						
			set_core_vars( 'product' , farray( $product ) );
			if( ! $product )
			{
				module_location( array( 'articles?notice=unknow-product' ) );
			}
			// Load Datas
			$categories	=	$this->lib->get_category( 'only-latest' , null , 0 , 'name_asc' );
			
			set_core_vars( 'categories' , $categories );
			
			$rayons		=	$this->lib->get_rayons();
			set_core_vars( 'rayons' , $rayons );
			
			$shippings	=	$this->lib->get_shipping();
			set_core_vars( 'shippings' , $shippings );
			
			// Setting Head			
			set_page( 'title' , 'Modifier un produit' );
			return module_view( 'views/product-edit', false , 'nexo' );
		}
		else if( $page == 'delete' )
		{
			$exec		=	$this->lib->delete_product( $id );
			module_location( array( 'articles?notice=' . $exec ) );
		}
		else if( $page == 'ajax_get' )
		{
			echo $this->lib->add_to_cart_conditional_test( $id );
		}
		else if( $page == 'printable' )
		{
			// configuration de l'identifiant
			$id 	=	$id == null ? 1 : $id;
			// 
			$nbr_product	=	count( $this->lib->get_product() );
			$pagination		=	pagination_helper( riake( 'product_pp' , $this->options , 10 ) , $nbr_product , $id , module_url( array( 'articles' , 'printable' ) ) , get_instance()->url->site_url( array( 'error' , 'code' , 'page-404' ) ) );
			set_core_vars( 'pagination_data' , $pagination );
			
			$products		=	$this->lib->get_product( $pagination[ 'start' ] , $pagination[ 'end' ] );
			set_core_vars( 'products' , $products );
			//			
			return module_view( 'views/product-printable-new', false , 'nexo' );
		}
		else if( $page == 'restore_codebar' )
		{
			// configuration de l'identifiant
			$id 	=	$id == null ? 1 : $id;
			// 
			$nbr_product	=	count( $this->lib->get_product() );
			$pagination		=	pagination_helper( riake( 'product_pp' , $this->options , 10 ) , $nbr_product , $id , module_url( array( 'articles' , 'printable' ) ) , get_instance()->url->site_url( array( 'error' , 'code' , 'page-404' ) ) );
			set_core_vars( 'pagination_data' , $pagination );
			
			$products		=	$this->lib->get_product( $pagination[ 'start' ] , $pagination[ 'end' ] );
			$exec			=	$this->lib->refresh_codebar( $products );
			//			
			module_location( array( 'articles' , $id . '?notice=' . $exec ) );
		}
		else if( $page == 'check-if-exist' )
		{
			$article_name 	=	riake( 'field_name' , $_POST );
			$article		=	farray( $this->lib->get_product( $article_name , 'as_name_low_case' ) );
			if( $article )
			{
				$array	=	array(
					'product_exists'	=>	true,
					'product_id'		=>	riake( 'ID' , $article ),
					'relation_id'		=>	riake( 'ID' , $article )
				);
			}
			else
			{
				$array	=	array(
					'product_exists'	=>	false,
					'product_id'		=>	riake( 'ID' , $article )
				);
			}
			echo json_encode( $array );
		}
		else
		{
			set_core_vars( 'current_page' , $page );
			$nbr_product	=	count( $this->lib->get_product() );
			$pagination		=	pagination_helper( riake( 'product_pp' , $this->options , 10 ) , $nbr_product , $page , module_url( array( 'articles' ) ) , get_instance()->url->site_url( array( 'error' , 'code' , 'page-404' ) ) );
			set_core_vars( 'pagination_data' , $pagination );
			
			$products		=	$this->lib->get_product( $pagination[ 'start' ] , $pagination[ 'end' ] , 'distinct' , 'name_asc' );
			set_core_vars( 'products' , $products );

			//			
			set_page( 'title' , 'Liste des articles' );						
			return module_view( 'views/product', false , 'nexo' );
		}
	}
	function rayons( $page = 1 , $arg2 = null )
	{
		if( !is_numeric( $page ) )
		{
			if( $page == 'new' )
			{
				$this->load->library( 'form_validation' );
				$this->form_validation->set_rules( 'designation_rayon' , 'Désignation rayon' , 'required' );
				if( $this->form_validation->run() )
				{
					switch( $exec	=	$this->lib->set_rayon( 
						$this->input->post( 'designation_rayon' ),
						$this->input->post( 'description_rayon' ),
						'create'
					) ) 
					{
						case 'rayon-has-been-created' 			: 	module_location( 'rayons?notice=' . $exec );
						case 'unable-to-create-or-edit-rayon' 	: 	$this->notice->push_notice( fetch_notice_output( $exec ) );
					}
				}
				set_page( 'title' , 'Nouveau Rayon' );
			
				set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
				
				return module_view( 'views/rayon-new', false , 'nexo' );
			}
			else if( $page == 'edit' )
			{
				$this->load->library( 'form_validation' );
				$this->form_validation->set_rules( 'designation_rayon' , 'Désignation rayon' , 'required' );
				if( $this->form_validation->run() )
				{
					switch( $exec	=	$this->lib->set_rayon( 
						$this->input->post( 'designation_rayon' ),
						$this->input->post( 'description_rayon' ),
						'edit',
						$arg2
					) ) 
					{
						case 'rayon-has-been-edited' 			: 	module_location( 'rayons?notice=' . $exec );
						case 'unable-to-create-or-edit-rayon' 	:	$this->notice->push_notice( fetch_notice_output( $exec ) );
					}
				}
				
				( $rayon	=	$this->lib->get_rayons( $arg2 , 'as_id' ) ) == false ? module_location( array( 'rayons?notice=unknow-rayon' ) ) : null;
				set_core_vars( 'rayon' , $rayon );
				
				set_page( 'title' , 'Modifier un rayon' );
			
				set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
				
				return module_view( 'views/rayon-edit', false , 'nexo' );
			}
			else if( $page == 'delete' )
			{
				$exec	=	$this->lib->delete_rayons( $arg2 , 'as_id' );
				module_location( array( 'rayons?notice=' . $exec ) );
			}
		}
		else
		{
			$nbr_rayons		=	count( $this->lib->get_rayons() );
			
			$pagination		=	pagination_helper( riake( 'rayon_pp' , $this->options , 10 ) , $nbr_rayons , $page , module_url( array( 'rayons' ) ), get_instance()->url->site_url( array( 'error' , 'code' , 'page-404' ) ) );
			set_core_vars( 'pagination_data' , $pagination );
			
			$rayons			=	$this->lib->get_rayons( $pagination[ 'start' ] , $pagination[ 'end' ] );
			
			set_core_vars( 'rayons' , $rayons );
			
			set_page( 'title' , 'Liste des rayons' );
		
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
				
			return module_view( 'views/rayons', false , 'nexo' );
		}
	}
	function buying_bill( $page = 1 , $id = null )
	{
		if( !is_numeric( $page ) )
		{
			$this->load->library( 'form_validation' );
			if( $page == 'new' )
			{
				$this->form_validation->set_rules( 'raison_sociale' , 'Raison Sociale' , 'required' );
				$this->form_validation->set_rules( 'nature_operation' , 'Nature de l\'opération' , 'required' );
				$this->form_validation->set_rules( 'montant_de_loperation' , 'Montant de l\'opération' , 'required|numeric' );
				if( $this->form_validation->run() )
				{
					$exec	=	$this->lib->set_bill( 
						$this->input->post( 'raison_sociale' ),
						$this->input->post( 'description_operation' ),
						$this->input->post( 'montant_de_loperation' ),
						$this->input->post( 'nature_operation' ),
						$this->input->post( 'ref' ),
						'create'
					);
					if( $exec == 'bill-set' ) 
					{
						module_location( array( 'buying_bill?notice=' . $exec ) );
					}
					else
					{
						$this->notice->push_notice( fetch_notice_output( $exec ) );
					}
				}
				
				set_page( 'title' , 'Nouvelle facture d\'achat' );
			
				return module_view( 'views/bill_payment-new', false , 'nexo' );
			} 
			else if( $page == 'edit' )
			{
				$this->form_validation->set_rules( 'raison_sociale' , 'Raison Sociale' , 'required' );
				$this->form_validation->set_rules( 'nature_operation' , 'Nature de l\'opération' , 'required' );
				$this->form_validation->set_rules( 'montant_de_loperation' , 'Montant de l\'opération' , 'required|numeric' );
				if( $this->form_validation->run() )
				{
					$exec	=	$this->lib->set_bill( 
						$this->input->post( 'raison_sociale' ),
						$this->input->post( 'description_operation' ),
						$this->input->post( 'montant_de_loperation' ),
						$this->input->post( 'nature_operation' ),
						$this->input->post( 'ref' ),
						'edit',
						$id
					);
					$this->notice->push_notice( fetch_notice_output( $exec ) );
				}
				$bills		=	$this->lib->get_bill( $id , 'as_id' );
				!$bills  	? 	module_location( array( 'buying_bill?notice=unknow-bill' ) ) : null;
				set_core_vars( 'bills' , farray( $bills ) );
				
				set_page( 'title' , 'Modifier une facture d\'achat' );
			
				return module_view( 'views/bill_payment-edit', false , 'nexo' );
			}
			else if( $page == 'delete' )
			{
				$exec 	=	$this->lib->delete_bill( $id );
				module_location( array( 'buying_bill?notice=' . $exec ) );
			}
		}
		else
		{
			$nbr_bill	=	count( $this->lib->get_bill() );
			$pagination	=	pagination_helper( riake( 'bills_pp' , $this->options , 10 ) , $nbr_bill , $page , module_url( array( 'buying_bill' ) ), get_instance()->url->site_url( array( 'error' , 'code' , 'page-404' ) ) );
			set_core_vars( 'pagination_data' , $pagination );
			
			$bills		=	$this->lib->get_bill( $pagination[ 'start' ] , $pagination[ 'end' ] );
			set_core_vars( 'bills' , $bills );
			
			set_page( 'title' , 'Liste des factures d\'achats' );			
			return module_view( 'views/bill_payment', false , 'nexo' );	
		}
	}
	function category( $page = 1 , $arg2 = null )
	{
		if( !is_numeric( $page ) )
		{
			if( $page == 'new' )
			{
				$this->load->library( 'form_validation' );
				$this->form_validation->set_rules( 'designation_category', __( 'Désignation categorie' ) , 'required' );
				$this->form_validation->set_rules( 'identifiant_parent' , __( 'Categorie Parent' ), 'numeric' );
				if( $this->form_validation->run() )
				{
					$exec	=	$this->lib->set_category( 
						$this->input->post( 'designation_category' ),
						$this->input->post( 'description_category' ), 
						$this->input->post( 'identifiant_parent' ),
						'create'
					);
					$exec == 'category-updated' ? module_location( array( 'category?notice=category-created' ) ) : null;
				}
				set_core_vars( 'categories' , $this->lib->get_category( null , null , 'name_asc' ) );
				
				set_page( 'title' , 'Nouvelle catégorie' );
			
				set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
				
				return module_view( 'views/category-new', false , 'nexo' );
			}
			else if( $page == 'edit' )
			{
				$this->load->library( 'form_validation' );
				$this->form_validation->set_rules( 'designation_category', __( 'Désignation categorie' ) , 'required' );
				$this->form_validation->set_rules( 'identifiant_parent' , __( 'Categorie Parent' ), 'numeric' );
				if( $this->form_validation->run() )
				{
					$exec	=	$this->lib->set_category( 
						$this->input->post( 'designation_category' ),
						$this->input->post( 'description_category' ), 
						$this->input->post( 'identifiant_parent' ),
						'edit',
						$arg2
					);
					$this->notice->push_notice( fetch_notice_output( $exec ) );
				}
				set_core_vars( 'categories' , $this->lib->get_category( null , null , $arg2 ) );
				set_core_vars( 'current_category' , farray( $this->lib->get_category( $arg2 , 'as_id' ) ) );
				
				set_page( 'title' , 'Modifier une catégorie' );
			
				set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
				
				return module_view( 'views/category-edit', false , 'nexo' );
			}
			else if( $page == 'delete' )
			{
				$exec	=	$this->lib->delete_category( $arg2 );
				module_location( array( 'category?notice=' . $exec ) );
			}
		}
		else
		{
			$nbr_cat	=	count( $this->lib->get_category() );
			$pagination	=	pagination_helper( 
				riake( 'category_pp' , $this->options , 10 ) ,
				$nbr_cat,
				$page,
				module_url( array( 'category' ) ),
				get_instance()->url->site_url( array( 'error' ,'code' ,'page-404' ) )
			);
			set_core_vars( 'pagination_data' , $pagination );
			// 
			$get_category	=	$this->lib->get_category( $pagination[ 'start' ] , $pagination[ 'end' ] , 0 , 'name_asc' );
			// $get_category	=	$this->lib->get_category( 'not-latest' );
			
			set_core_vars( 'category' , $get_category );							
			
			set_page( 'title' , 'Liste des catégories' );
		
			set_core_vars( 'left_menu' , $this->load->view( 'admin/left_menu' , array() , true ) );
			
			return module_view( 'views/category', false , 'nexo' );
		}
	}
	function remuneration_personnel( $page = 1 )
	{
		if( !is_numeric( $page ) )
		{
			if( $page == 'new' )
			{
				set_page( 'title' , 'Nouvelle rémunération' );
			
				return module_view( 'views/bill_payment-new', false , 'nexo' );
			}
		}
		else
		{
			
		}
	}
	function settings()
	{
		set_core_vars( 'roles' , get_instance()->roles->get() );
		set_page( 'title' , 'Reglages Nexo' );
		return module_view( 'views/settings' , false , 'nexo' );
	}
	function compta( $page = 'daily-selling-book' , $YEAR = 'DEFAULT' , $MONTH = 'DEFAULT' , $DAY = 'DEFAULT' )
	{
		if( $page === 'daily-selling-book' )
		{
			set_core_vars( 'YEAR' , $YEAR );
			set_core_vars( 'MONTH' , $MONTH );
			set_core_vars( 'DAY' , $DAY );
			
			set_page( 'title' , 'Journal de la caisse' );
			module_view( 'views/livre-journal-des-ventes' , false , 'nexo' );
		}
		if( $page === 'daily-patrimonial-book' )
		{
			set_core_vars( 'YEAR' , $YEAR );
			set_core_vars( 'MONTH' , $MONTH );
			set_core_vars( 'DAY' , $DAY );
			
			set_page( 'title' , 'Journal du patrimoine' );
			module_view( 'views/livre-journal-du-patrimoine' , false , 'nexo' );
		}
		if( $page === 'daily-de-l-exploitation' )
		{
			set_core_vars( 'YEAR' , $YEAR );
			set_core_vars( 'MONTH' , $MONTH );
			set_core_vars( 'DAY' , $DAY );
			
			set_page( 'title' , 'Journal de l\'exploitation' );
			module_view( 'views/livre-journal-de-l-exploitation' , false , 'nexo' );
		}
	}
}