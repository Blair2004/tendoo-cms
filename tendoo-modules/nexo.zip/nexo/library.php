<?php
class nexo_class
{
	private $category_legacy			=	array();
	function __construct()
	{
		module_include( 'third-library/codebar/barcodes.php' , 'nexo' );
		$this->db						=	get_db();
		$this->time						=	get_instance()->tdate;
		$this->notices();
		$this->datetime					=	$this->time->datetime();
		$this->user_id					=	current_user( 'ID' );
		$this->barcode					=	new DNS1DBarcode();
		$this->barcode->save_path		=	module_path( 'barcodes/' );
		$this->code_limitation			=	5;
		$this->codebar_type				=	'CODABAR';
		$this->options					=	get_meta( 'nexo_settings' );
		$this->morning					=	date( 'Y-m-d' , strtotime( $this->datetime ) ) . ' 00:00:00'; // For date like this Y-m-d h:is			
		$this->evening					=	date( 'Y-m-d' , strtotime( $this->datetime ) ) . ' 23:59:59';
	}
	function __special_update()
	{ 
		return;
		$query	=	$this->db->get( 'nexo_articles' );
		var_dump( count( $query->result_array() ));
		foreach( $query->result_array() as $_result )
		{
			// Get Product Code
			$query				=	$this->db->where( 'REF_ARTICLE' , riake( 'ID' , $_result ) )->get( 'nexo_code_barre' );
			$result				=	farray( $query->result_array() );
			var_dump( $result );
			// Get Articles Vars
			$this->db->insert( 'nexo_articles_relationship' , array(
				'REF_ARTICLE'		=>	riake( 'ID' , $_result ),
				'REF_SHIPPING'		=>	riake( 'REF_SHIPPING' , $_result ),
				'REF_CATEGORIE'		=>	riake( 'REF_CATEGORIE' , $_result ),
				'REF_RAYON'			=>	riake( 'REF_RAYON' , $_result ),
				'QUANTITY'			=>	riake( 'QUANTITY' , $_result ),
				'DEFECTUEUX'		=>	riake( 'DEFECTUEUX' , $_result ),
				'DATE_CREATION'		=>	riake( 'DATE_CREATION' , $_result ),
				'DATE_MODIFICATION'	=>	riake( 'DATE_MODIFICATION' , $_result ),
				'AUTHOR'			=>	riake( 'AUTHOR' , $_result ),
				'REF_CODE'			=>	riake( 'CODE' , $result )
			) );
		}
	}
	//
	function get_random_charges_id()
	{
		return array( 'impots' , 'achatmse' , 'clients' , 'factures' , 'matsamg' , 'admin' , 'faa' , 'rrr' , 'fourbur' , 'sav' , 'pressing' , 'pub' , 'eau' , 'electricite' , 'productdentretien' , 'fraisbanc' , 'internet' , 'emballages' );
	}
	function get_random_charges_label()
	{
		return array( __( 'Impôts' ) , __( 'Achat m/se' ) , __( 'Clientèle' ) , __( 'Factures' ) , __( 'Mat/Amg' ) , __( 'Admin' ) , __( 'FAA' ) , __( 'RRR' ) , __( 'Fourbur' ) , __( 'Services Après Vente' ) , __( 'Pressing' ) , __( 'Publicité' ) , __( 'Eau' ) , __( 'Electricité' ) , __( 'Produits D\'entretien' ) , __( 'Frais Bancaires' ) , __( 'Internet' ) , __( 'Emballages' ) );
	}
	function get_fixed_charges_id()
	{
		return array( 'loyer' , 'cabletv' , 'securitydak' );
	}
	function get_fixed_charges_label()
	{
		return array( __( 'Loyer' ), __( 'Cable Tv' ) , __( 'Securité DAK' ) );	
	}
	function get_all_charges_id()
	{
		return array_merge( $this->get_random_charges_id() , $this->get_fixed_charges_id() );
	}
	function get_all_charges_label()
	{
		return array_merge( $this->get_random_charges_label() , $this->get_fixed_charges_label() );
	}
	//
	function daily_report( $type , $date_start = null , $date_end = null )
	{
		if( $date_start == null )
		{
			$date_start				=	date( 'Y-m-d' , strtotime( $this->datetime ) );
			$date_start				.=	' 00:00:00'; // For date like this Y-m-d h:is			
		}
		if( $date_end == null )
		{
			$date_end				=	date( 'Y-m-d' , strtotime( $this->datetime ) ) . ' 23:59:59';
		}
		if( $type == 'recap-recettes' )
		{			
			return $factures				=	$this->get_commands( 'between' , $date_start , $date_end );
		}
		else if( $type == 'recap-bills' )
		{
			return $bills					=	$this->get_bill( 'between' , $date_start , $date_end );
		}
		return false;
	}
	/**
	 *
	**/
	function get_bondavoir_real_price( $bondavoir_id )
	{
		$bondavoir		=	farray( $this->get_bondavoir( $bondavoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			$command		=	farray( $this->get_commands( riake( 'REF_COMMAND' , $bondavoir ) , 'as_id' ) );
			if( $command )
			{
				$command_price	=	$this->get_command_real_price( riake( 'ID' , $command ) , 'as_id' , 'without_active_status' );
				return $command_price;
			}
		}
		return 0;
	}
	function get_bondavoir_client_reduction( $bon_davoir_id )
	{
		$bondavoir	=	farray( $this->get_bondavoir( $bon_davoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			return $command_price	=	$this->get_command_price( riake( 'REF_COMMAND' , $bondavoir ) , 'without_active_status' );
			// return $reduction		=	$this->get_reduction_for_client( riake( 'REF_CLIENT' , $bondavoir ) , $command_price );
			// La réduction pour un client est calculé une fois durant la création des commandes. La récupération de la valeur réelle d'une commande prendra en considération le champ "CHARGE" et non les réductions.
		}
		return 0;
	}
	function get_bondavoir_montant_brut( $bon_davoir_id )
	{
		$bondavoir	=	farray( $this->get_bondavoir( $bon_davoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			return $this->get_command_price( riake( 'REF_COMMAND' , $bondavoir ), 'as_id' , 'without_active_status' ); ;
		}
		return 0;
	}
	function count_product_from_bondachat( $bon_davoir_id , $produit_id )
	{
		$bondavoir	=	farray( $this->get_bondavoir( $bon_davoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			$command	=	farray( $this->get_commands( riake( 'REF_COMMAND' , $bondavoir ) , 'as_id' ) );
			$command_id	=	riake( 'ID' , $command );
			if( $command )
			{
				$count_product_from_command	=	$this->count_product_from_command( $command_id , $produit_id , true );
				return $count_product_from_command;
			}
			return 0;
		}
		return 0;
	}
	function get_bondavoir_price( $bondavoir_id ) // Deprecated
	{
		$bondavoir	=	farray( $this->get_bondavoir( $bondavoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			$command	=	farray( $this->get_commands( riake( 'REF_COMMAND' , $bondavoir ) , 'as_id' ) );
			if( $command )
			{
				$price	=	$this->get_command_price( riake( 'ID' , $command  ) );
				return $price;
			}
			return 0;
		}
		return 0;
	}
	function set_bondavoir( $command_id )
	{
		$bondav	=	farray( $this->get_bondavoir( $command_id , 'as_command_id' ) );
		if( ! $bondav )
		{
			$command					=	farray(  $this->get_commands( $command_id , 'as_id' ) );
			$array	=	array(
				'REF_COMMAND'			=>	$command_id,
				'DATE_CREATION'			=>	$this->datetime,
				'DATE_MODIFICATION'		=>	$this->datetime,
				'REF_CLIENT'			=>	riake( 'REF_CLIENT' , $command ),
				'AUTHOR'				=>	$this->user_id
			);
			$this->db->insert( 'bon_davoir' , $array );
			// Changing product Status
			$current_bondavoir			=	farray( $this->get_bondavoir( $command_id , 'as_command_id' ) );
			$array	=	array(
				'REF_BON_DAVOIR'	=>	riake( 'ID' , $current_bondavoir ),
				'STATUS'			=>	0 // set as unavailable
			);
			$this->db->where( 'REF_COMMANDE' , riake( 'ID' , $command ) )->update( 'nexo_commandes_ref_article' , $array );
			return 'bondav-set';
		}
		return 'bondav-already-exists-for-this-command';
	}
	function delete_bondavoir( $id )
	{
		$bondav	=	$this->get_bondavoir( $id , 'as_id' );
		if( $bondav )
		{
			$array	=	array(
				'STATUS'	=>	1
			);
			$this->db->where( 'REF_BON_DAVOIR' , $id )->update( 'nexo_commandes_ref_article' , $array );
			$this->db->where( 'ID' , $id )->delete( 'bon_davoir' );
			return 'bon-davoir-deleted';
		}
		return 'unknow-bon-davoir';
	}
	function get_bondavoir( $start_or_id = null , $filter_or_end = null )
	{
		$this->db->order_by( 'DATE_MODIFICATION' , 'desc' );
		if( is_numeric( $start_or_id ) && is_numeric( $filter_or_end ) )
		{
			$this->db->limit( $filter_or_end , $start_or_id );
		}
		else if( $filter_or_end == 'as_id' && $start_or_id != null )
		{
			$this->db->where( 'ID' , $start_or_id );
		}
		else if( $filter_or_end == 'as_command_id' && $start_or_id != null )
		{
			$this->db->where( 'REF_COMMAND' , $start_or_id );
		}
		else if( $filter_or_end == 'as_client_id' && $start_or_id != null )
		{
			$this->db->where( 'REF_CLIENT' , $start_or_id );
		}
		$query	=	$this->db->get( 'bon_davoir' );
		return $query->result_array();
	}
	/**
	 * 	CRON JOBS
	 * 	Supprime les factures autoamtiquement et etablie des bons d'avoir.
	**/
	function auto_delete_commands()
	{
	}
	/**
	 * 		Flux Input Output
	**/
	function set_flux( $type , $designation , $montant , $description , $mode = 'create' , $id = null )
	{
		$flux_type	= ( $type == 'input' ) ? 1 : 2;
		if( ! $this->flux_exists( $type , $designation , 'as_name' ) || ( ! $this->flux_exists( $id , 'as_id' ) && $mode == 'edit' ))
		{
			$array					=	array(
				'TITLE'				=>	$designation,
				'DESCRIPTION'		=>	$description,
				'MONTANT'			=>	$montant,
				'DATE_MODIFICATION'	=>	$this->datetime,
				'AUTHOR'			=>	$this->user_id
			);
			if( $mode == 'create' )
			{
				$array[ 'DATE_CREATION' ]	=	$this->datetime;
				$array[ 'TYPE' ]			=	$flux_type;
			}
			else
			{
				$this->db->where( 'TYPE' , $flux_type );
			}
			$mode == 'create' ? $this->db->insert( 'nexo_input_output' , $array ) : $this->db->where( 'ID' , $id )->update( 'nexo_input_output' , $array );
			return 'flux-successfully-set';
		}
		return 'flux-already-exists';
	}
	function get_flux( $type , $item = null, $filter = 'as_id' )
	{
		if( $type == 'input' )
		{
			$this->db->where( 'TYPE' , 1 );
		}
		else if( $type == 'output' )
		{
			$this->db->where( 'TYPE' , 2 );
		}
		if( $item === 'previous-to' )
		{
			$this->db->where( 'DATE_CREATION <=' , $filter );
		}
		if( $item === 'as_date_asc' )
		{
			$this->db->where( 'DATE_CREATION >=' , $filter );
		}
		else if( is_numeric( $item ) && is_numeric( $filter ) )
		{ 
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $filter , $item );
		}
		else if( $filter == 'as_id' && $item != null )
		{
			$this->db->where( 'ID' , $item );
		}
		else if( $filter == 'as_name' && $item != null )
		{
			$this->db->where( 'TITLE' , $item );
		}
		$query	=	$this->db->get( 'nexo_input_output' );
		return $query->result_array();
	}
	function flux_exists( $type , $item , $filter = 'as_id' )
	{
		return $this->get_flux( $type , $item , $filter );
	}
	function delete_flux( $id )
	{
		$exec	=	$this->db->where( 'ID' , $id )->delete( 'nexo_input_output' );
		return 'flux-deleted';
	}
	/**
	 * 		Commandes
	**/
	function set_commandes( $client_id , $reduction_expresse , $command_amount , $montant_avance , $products_relation_ids , $payment_type , $mode = 'create' , $id = null )
	{
		
		if( $montant_avance >= $command_amount ) // Commande Doit
		{
			$command_type	=	1;
		}
		else if( $montant_avance < $command_amount && $montant_avance != 0 )// Command Avance
		{
			$command_type	=	2;
		}
		else // Commande Devis
		{
			$command_type	=	3;
		}
		if( is_array( $products_relation_ids ) )
		{
			$error_count				=	0;
			$final_product_relation_id	=	array();
			foreach( $products_relation_ids as $key	=> &$product_relation_id )
			{
				$splited	=	explode( '|' , $product_relation_id );
				if( $this->product_exists( $splited[0] , 'as_relation_id' ) )
				{
					$final_product_relation_id[]	=	$product_relation_id;
				}
				else
				{
					$error_count++;
				}
			}
		}
		else
		{
			return 'require-product';
		}
		$command_code			=	$this->get_command_code();
		
		$array		=	array(
			'REF_CLIENT'		=>		$client_id,
			'CODE'				=>		$command_code,
			'TYPE'				=>		$command_type,
			'DATE_MODIFICATION'	=>		$this->datetime,
			'AUTHOR'			=>		$this->user_id,
			'PAYMENT_TYPE'		=>		$payment_type,
			'CHARGE'			=>		( int ) $reduction_expresse
		);
		// 
		$mode == 'create' ?	$array[ 'DATE_CREATION' ] = $this->datetime : null;
		$mode == 'create' ?	$this->db->insert( 'nexo_commandes' , $array ) : $this->db->where( 'ID' , $id )->update( 'nexo_commandes' , $array );
		// Geting product
		$commande_query			=		$this->db->where( 'CODE' , $command_code )->get( 'nexo_commandes' );
		$commande				=		$commande_query->result_array();
		// Filling Commandes vars
		$command_vars			=	array(
			'REF_COMMAND_ID'	=>	$commande[0][ 'ID' ],
			'DATE_CREATION'		=>	$this->datetime,
			'AVANCE'			=>	$montant_avance,
			'AUTHOR'			=>	$this->user_id
		);
		$this->db->insert( 'nexo_commandes_ref_vars' , $command_vars );
		// Deleting product to refill
		$this->db->where( 'REF_ARTICLE' , $commande[0][ 'ID' ] )->delete( 'nexo_commandes_ref_article' );
		foreach( $final_product_relation_id as $_pid )
		{
			// 
			$_id_exploded	=	explode( '|' , $_pid );
			$saved_product_data			=	0;
			for( $i = 0 ; $i < (int) $_id_exploded[1]; $i++ )
			{
				if( $_id_exploded[0] != $saved_product_data )
				{
					$final_product		=	farray( $this->get_product( $_id_exploded[0] , 'as_relation_id' ) ); // Fix unique product handled
					$saved_product_data	=	$_id_exploded[0];
				}
				else
				{
					echo 'ERREUR DIE'; die;
				}
				$this->db->insert( 'nexo_commandes_ref_article' , array(
					'REF_ARTICLE'	=>	riake( 'ARTICLE_ID' , $final_product ),
					'REF_COMMANDE'	=>	$commande[0][ 'ID' ],
					'REF_RELATION'	=>	riake( 'RELATION_ID' , $final_product ),
					'STATUS'		=>	1 // Set status 1 (active) per default
				) );
			}
		}	
		$command_amount			=	$this->get_command_price( $command_code , 'as_code' );
		$charge					=	$this->get_reduction_for_client( $client_id , $command_amount );	
		$this->db->where( 'CODE' , $command_code )->update( 'nexo_commandes' , array(
			'CHARGE'			=>	$reduction_expresse + $charge // Reduction Expresse Plus Charge RRR
		) );
		return 'commands-successfully-done';
	}
	function command_payment_type( $code )
	{
		if( $code == 1 )
		{
			return 'Espèce';
		}
		else if( $code == 2 )
		{
			return 'Virement';
		}
		else if( $code == 3 )
		{
			return 'Carte Bancaire';
		}
		else if( $code == 4 )
		{
			return 'MTN Mobile Money';
		}
		else if( $code == 5 )
		{
			return 'Orange Money';
		}
	}
	function get_command_price( $item , $filter = 'as_id' , $filter2 = 'with_active_status' ) // Avec reduction
	{
		$check_product_status	=	( $filter2 == 'with_active_status' ) ? true : false;
		if( $filter == 'as_code' )
		{
			$command	=	farray( $this->get_commands( $item , 'as_code' ) );
			$products	=	$this->get_products_in_commands( $command[ 'ID' ] , $check_product_status );
			$price		=	0;
			foreach( $products as $_product )
			{
				$price += 	$this->get_product_selling_price( riake( 'REF_ARTICLE' , $_product ) , riake( 'ID',  $command ) );
			}
			// Prise ne charge des réduction expresses
			return $price - riake( 'CHARGE' , $command );
		}
		else if( $filter == 'as_id' )
		{
			$command	=	farray( $this->get_commands( $item , 'as_id' ) );
			$products	=	$this->get_products_in_commands( $command[ 'ID' ] , $check_product_status );
			// var_dump( $products );
			$price		=	0;
			foreach( $products as $_product )
			{
				$price += 	$this->get_product_selling_price( riake( 'REF_ARTICLE' , $_product ) , riake( 'ID',  $command ) );
			}
			// Prise ne charge des réduction expresses
			return $price - riake( 'CHARGE' , $command );
		}
		return 0;
	}
	function get_command_real_price( $item , $filter = 'as_id' , $filter2 = 'with_active_status' ) // Sans reduction
	{
		$command	=	farray( $this->get_commands( $item , $filter ) );
		$price	=	$this->get_command_price( $item , $filter , $filter2 );
		// $charge	=	$this->get_reduction_for_client( riake( 'REF_CLIENT' , $command ) , $price );
		//	- $charge
		// La réduction offerte à un client est calculé en même temps que la commande. Pour évider d'appliquer une réduction permanente.
		// - riake( 'CHARGE' , $command )
		// La réduction s'applique uniquement à get_command_price
		return $price + riake( 'CHARGE' , $command ); // On annule la reduction
	}
	function get_reduction_for_client( $client_id , $current_command_amount )
	{
		$required_product	=	riake( 'client_promo' , $this->options );
		if( ( int )$required_product > 0 )
		{
			$nbr_command	=	count( $this->get_commands( $client_id , 'as_client_for_active_command' ) );
			if( $nbr_command >= $required_product )
			{
				if( between( 1 , 100 , ( $percent = riake( 'pormo_percent' , $this->options ) ) ) )
				{
					return ( $current_command_amount * $percent ) / 100;
				}
				return 0;
			}
			return 0;
		}
		return 0;
	}
	function get_products_in_commands( $pid , $check_status = true , $filter = 'as_command' ) // Double Compta Ready
	{
		if( $check_status ) : 	$this->db->where( 'STATUS' , 1 ); endif;
		
		if( $filter === 'as_command' )
		{
			$query	=	$this->db->where( 'REF_COMMANDE' , $pid )->get( 'nexo_commandes_ref_article' );
		}
		else if( $filter === 'as_product' )
		{
			$query	=	$this->db->where( 'REF_ARTICLE' , $pid )->get( 'nexo_commandes_ref_article' );
		}
		else if( $filter === 'as_relation' )
		{

			$query	=	$this->db->where( 'REF_RELATION' , $pid )->get( 'nexo_commandes_ref_article' );
		}
		$result	=	$query->result_array();
		// Double Compta
		$double_compta		=	riake( 'double_compta' , $this->options , 0 );
		if( between( 1 , 100 , $double_compta ) )
		{
			$nbr_product	=	count( $result );
			$limit_product	=	ceil( ( $nbr_product * $double_compta ) / 100 ); 
			$fictive_list	=	array();
			for( $i = 0 ; $i < $limit_product ; $i++ )
			{
				$fictive_list[] =	$result[ $i ];
			}
			$result		=	$fictive_list; // Changin array result.
		}
		return $result;
	}
	function add_to_cart_conditional_test( $id )
	{
		$articles	=	$this->get_product( $id , 'as_code' , 'sum' );
		$_articles	=	farray( $articles );
		if( ! $articles )
		{
			return json_encode( array(
				'msg'		=>		'Article introuvable ou code incorrect.',
				'return'	=>		false
			) );
		}
		// Count if product can be added to cart again
		else if( ( ( int )riake( 'QUANTITY' , $_articles , 0 ) - ( int )riake( 'DEFECTUEUX' , $_articles , 0 ) ) - count( $this->get_products_in_commands( $_articles[ 'ARTICLE_ID' ] , true , 'as_product' ) )  > riake( 'nbr' , $_GET , 0 ) )
		{
			return json_encode( $articles , JSON_FORCE_OBJECT );
		}
		else
		{
			return json_encode( array(
				'msg'		=>		'Impossible d\'ajouter le produit. Le stock est épuisé',
				'return'	=>		false
			) );
		}
	}
	function get_commands( $start_or_id = null, $end_or_filter = null , $extra_param = null , $extra_param2 = null )
	{
		$this->db->select( '
			*,
			nexo_commandes_ref_vars.AVANCE	as AVANCE,
			nexo_commandes.ID as ID,
			nexo_commandes_ref_vars.ID as COMMAND_REF_VARS_ID'
		);
		
		$this->db->join( 'nexo_commandes_ref_vars' , 'nexo_commandes_ref_vars.REF_COMMAND_ID = nexo_commandes.ID' , 'LEFT' );
				
		if( $extra_param2 === 'doit' )
		{
			$this->db->where( 'nexo_commandes.TYPE' , 1 ); // Since 1 means "facture-doit"
		}
		if( $extra_param2 === 'exclude_devis' )
		{
			$this->db->where( 'nexo_commandes.TYPE !=' , 3 ); // Since 3 means "facture-devis"
		}
		if( is_numeric( $start_or_id ) && is_numeric( $end_or_filter ) )
		{
			$this->db->order_by( 'nexo_commandes.DATE_MODIFICATION' , 'desc' )->limit( $end_or_filter , $start_or_id );
		}
		else
		{
			if( $end_or_filter == 'as_id' )
			{
				$this->db->where( 'nexo_commandes.ID' , $start_or_id );
			}
			else if( $end_or_filter == 'as_code' )
			{
				$this->db->where( 'CODE' , $start_or_id );
			}
			else if( $start_or_id == 'previous-to' )
			{
				$this->db->where( 'nexo_commandes.DATE_CREATION <=' , $end_or_filter );
			}
			else if( $end_or_filter == 'as_date_asc' )
			{
				$this->db->where( 'nexo_commandes.DATE_CREATION >=' , $start_or_id );
			}
			else if( $start_or_id == 'between' && $end_or_filter != null && $extra_param != null )
			{
				$this->db->where( 'nexo_commandes.DATE_CREATION >=' , $end_or_filter );
				$this->db->where( 'nexo_commandes.DATE_CREATION <=' , $extra_param );
			}
			else if( $end_or_filter == 'as_type' )
			{
				$this->db->where( 'TYPE' , $start_or_id );
			}
			else if( $end_or_filter == 'as_client' )
			{
				$this->db->where( 'REF_CLIENT' , $start_or_id );
			}
			else if( $end_or_filter == 'as_client_for_active_command' )
			{
				$this->db->where( 'TYPE' , 1 );
				$this->db->where( 'nexo_commandes.REF_CLIENT' , $start_or_id );
			}
		}
		$query	=	$this->db->get( 'nexo_commandes' );
		return $query->result_array();
	}
	function get_command_code()
	{
		return 
			date( 'Y' , strtotime( $this->datetime ) ) . 
			date( 'd' , strtotime( $this->datetime ) ) . 
			date( 'H' , strtotime( $this->datetime ) ) . 
			date( 'm' , strtotime( $this->datetime ) ) . 
			date( 's' , strtotime( $this->datetime ) ) .
			rand( 0 , 9 ) . 
			rand( 0 , 9 );
	}
	function get_distinct_from_command( $command_id , $ignore_status = false )
	{
		$this->db->distinct();
		$this->db->select( 'REF_ARTICLE' );
		$this->db->where( 'REF_COMMANDE' , $command_id );
		if( $ignore_status == false )
		{
			$this->db->where( 'STATUS' , 1 );
		}
		$query	=	$this->db->get( 'nexo_commandes_ref_article' );
		$result	=	$query->result_array();
		// Double Compta
		$double_compta		=	riake( 'double_compta' , $this->options , 0 );
		if( between( 1 , 100 , $double_compta ) )
		{
			$nbr_product	=	count( $result );
			$limit_product	=	ceil( ( $nbr_product * $double_compta ) / 100 ); 
			$fictive_list	=	array();
			for( $i = 0 ; $i < $limit_product ; $i++ )
			{
				$fictive_list[] =	$result[ $i ];
			}
			$result		=	$fictive_list; // Changin array result.
		}
		return $result;
	}
	function count_product_from_command( $command_id , $product_id , $ignore_status = false ) // Double compta Ready
	{
		if( $ignore_status == false )
		{
			$this->db->where( 'STATUS' , 1 ); // Get only active product
		}
		$this->db->where( 'REF_COMMANDE' , $command_id )->where( 'REF_ARTICLE' , $product_id );
		$query	=	$this->db->get( 'nexo_commandes_ref_article' );
		$result	=	$query->result_array();
		// Double Compta
		$double_compta		=	riake( 'double_compta' , $this->options , 0 );
		if( between( 1 , 100 , $double_compta ) )
		{
			$nbr_product	=	count( $result );
			$limit_product	=	ceil( ( $nbr_product * $double_compta ) / 100 ); 
			$fictive_list	=	array();
			for( $i = 0 ; $i < $limit_product ; $i++ )
			{
				$fictive_list[] =	$result[ $i ];
			}
			$result		=	$fictive_list; // Changin array result.
		}
		return count( $result );
	}
	function delete_command( $command_id )
	{
		$command = $this->get_commands( $command_id , 'as_id' );
		if( $command )
		{
			$this->db->where( 'REF_COMMANDE' , $command[0][ 'ID' ] )->delete( 'nexo_commandes_ref_article' );
			$this->db->where( 'ID' , $command[0][ 'ID' ] )->delete( 'nexo_commandes' );
			$this->db->where( 'REF_COMMAND_ID' , $command[0][ 'ID' ] )->delete( 'nexo_commandes_ref_vars' );
			return 'command-deleted';
		}
		return 'unknow-command';
	}
	/**
	 * 		Recupérer le solde de la caisse pour une opération
	**/
	function get_cash( $arg	= 'default' , $date = null )
	{
		$cash	=	0;
		if( $arg === 'default' )
		{
			$facture_dachats	=	$this->get_bill();
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands();
			foreach( $get_commands as $_command )
			{
				$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) );
			}
			$flux_input			=	$this->get_flux( 'input' );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'real' )
		{
			$facture_dachats	=	$this->get_bill();
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands();
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
				else if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) );
				}
			}
			$flux_input			=	$this->get_flux( 'input' );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'real-today' )
		{
			$facture_dachats	=	$this->get_bill( 'between' , $this->morning , $this->evening );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( $this->morning , 'as_date_asc' );
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
				else if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) );
				}
			}
			$flux_input			=	$this->get_flux( 'input' , 'as_date_asc' , $this->morning );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , 'as_date_asc' , $this->morning );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'real-today-without-discounts' )
		{
			$facture_dachats	=	$this->get_bill( 'between' , $this->morning , $this->evening );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( $this->morning , 'as_date_asc' );
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
				else if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_real_price( riake( 'ID' , $_command ) , 'as_id' ) );
				}
			}
			$flux_input			=	$this->get_flux( 'input' , 'as_date_asc' , $this->morning );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , 'as_date_asc' , $this->morning );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'real-today-without-entree-extra' )
		{
			$facture_dachats	=	$this->get_bill( 'between' , $this->morning , $this->evening );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( $this->morning , 'as_date_asc' );
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
				else if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) );
				}
			}
		}
		if( $arg === 'entree-extra-today' )
		{
			$flux_input			=	$this->get_flux( 'input' , 'as_date_asc' , $this->morning );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , 'as_date_asc' , $this->morning );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'facture-doit' )
		{
			$get_commands		=	$this->get_commands();
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) );
				}
			}
		}
		if( $arg === 'facture-doit-today' )
		{
			$get_commands		=	$this->get_commands( $this->morning , 'as_date_asc' );
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) );
				}
			}
		}
		if( $arg === 'facture-avance' )
		{
			$get_commands		=	$this->get_commands();
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
			}
		}
		else if( $arg === 'facture-avance-today' )
		{
			$get_commands		=	$this->get_commands( $this->morning , 'as_date_asc' );
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
			}
		}
		else if( $arg === 'previous-to' )
		{
			$facture_dachats	=	$this->get_bill( $arg , $date );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs(riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( $arg , $date );
			foreach( $get_commands as $_command )
			{
				$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) ) - ( int ) riake( 'CHARGE' , $_command );
			}
			$flux_input			=	$this->get_flux( 'input' , $arg , $date );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , $arg , $date );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		else if( $arg === 'previous-to-without-discounts' )
		{
			$facture_dachats	=	$this->get_bill( $arg , $date );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs(riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( 'previous-to' , $date );
			foreach( $get_commands as $_command )
			{
				// Sans prendre en considération les factures devis
				if( riake( 'TYPE' , $_command ) == 1 )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) );
				}	
				else if( riake( 'TYPE' , $_command ) == 2 )
				{
					$cash	+= (  riake( 'AVANCE' , $_command ) );
				}
			}
			$flux_input			=	$this->get_flux( 'input' , 'previous-to' , $date );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , 'previous-to' , $date );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		else if( $arg === 'previous-to-with-discounts' )
		{
			$facture_dachats	=	$this->get_bill( $arg , $date );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs(riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( 'previous-to' , $date );
			foreach( $get_commands as $_command )
			{
				// Sans prendre en considération les factures devis
				if( riake( 'TYPE' , $_command ) == 1 )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) );
				}	
				else if( riake( 'TYPE' , $_command ) == 2 )
				{
					$cash	+= (  riake( 'AVANCE' , $_command ) );
				}		
			}
			$flux_input			=	$this->get_flux( 'input' , 'previous-to' , $date );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , 'previous-to' , $date );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		return $cash;
	}
	/**
	 * 		Providers
	**/
	function create_providers( $name , $bp , $cellphone , $email , $mode = 'create' , $id = 0 )
	{
		$user_id			=	current_user( 'ID' );
		$datetime			=	$this->time->datetime();
		if( $mode == 'create' )
		{
			if( ! $this->provider_exists( $name , 'as_name' ) )
			{
				$this->db->insert( 'nexo_fournisseurs' , array(
					'NOM'		=>		$name,
					'BP'		=>		$bp,
					'TEL'		=>		$cellphone,
					'EMAIL'		=>		$email,
					'DATE_CREATION'	=>	$datetime,
					'DATE_MODIFICATION'	=>	$datetime,
					'AUTHOR'	=>		$user_id
				) );
				return 'provider-created';
			}
			return 'provider-already-exists';
			
		} else if ( $mode == 'edit' ) {
			if( ! $this->provider_exists( $name , 'as_name' , $id ) )
			{
				$this->db->where( 'ID' , $id )->update( 'nexo_fournisseurs' , array(
					'NOM'			=>		$name,
					'BP'			=>		$bp,
					'TEL'			=>		$cellphone,
					'EMAIL'			=>		$email,
					'DATE_MODIFICATION'	=>	$datetime,
					'AUTHOR'		=>		$user_id
				) );
				return 'provider-updated';
			}
			return 'provider-already-exists';
		}
	}
	function delete_provider( $id )
	{
		if( $this->provider_exists( $id , 'as_id' ) )
		{
			$provider			=	$this->get_providers( $id , 'as_id' );
			// Log
			$this->log_actions( current_user( 'PSEUDO' ) , 'supprimé le fournisseur ' . $provider[0][ 'NOM' ] , $this->time->datetime() );
			// Return
			return $this->db->where( 'ID' , $id )->delete( 'nexo_fournisseurs' ) ? 'provider-deleted' : 'error_occured' ;
		}
		return 'error_occured';
	}
	function provider_exists( $name , $filter = 'as_name' , $exclude = 0 )
	{
		if( $exclude != null )
		{
			$query	=	$this->db->where( 'NOM' , $name )->where( 'ID !=' , $exclude )->get( 'nexo_fournisseurs' );
			return $query->result_array() ? true : false;
		}
		return $this->get_providers( $name , $filter ) == true ? true : false;
	}
	function get_providers( $name = null , $end = 'as_name' )
	{
		if( is_numeric( $name ) && is_numeric( $end ) )		{ 
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $end , $name );
		} else if( $name != null ){	
			if( $end == 'as_id' ){
				$this->db->where( 'ID' , $name );		
			} else if( $end == 'as_name' ){
				$this->db->where( 'NOM' , $name );		
			}
		}
		$query	= 	$this->db->get( 'nexo_fournisseurs' );
		return $query->result_array();
	}
	/**
	 * 		Shipping Functions
	**/
	function create_shipping( $name , $provider  , $description , $mode = 'create' , $id = 0 ) // Ok
	{
		if( $mode == 'create' ){
			if( ! $this->shipping_exists( $name , 'as_name' ) && $this->provider_exists( $provider , 'as_id' ) ){
				$exec	=	$this->db->insert( 'nexo_arrivages' , array(
					'TITRE'			=>	$name,
					'DESCRIPTION'	=>	$description,
					'DATE_CREATION'	=>	$this->datetime,
					'DATE_MODIFICATION'	=>	$this->datetime,
					'AUTHOR'		=>	$this->user_id,
					'FOURNISSEUR_REF_ID'	=>	$provider
				) );
				return $exec ? 'shipping-created' : 'error-occured';
			} 
			return 'shipping-already-exists-or-unknow-provider';
		} else if( $mode == 'edit' ){
			if( ! $this->shipping_exists( $name , 'as_name' , $id ) && $this->provider_exists( $provider , 'as_id' ) ){
				$exec	=	$this->db->where( 'ID' , $id )->update( 'nexo_arrivages' , array(
					'TITRE'					=>	$name,
					'DESCRIPTION'			=>	$description,
					'DATE_MODIFICATION'		=>	$this->datetime,
					'AUTHOR'				=>	$this->user_id,
					'FOURNISSEUR_REF_ID'	=>	$provider
				) );
				return $exec ? 'shipping-updated' : 'error-occured';
			} 
			return 'shipping-already-exists-or-unknow-provider';
		}
	}
	function shipping_exists( $name , $filter = 'as_name' , $exclude = 0 )
	{
		if( $exclude != null )
		{
			$query	=	$this->db->where( 'TITRE' , $name )->where( 'ID !=' , $exclude )->get( 'nexo_arrivages' );
			return $query->result_array() ? true : false;
		}
		else
		{
			return $this->get_shipping( $name , $filter ) ? true : false;
		}
	}
	function get_shipping( $name = null , $end = 'as_name' )
	{
		if( is_numeric( $name ) && is_numeric( $end ) )	{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $end , $name );
		} else if( $name != null ) {
			if( $end == 'as_id' ){
				$this->db->where( 'ID' , $name );
			} else if( $end ==  'as_name' ){
				$this->db->where( 'TITRE' , $name );
			} else if( $end == 'as_excluded_id' ){
				$this->db->where( 'ID !=' , $name );
			} 
		}
		$query	=	$this->db->get( 'nexo_arrivages' );
		return $query->result_array();
	}
	function get_shippings_products( $shippings )
	{
		$final_list			=	array();
		foreach( force_array( $shippings ) as $_shipping )
		{
			$new_product	=	$this->get_product( riake( 'ID' , $_shipping ) , 'as_shipping' );
			$final_list		=	array_merge( $final_list , $new_product );
		}
		return $final_list;
	}
	function delete_shipping( $id )
	{
		if( $this->shipping_exists( $id , 'as_id' ) )
		{
			$this->db->where( 'ID' , $id )->delete( 'nexo_arrivages' );
			return 'shipping-deleted';
		}
		return 'unknow-shipping';
	}
	//
	function get_shipping_worth( $ship_id , $before_date = null )
	{
		$his_products		=	$this->get_product( $ship_id , 'as_shipping' );
		if( $before_date == null )
		{

		}
		else
		{
			var_dump( $his_products );
		}
	}
	function get_shipping_products_worth( $shipping_id , $univers_id )
	{
		if( ! isset( $this->category_legacy[ $univers_id ] ) )
		{
			$this->category_legacy[ $univers_id ]	=	$this->get_category_legacy( $univers_id );
		}
		$categories		=	$this->category_legacy[ $univers_id ];
		
		if( $categories )
		{
			$final_price		=	0;
			foreach( force_array( $categories ) as $cat )
			{
				$products		=	$this->get_product( array(
					'category_id'	=>	$cat,
					'shipping_id'	=>	$shipping_id
				) , 'as_category_and_shipping' );
				foreach( force_array( $products ) as $_product )
				{
					$ca			=	riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product );
					$pv			=	$ca * riake( 'TAUX_DE_MARGE' , $_product );
					$pvG		=	$pv * ( riake( 'QUANTITY' , $_product ) - riake( 'DEFECTUEUX' , $_product ) );
					$final_price+=	$pvG;
				}
			}
			return $final_price;
		}
		return 0;
	}
	/** 
	 * 		Rayons Functions
	**/
	function set_rayon( $name , $description , $mode = 'create' , $id = 0 )
	{
		if( $mode == 'create' )
		{
			if( ! $this->rayon_exists( $name , 'as_name' ) )
			{
				return $this->db->insert( 'nexo_rayons' , array(
					'TITRE'				=>	$name,
					'DESCRIPTION'		=>	$description,
					'DATE_CREATION'		=>	$this->datetime,
					'DATE_MODIFICATION'	=>	$this->datetime,
					'AUTHOR'			=>	$this->user_id
				) ) ? 'rayon-has-been-created' : 'error-occured';
			}
		}
		else if( $mode == 'edit' )
		{
			if( ! $this->rayon_exists( $name , 'as_name' , $id ) )
			{
				return $this->db->where( 'ID' , $id )->update( 'nexo_rayon' , array(
					'TITRE'				=>	$name,
					'DESCRIPTION'		=>	$description,
					'DATE_MODIFICATION'	=>	$this->datetime,
					'AUTHOR'			=>	$this->user_id
				) ) ? 'rayon-has-been-edited' : 'error-occured';
			}
		}
		return 'unable-to-create-or-edit-rayon';
	}
	function rayon_exists( $name , $filter = 'as_name' , $exclude = 0 )
	{
		if( $exclude == null )
		{
			return	$this->get_rayons( $name , $filter );
		}
		else 
		{
			$this->db->where( 'ID !=' , $exclude );
			$query	=	$this->db->where( 'TITRE' , $name )->get( 'nexo_rayons' );
			return $query->result_array();
		}
	}
	function get_rayons( $name = null, $filter_or_end = 'as_name' )
	{
		if( $filter_or_end == 'as_name' && $name != null )
		{
			$this->db->where( 'TITRE' , $name );
		}
		else if( $filter_or_end == 'as_id' && $name != null )
		{
			$this->db->where( 'ID' , $name );
		}
		else if( is_numeric( $name ) && is_numeric( $filter_or_end ) )
		{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $filter_or_end , $name );
		}
		$query	=	$this->db->get( 'nexo_rayons' );
		return $query->result_array();
	}
	function delete_rayons( $name_or_id , $filter )
	{
		if( $rayon	=	$this->rayon_exists( $name_or_id , $filter ) )
		{
			if( $filter == 'as_name' )
			{
				$exec	= $this->db->where( 'TITRE' , $name_or_id )->delete( 'nexo_rayons' );
			}
			else if( $filter == 'as_id' )
			{
				$exec	= $this->db->where( 'ID' , $name_or_id )->delete( 'nexo_rayons' );
			}
			return $exec ? 'rayon-has-been-deleted' : 'error-occurred';
		}
		return 'error-occured';
	}
	/**
	 *  	Product Function
	**/
	function set_product( $name , $arrivage_id , $prix_ttc , $cout_unitaire , $category_id , $rayon_id , $shipping_id , $taille , $couleur , $quantity , $prix_dachat , $frais_accessoires , $taux_marge , $taux_solde , $defectueux ,  $enable_discount , $mode  = 'create' , $id = 0 )
	{
		if( ( int ) $quantity < ( int )$defectueux ) : return 'quantity-error'; endif;
		if( ! $this->product_exists( $name , 'as_name' ) || ( ! $this->product_exists( $name , 'as_id' , $id ) && $mode == 'edit' ) )
		{
			$save_product	=	$this->product_exists( $name , 'as_name' ) ? 
				$this->product_exists( $name , 'as_name' ) : 
				$this->product_exists( $name , 'as_relation_id' , $id );
			$save_product	=	farray( $save_product );
			if( is_numeric( $frais_accessoires ) && is_numeric( $taux_marge ) && is_numeric( $quantity ) )
			{
				if( 
					$this->shipping_exists( $arrivage_id , 'as_id' ) && 
					$this->category_exists( $category_id , 'as_id' ) &&
					$this->rayon_exists( $rayon_id , 'as_id' ) 
				)
				{
					$return					=	'product-has-been-created';
					$data	=	 array(
						'DESIGN'			=>	ucwords( $name ),
						'TAILLE'			=>	$taille,
						'COULEUR'			=>	$couleur,
						'AUTHOR'			=>	$this->user_id,
						'DATE_MODIFICATION'	=>	$this->datetime,
					);
					// var_dump( $category_id );die;
					$relationship			=	array(
						'QUANTITY'			=>	$quantity >= 1 ? $quantity : 0,
						'DEFECTUEUX'		=>	$defectueux >= 1 ? $defectueux : 0,
						'REF_CATEGORIE'		=>	$category_id,
						'REF_RAYON'			=>	$rayon_id,
						'REF_SHIPPING'		=>	$shipping_id,
						'REF_ARTICLE'		=>	0, // Sera défini plus tard dans le meme script
						'AUTHOR'			=>	$this->user_id,
						'DATE_MODIFICATION'	=>	$this->datetime,
						'TYPE'				=>	1 // En attendant de savoir si l'utilisation d'un type est approprié
					);
					$vars	=	array(
						'PRIX_DACHAT'		=>	$prix_dachat,
						'FRAIS_ACCESSOIRES'	=>	$frais_accessoires,
						'TAUX_DE_MARGE'		=>	$taux_marge,
						'TAUX_SOLDE'		=>	$taux_solde,
						'DATE_MODIFICATION'	=>	$this->datetime,
						'DATE_CREATION'		=>	$this->datetime, // Pour ce cas spécialement, puisque les données antérieures ne peuvent pas être modifiée
						'AUTHOR'			=>	$this->user_id,
						'ENABLE_DISCOUNT'	=>	$enable_discount
					);
					// Creating Code Bar
					if( $mode == 'create' )
					{
						$data[ 'DATE_CREATION' ] = $this->datetime;
						$this->db->insert( 'nexo_articles' , $data );
						///  
						$latest					=	farray( $this->__get_latest_product() );
						$vars[ 'REF_ARTICLE' ]	=	riake( 'ID' , $latest ) ;
						$this->db->insert( 'nexo_articles_vars' , $vars );
						/// Définition du code barre
						$code_data				=	$this->generate_code();
						/// Sauvegarde des données de la relation
						$relationship[ 'DATE_CREATION' ]	=	$this->datetime;
						$relationship[ 'REF_ARTICLE' ]		=	riake( 'ID' , $latest );
						$relationship[ 'REF_CODE' ]			=	riake( 'CODE' , $code_data );
						$this->db->insert( 'nexo_articles_relationship' , $relationship );
						$latest_relation		=	farray( $this->__get_product_relationship( $relationship[ 'REF_CODE' ] , 'as_product_code' ) ); 
						/// Création d'un code
						$get_relation			=	$this->__get_product_relationship( array(
							'product_id' 		=>	riake( 'ID' , $latest ) , 
							'shipping_id'		=>	riake( 'REF_SHIPPING' , $latest_relation ),
						) , 'as_product_and_shipping_id' );
						
						$get_relation			=	farray( $get_relation );
						$creation				=	$this->set_code( $code_data , riake( 'ID' , $latest ) , riake( 'ID' , $get_relation ) );
						// Return
						return $return;
					}
					/**
						Edit mode 
					**/
					else
					{
						$vars[ 'REF_ARTICLE' ]				=	riake( 'ID' , $save_product ) ;
						$relationship[ 'DATE_CREATION' ]	=	$this->datetime;
						$relationship[ 'REF_ARTICLE' ]		=	riake( 'ID' , $save_product );
						$this->db->where( 'ID' , riake( 'ID' , $save_product ) )->update( 'nexo_articles' , $data );
						// 
						// Si la précédente livraison attaché au produit correspond a la nouvelle, alors il s'agit d'une modification simple du stock
						if( riake( 'REF_SHIPPING' , $relationship ) == riake( 'REF_SHIPPING' , $save_product ) )
						{
							$this->db->where( 'REF_ARTICLE' , riake( 'ID' , $save_product ) )->where( 'REF_SHIPPING' , riake( 'REF_SHIPPING', $save_product ) )
							->update( 'nexo_articles_relationship' , $relationship );
							$return 	=	'stock-updated';
						}
						// Sinon il s'agit d'un approvisionnement du stock
						else
						{
							$code_data							=	$this->generate_code();
							$relationship[ 'REF_CODE' ]			=	riake( 'CODE' , $code_data );							
							$this->db->insert( 'nexo_articles_relationship' , $relationship );
							// Nouveau code barre pour un produit provenant d'un stock different
							$relation							=	$this->__get_product_relationship( $relationship[ 'REF_CODE' ] , 'as_product_code' );
							/// Création d'un code
							$creation							=	$this->set_code( $code_data , riake( 'ID' , $save_product ) , riake( 'ID' , farray( $relation ) ) );							
							/// Affectation d'un nouveau codebarre
							$return 	=	'stock-added';
						}
						// Inserting Data vars
						$this->db->insert( 'nexo_articles_vars' , $vars );
					}					
					return $return;
				}
				return 'unable-to-find-meta-data';
			}			
			return 'numeric-value-required';	
		}
		return 'product-exists';
	}
	function get_product( $name = null , $filter_or_end = 'as_name' , $filter_2 = 'distinct' , $filter_3 = 'date_desc' )
	{		
		// 	nexo_code_barre.ID as CODEBAR_ID, 
		//  Le filtre 2 ne peux pas être choisi avec certains filtre 1
		if( $filter_2 === 'sum' )
		{
			$this->db->select( 
				'*,
				nexo_articles.ID as ARTICLE_ID,
				nexo_articles.DATE_MODIFICATION as DATE_MODIFICATION,
				nexo_articles.DATE_CREATION as DATE_CREATION,
				nexo_articles.ID as ID,
				nexo_articles_relationship.REF_CATEGORIE as REF_CATEGORIE,
				nexo_articles_relationship.REF_SHIPPING as REF_SHIPPING,	
				nexo_articles_relationship.QUANTITY as QUANTITY,
				nexo_articles_relationship.DEFECTUEUX as DEFECTUEUX,			
				nexo_articles_relationship.ID as RELATION_ID,			
				nexo_articles_relationship.ID as REF_RELATION
				' 
			);
			$this->db->group_by( 'nexo_articles.ID' );
		}
		else
		{
			$this->db->select( 
				'*,
				nexo_articles.ID as ARTICLE_ID,
				nexo_articles.DATE_MODIFICATION as DATE_MODIFICATION,
				nexo_articles.DATE_CREATION as DATE_CREATION,
				nexo_articles.ID as ID,
				nexo_articles_relationship.REF_CATEGORIE as REF_CATEGORIE,
				nexo_articles_relationship.REF_SHIPPING as REF_SHIPPING,	
				nexo_articles_relationship.QUANTITY as QUANTITY,
				nexo_articles_relationship.DEFECTUEUX as DEFECTUEUX,			
				nexo_articles_relationship.ID as RELATION_ID,			
				nexo_articles_relationship.ID as REF_RELATION
					
				' 
			);
		}
		$this->db->from( 'nexo_articles' );
		$this->db->join( 'nexo_code_barre' , 'nexo_articles.ID = nexo_code_barre.REF_ARTICLE' , 'left' );
		$this->db->join( 'nexo_articles_relationship' , 'nexo_code_barre.REF_ARTICLE_RELATIONSHIP = nexo_articles_relationship.ID AND `'.DB_ROOT.'nexo_code_barre`.`CODE` = `'.DB_ROOT.'nexo_articles_relationship`.`REF_CODE`' , 'left' );
		$this->db->join( 'nexo_categories' , 'nexo_articles_relationship.REF_CATEGORIE = nexo_categories.ID' , 'left' );
				
		if( $filter_3 === 'date_desc' )
		{
			$this->db->order_by( 'nexo_articles.DATE_MODIFICATION' , 'desc' );
		}
		else if( $filter_3 === 'category_asc' )
		{
			$this->db->order_by( 'nexo_categories.NOM' , 'asc' );
		}
		else if( $filter_3 === 'id_asc' )
		{
			$this->db->order_by( 'nexo_articles.ID' , 'asc' );
		}
		else if( $filter_3 === 'id_desc' )
		{
			$this->db->order_by( 'nexo_articles.ID' , 'desc' );
		}
		else if( $filter_3 == 'category_desc' )
		{
			$this->db->order_by( 'nexo_categories.NOM' , 'desc' );
		}
		else if( $filter_3 == 'name_asc' )
		{
			$this->db->order_by( 'nexo_articles.DESIGN' , 'asc' );
		}
		else if( $filter_3 == 'name_desc' )
		{
			$this->db->order_by( 'nexo_articles.DESIGN' , 'desc' );
		}
		// First Filter	
		if( $filter_or_end === 'as_id' && $name != null )
		{
			$this->db->where( 'nexo_articles.ID' , $name );
		}
		else if( $filter_or_end === 'as_code' && $name != null )
		{
			$this->db->where( 'nexo_code_barre.CODE' , $name );
		}
		else if( $filter_or_end === 'as_relation_id' && $name != null )
		{
			$this->db->where( 'nexo_articles_relationship.ID' , $name );
		}
		else if( $filter_or_end === 'as_name' && $name != null )
		{
			$this->db->where( 'DESIGN' , $name );
		}
		else if( $filter_or_end === 'as_name_low_case' && $name != null )
		{
			$this->db->where( 'LCASE(DESIGN)' , strtolower( $name ) );
		}
		else if( $filter_or_end === 'as_category_and_shipping' && $name != null )
		{
			$this->db->where( 'nexo_articles_relationship.REF_CATEGORIE' , riake( 'category_id' , $name ) );
			if( riake( 'shipping_id' , $name ) )
			{
				$this->db->where( 'nexo_articles_relationship.REF_SHIPPING' , riake( 'shipping_id' , $name ) );
			}
		}
		else if( $filter_or_end === 'as_category_and_shipping_before_command_date' && $name != null )
		{
			// dont display if product isn't bound to a selling
			$this->db->join( 'nexo_commandes_ref_article' , 'nexo_articles.ID = nexo_commandes_ref_article.REF_ARTICLE' , 'inner'); 
			$this->db->join( 'nexo_commandes'	, 'nexo_commandes_ref_article.REF_COMMANDE = 	 nexo_commandes.ID' , 'inner' );
			
			$this->db->where( 'nexo_articles_relationship.REF_CATEGORIE' , riake( 'category_id' , $name ) );
			if( riake( 'shipping_id' , $name ) )
			{
				$this->db->where( 'nexo_articles_relationship.REF_SHIPPING' , riake( 'shipping_id' , $name ) );
			}
			$this->db->where( 'nexo_commandes.DATE_CREATION <' , riake( 'date' , $name ) );
		}
		else if( $filter_or_end === 'as_category_and_shipping_sold_between' && $name != null )
		{
			// dont display if product isn't bound to a selling
			$this->db->select( 'nexo_commandes.ID as COMMAND_ID' );
			$this->db->join( 'nexo_commandes_ref_article' , 'nexo_articles.ID = nexo_commandes_ref_article.REF_ARTICLE' , 'inner'); 
			$this->db->join( 'nexo_commandes'	, 'nexo_commandes_ref_article.REF_COMMANDE = 	 nexo_commandes.ID' , 'inner' );
			if( riake( 'shipping_id' , $name ) )
			{
				$this->db->where( 'nexo_articles_relationship.REF_SHIPPING' , riake( 'shipping_id' , $name ) );
			}
			$this->db->where( 'nexo_articles_relationship.REF_CATEGORIE' , riake( 'category_id' , $name ) );
			$this->db->where( 'nexo_commandes.DATE_CREATION >' , riake( 'start_date' , $name ) );
			$this->db->where( 'nexo_commandes.DATE_CREATION <' , riake( 'end_date' , $name ) );
			$this->db->where( 'nexo_commandes.TYPE !=' , 3 ); // Skip Devis
		}
		else if( $filter_or_end === 'as_category_and_before_shipping' && $name != null )
		{
			$this->db->where( 'nexo_articles_relationship.REF_CATEGORIE' , riake( 'category_id' , $name ) );
			$this->db->where( 'nexo_articles_relationship.REF_SHIPPING <' , riake( 'shipping_id' , $name ) );
			$this->db->where( 'nexo_articles_relationship.REF_SHIPPING !=' , riake( 'shipping_id' , $name ) );
		}
		else if( $filter_or_end === 'as_shipping' && $name != null )
		{
			$this->db->where( 'nexo_articles_relationship.REF_SHIPPING' , $name );
		}
		else if( $filter_or_end === 'as_category' && $name != null ) // Warning
		{
			$this->db->where( 'nexo_articles_relationship.REF_CATEGORIE' , $name );
		}
		else if( is_numeric( $name ) && is_numeric( $filter_or_end ) )
		{
			$this->db->limit( $filter_or_end , $name );
		}
		$query	=	$this->db->get();
		// Getting Vars
		$array	=	$query->result_array();
		// La recupération des données récentes d'un produit n'est pas activé si la requete fait des comparaison dans le temps
		foreach( $array as $key => $value )
		{
			$query	=	$this->db->where( 'REF_ARTICLE' , $value[ 'ARTICLE_ID' ] )->order_by( 'DATE_MODIFICATION' , 'desc' )->get( 'nexo_articles_vars' );
			$data	=	$query->result_array();
			
			// Récupération du dernier prix d'actualité
			$latest	=	farray( $data );
			$array[ $key ][ 'PRIX_DACHAT' ]			=	riake( 'PRIX_DACHAT' , $latest );
			$array[ $key ][ 'FRAIS_ACCESSOIRES' ]	=	riake( 'FRAIS_ACCESSOIRES' , $latest );
			$array[ $key ][ 'TAUX_DE_MARGE' ]		=	riake( 'TAUX_DE_MARGE' , $latest );
			$array[ $key ][ 'TAUX_SOLDE' ]			=	riake( 'TAUX_SOLDE' , $latest );
			$array[ $key ][ 'ENABLE_DISCOUNT' ]		=	riake( 'ENABLE_DISCOUNT' , $latest );
			
			/**
				Il est préférable que chaque ligne de produit affiche ses informations et non celles regroupées.
			**/
			if( $filter_2 == 'sum' ) // Only While Sum is enabled
			{
				// getting stock data
				// Recupération unique selon les arrivages.
				if( $filter_or_end == 'as_shipping' && true == false )// Disabled
				{
					$this->db->where( 'REF_SHIPPING' , $name );
				}
			
				$query	=	$this->db
					->where( 'REF_ARTICLE' , $value[ 'ARTICLE_ID' ] )
					->order_by( 'DATE_MODIFICATION' , 'desc' )
					->get( 'nexo_articles_relationship' );
				$relationship_result	=	$query->result_array();
				$latest	=	farray( $relationship_result );
				$array[ $key ][ 'REF_RAYON' ]			=	riake( 'REF_RAYON' , $latest );
				$array[ $key ][ 'REF_CATEGORIE' ]		=	riake( 'REF_CATEGORIE' , $latest );
				$array[ $key ][ 'REF_SHIPPING' ]		=	riake( 'REF_SHIPPING' , $latest );
				$array[ $key ][ 'ENABLE_DISCOUNT' ]		=	riake( 'ENABLE_DISCOUNT' , $latest );
				// Counting Quantity over the time and shippings
				if( ! in_array( $filter_or_end , array( 'as_category_and_shipping' , 'as_category_and_before_shipping' ) , TRUE ) ) 
				{
					$array[ $key ][ 'QUANTITY' ]			=	0;
					$array[ $key ][ 'DEFECTUEUX' ]			=	0;
					foreach( $relationship_result as $relationship )
					{
						// var_dump( $relationship );
						$array[ $key ][ 'QUANTITY' ]			+=	( int ) riake( 'QUANTITY' , $relationship );
						$array[ $key ][ 'DEFECTUEUX' ]			+=	( int ) riake( 'DEFECTUEUX' , $relationship );
						/** 
						if( riake( 'TYPE' , $relationship ) == 1 )
						{
							$array[ $key ][ 'QUANTITY' ]			+=	( int ) riake( 'QUANTITY' , $relationship );
							$array[ $key ][ 'DEFECTUEUX' ]			+=	( int ) riake( 'DEFECTUEUX' , $relationship );
							//var_dump( $array[ $key ] );
						}
						else
						{
							$array[ $key ][ 'QUANTITY' ]			-=	( int ) riake( 'QUANTITY' , $relationship );
							$array[ $key ][ 'DEFECTUEUX' ]			-=	( int ) riake( 'DEFECTUEUX' , $relationship );
						}
						**/
					}
				}
			}
		}
		return $array;
	}
	function __get_product_vars( $product_id , $filter = 'as_product_id' )
	{
		if( $filter == 'as_product_id' )
		{
			$query	=	$this->db->where( 'REF_ARTICLE' , $product_id )->get( 'nexo_articles_vars' );
			return $query->result_array();
		}
		return false;
	}
	function __get_latest_product()
	{
		$sub_query 				=	$this->db->order_by( 'ID' , 'desc' )->limit( 1 , 0 )->get( 'nexo_articles' );
		$latest					=	$sub_query->result_array();
		return $latest;
	}
	function __get_categories( $id = null )
	{
		if( $id == null )
		{
			$categories 	=	$this->get_category( 'only_parents' , null , 0 , 'name_asc' );
		}
		else
		{		
			$categories 	=	$this->get_category( $id , 'as_parent' , 0 , 'name_asc' );
		}
		foreach( $categories as $key => $_category )
		{
			$_sub_category	=	$this->__get_categories( riake( 'ID' , $_category ) );
			$categories[ $key ][ 'SUB_CATEGORY' ]	=	$_sub_category;
		}
		return $categories;
	}
	private 	$e	=	0;
	function get_category_legacy( $category_id )
	{
		if( is_numeric( ( int ) $category_id ) && ! is_array( $category_id ) ) 
		{
			$parent				=	$this->__get_categories( $category_id );
			if( $parent )
			{				
				$first_chils	=	$this->get_category( $category_id , 'as_parent' );
				$the_legacy		=	array( $category_id );
				$the_legacy		=	array_merge( $the_legacy , $this->get_category_legacy( $first_chils ) );
				return $the_legacy;
			}
		}
		else if( is_array( $category_id ) && count( $category_id ) > 0 )
		{
			$final_result		=	array();
			foreach( force_array( $category_id ) as $_cat )
			{
				array_push( $final_result , riake( 'ID' , $_cat ) ); // Ajoute l'identifiant du parent				
				
				$childs			=	$this->get_category( riake( 'ID' , $_cat ) , 'as_parent' );
				if( $childs ) // S'il y a des enfants
				{
					$final_result	=	array_merge( $final_result , $this->get_category_legacy( $childs ) );
				}
			}
			return $final_result;
		}
		return array(); // Means FALSE
	}
	function __get_category_products( $category_array , $filter = '' )
	{
		foreach( $category_array as $key => $_category )
		{
			// Si une catégorie n'a pas d'enfant on recupère ses produits
			
			if( count( riake( 'SUB_CATEGORY' , $_category ) ) > 0 )
			{
				$category_array[ $key ][ 'SUB_CATEGORY' ]	=	$this->__get_category_products( $category_array[ $key ][ 'SUB_CATEGORY' ] , $filter );
			}
			else
			{
				$category_array[ $key ][ 'PRODUCTS' ] 		= 	$this->get_product_related( 'category' , riake( 'ID' , $_category ) , $filter );
			}
		}
		return $category_array;
	}
	function __get_latest_category( $category_array = null )
	{
		if( $category_array == null )
		{
			$category_array	=	$this->__get_categories();
		}
		$latest_categories		=	array();
		foreach( $category_array as $key => $_category )
		{
			if( count( riake( 'SUB_CATEGORY' , $_category ) ) > 0 && is_array( riake( 'SUB_CATEGORY' , $_category  ) ) )
			{
				$category_array[ $key ][ 'SUB_CATEGORY' ]	=	$this->__get_category_products( $category_array[ $key ][ 'SUB_CATEGORY' ] );
			}
		}
		$latest_categories	=	$this->__extract_latest_category( $category_array );
		return $latest_categories;
	}
	function __extract_latest_category( $categories_array )
	{
		$merged_category		=	array();
		foreach( $categories_array as $category )
		{
			if( riake( 'SUB_CATEGORY' , $category ) )
			{
				$merged_category	=	array_merge( $merged_category , $this->__extract_latest_category( $category[ 'SUB_CATEGORY' ] ) );
			}
			else
			{
				$merged_category	=	array_merge( $merged_category , array( $category ) );
			}
		}
		return $merged_category;
	}
	function get_product_related( $item , $element = 'optional' , $filter = '' ) // Not Yet Ready
	{
		if( $item === 'rayon' )
		{
			$this->db->select('*,
				nexo_articles_relationship.REF_RAYON
			');
			// $this->db->group_by( array( 'REF_RAYON' , 'REF_CATEGORY' , 'REF_ARTICLE' ) );
			$this->db->join( 'nexo_articles_relationship' , 'nexo_articles.ID = nexo_articles_relationship.REF_ARTICLE' );
			$this->db->where( 'nexo_articles_relationship.REF_RAYON' , $element );
			$query		=	$this->db->get( 'nexo_articles' );
			return $query->result_array();
		}
		else if( $item === 'categories' )
		{
			$categories	=	$this->__get_categories( $item );
			$categories	=	$this->__get_category_products( $categories , $filter );
			
			return ( $categories );
		}
		else if( $item == 'category' )
		{
			return $this->get_product( $element , 'as_category' , $filter );
		}
		
	}
	function get_product_inside_big_category( $array )
	{
		$final_array =	array();
		foreach( force_array( $array ) as $category )
		{
			$final_array[ riake( 'NOM' , $category ) ]	=	$this->__join_products( array( $category ) );
		}
		return $final_array;
	}
	private function __join_products( $array )
	{
		$cart	=	array();
		foreach( $array as $_ar )
		{
			if( riake( 'PRODUCTS' , $_ar ) )
			{
				$cart	=	array_merge( $cart , riake( 'PRODUCTS' , $_ar ) );
			}
			else if( is_array( riake( 'SUB_CATEGORY' , $_ar ) ) && count( riake( 'SUB_CATEGORY' , $_ar ) ) > 0 )
			{
				$cart	=	array_merge( $cart , $this->__join_products( riake( 'SUB_CATEGORY' , $_ar ) ) );
			}
		}
		return $cart;
	}
	function product_exists( $name , $filter = 'as_id' , $exclude = 0 )
	{
		return $this->get_product( $name , $filter );
	}
	// Recupère les données d'un produit à une date précise
	function get_product_selling_price( $product_id , $command_id = 'optional' )
	{
		if( $command_id !== 'optional' )
		{
			$command	=	farray( $this->get_commands( $command_id , 'as_id' ) );
			if( ! $command ): return 0; endif;
			$date		=	riake( 'DATE_CREATION' , $command );
		}
		else
		{
			$date		=	null;
		}
		
		if( is_array( $product_id ) )
		{
			$product_vars	=	farray( $this->get_product_vars( riake( 'ID' , $product_id ) , 'as_id' , $date  ) );
			
			return ( riake( 'PRIX_DACHAT' , $product_vars ) + riake( 'FRAIS_ACCESSOIRES' , $product_vars ) ) * riake( 'TAUX_MARGE' , $product_vars );
		}
		else if( is_numeric( $product_id ) )
		{
			$product	=	farray( $this->get_product( $product_id , 'as_id' ) );
			
			if( ! is_numeric( $command_id ) ) // If command id is no set
			{
				return ( riake( 'PRIX_DACHAT' , $product ) + riake( 'FRAIS_ACCESSOIRES' , $product ) ) * riake( 'TAUX_DE_MARGE' , $product );
			}
			
			if( ! $product ) : return 0; endif;
			
			$product_vars	=	farray( $this->get_product_vars( $product_id , 'as_id' , $date ) );

			return ( riake( 'PRIX_DACHAT' , $product_vars ) + riake( 'FRAIS_ACCESSOIRES' , $product_vars ) ) * riake( 'TAUX_DE_MARGE' , $product_vars );
		}
	}
	function get_product_vars( $product_id , $filter = 'as_id' , $where_date_is_under = null )
	{
		$produit	=	farray( $this->get_product( $product_id , $filter ) );		
		
		$this->db->order_by( 'DATE_CREATION' , 'desc' );
		
		if( $where_date_is_under != null ) : $this->db->where( 'DATE_MODIFICATION <' , $where_date_is_under ); endif;

		// $query		=	$this->db->where( 'ID' , riake( 'ID' , $produit ) )->get( 'nexo_articles_vars' ); // bug fix : Retreive from  REF_ARTICLE (remove)
		$query		=	$this->db->where( 'REF_ARTICLE' , riake( 'ID' , $produit ) )->get( 'nexo_articles_vars' ); // 
		
		return $query->result_array();
	}
	function delete_product( $id )
	{
		if( $this->product_exists( $id ,'as_id' ) )
		{
			$product	=	farray( $this->get_product( $id , 'as_id' ) );
			// Supprime le codebar
			if( is_file( $file_path	=	riake( 'FILE_PATH' , $product ) ) )
			{
				unlink( $file_path );
				$this->db->where( 'REF_ARTICLE' , $id )->delete( 'nexo_code_barre' );
				$this->db->where( 'REF_ARTICLE' , $id )->delete( 'nexo_articles_vars' );
				$this->db->where( 'REF_ARTICLE' , $id )->delete( 'nexo_articles_relationship' );
			}
			// 
			if( $this->db->where( 'ID' , $id )->delete( 'nexo_articles' ) )
			{
				return 'product-deleted';
			}
			return 'error-occured';
		}
		return 'unknow-product';
	}
	function __get_product( $id , $filter = 'as_category' )
	{
		if( $filter == 'as_category' )
		{
			$this->db->where( 'REF_CATEGORIE' , $id );
		}
		else if( $filter == 'as_id' )
		{
			$this->db->where( 'REF_CATEGORIE' , $id );
		}
		$query	=	$this->db->get( 'nexo_articles' );
		return $query->result_array();		
	}
	function refresh_codebar( $products_list )
	{
		if( is_array( $products_list ) )
		{
			foreach( force_array( $products_list ) as $product )
			{
				// Delete Previous Codebar
				if( is_file( $file = module_path( 'barcodes/' . riake( 'CODE' , $product ) , 'nexo' ) . '.png' ) )
				{
					unlink( $file );
				}
				$this->delete_code( riake( 'CODE' , $product ) );
				// Refreshing
				$code_data					=	$this->generate_code();
				$product_relationship		=	$this->__get_product_relationship(  riake( 'CODE' , $product ) , 'as_product_code' ); 
				$ref_product_relationship	=	riake( 'ID' , farray( $product_relationship ) );
				// Creating Code
				$creation					=	$this->set_code( 
					$code_data , 
					riake( 'ID' , $product ) , 
					$ref_product_relationship , 
					'edit' , 
					riake( 'CODE' , $product ) 
				);
			}
			return 'product-code-refreshed';
		}
		return 'only-array-is-supported';
	}
	function __get_product_relationship( $product_id , $filter = 'as_product_id' )
	{
		if( $filter == 'as_product_id' )
		{
			$query	=	$this->db->where( 'REF_ARTICLE' , $product_id )->get( 'nexo_articles_relationship' );
			return $query->result_array();
		}
		if( $filter == 'as_id' )
		{
			$query	=	$this->db->where( 'ID' , $product_id )->get( 'nexo_articles_relationship' );
			return $query->result_array();
		}
		else if( $filter == 'as_product_and_shipping_id' )
		{
			$query	=	$this->db
					->where( 'REF_ARTICLE' , riake( 'product_id' , $product_id ) )
					->where( 'REF_SHIPPING' , riake( 'shipping_id' , $product_id ) )
					->get( 'nexo_articles_relationship' );
			return $query->result_array();
		}
		else if( $filter === 'as_product_code' )
		{
			$query	=	$this->db->where( 'REF_CODE' , $product_id )->get( 'nexo_articles_relationship' );
			return $query->result_array();
		}
	}
	function get_products_sold_before_a_date( $shipping_id , $univers , $date )
	{
		$products	=	array();
		$legacy	=	$this->get_category_legacy( $univers );
		if( $legacy )
		{
			foreach( $legacy as $_legacy )
			{
				$_products	=	$this->get_product( array(
					'shipping_id'		=>		$shipping_id,
					'category_id'		=>		$_legacy,
					'date'				=>		$date
				) , 'as_category_and_shipping_before_command_date' );
				if( $_products )
				{
					$products[]		=	farray( $_products );
				}
			}
			return $products;
		}
		return false;
	}
	function get_products_price_sold_before_a_date( $shipping_id , $univers , $date )
	{
		$products	=	$this->get_products_sold_before_a_date( $shipping_id , $univers , $date );
		if( $products )
		{
			$price	=	0;
			foreach( $products as $_product )
			{
				$price	+=	$this->get_product_selling_price( riake( 'ARTICLE_ID' , $_product ) );
			}
			return $price;
		}
		return 0;
	}
	function get_products_price_between_a_date( $shipping_id , $univers , $date_start , $date_end )
	{
		$products	=	array();
		if( ! isset( $this->category_legacy[ $univers ] ) )
		{
			$this->category_legacy[ $univers ]	=	$this->get_category_legacy( $univers );
		}
		$legacy	=	$this->category_legacy[ $univers ];
		if( $legacy )
		{
			$array			=		array(
				'start_date'		=>		$date_start,
				'end_date'			=>		$date_end
			);
			if( $shipping_id != false )
			{
				$array[ 'shipping_id' ]	=	$shipping_id;
			}
			foreach( $legacy as $_legacy )
			{
				$array[ 'category_id' ]	=	$_legacy;
								
				$_products	=	$this->get_product( $array , 'as_category_and_shipping_sold_between' );	
						
				if( $_products )
				{
					$products[]		=	farray( $_products );
				}
			}
			return $products;
		}
		return false;
	}
	function get_products_price_sold_between_a_date( $shipping_id , $univers , $date_start , $date_end )
	{
		$price		=	0;
		$products	=	$this->get_products_price_between_a_date( $shipping_id , $univers , $date_start , $date_end );
		foreach( force_array( $products ) as $_product )
		{
			$price	+=	$this->get_product_selling_price( riake( 'ARTICLE_ID' , $_product ) , riake( 'COMMAND_ID' , $_product ) );
		}
		return $price;
	}
	/**
	 * 		Category Functions
	**/
	function set_category( $name , $description , $parent , $mode = 'create' , $id = 0 )
	{
		if( $name == $parent ): return 'hierarchy-error'; endif;
		if( ! $this->category_exists( $name , 'as_name' ) || ! $this->category_exists( $name , 'as_name' , $id ) )
		{
			if( $this->category_exists( $parent , 'as_id' ) || $parent == 0 )
			{
				$array	=	array( 
					'NOM'				=>	$name,
					'DESCRIPTION'		=>	$description,
					'AUTHOR'			=>	$this->user_id,
					'DATE_MODIFICATION'	=>	$this->datetime,
					'PARENT_REF_ID'		=>	$parent
				);
				( $mode == 'create' ) ? $array[ 'DATE_CREATION' ] = $this->datetime : null;
				( $mode == 'create' ) ? $this->db->insert( 'nexo_categories' , $array ) : $this->db->where( 'ID' , $id )->update( 'nexo_categories' , $array );
				return 'category-updated';
			}
			return 'parent-category-unknow';
		}
		return 'categoy-name-already-taken';
	}
	function category_exists( $name , $filter , $exclude = 0 )
	{
		// for exclude statement
		$query	=	$this->db->where( 'ID !=' , $exclude )->where( 'NOM' , $name )->get( 'nexo_categories' );
		return $exclude == null ? $this->get_category( $name , $filter ) : $query->result_array();
	}
	function get_latest_category()
	{
		
	}
	function get_category( $name_or_start = null , $filter_or_end = null , $exclude = 0 , $order_by = null )
	{
		if( $name_or_start === 'only_parents' )
		{
			$this->db->where( 'PARENT_REF_ID' , 0 );
		}
		else if( $order_by == null )
		{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' );
		}
		else if( $order_by == 'name_asc' )
		{
			$this->db->order_by( 'NOM' , 'asc' );
		}
		else if( $order_by == 'name_desc' )
		{
			$this->db->order_by( 'NOM' , 'desc' );
		}

		is_numeric( $exclude ) && $exclude != 0 ? $this->db->where( 'ID !=' , $exclude ) : null; // excluding if exclude is provided
		
		if( is_numeric( $name_or_start ) && is_numeric( $filter_or_end ) )
		{
			$this->db->limit( $filter_or_end , $name_or_start );
		}
		else if( is_string( $filter_or_end ) )
		{
			$filter_or_end === 'as_id' 		? $this->db->where( 'ID' , $name_or_start ) : null;
			$filter_or_end === 'as_name' 	? $this->db->where( 'NOM' , $name_or_start ) : null;
			$filter_or_end === 'as_parent' 	? $this->db->where( 'PARENT_REF_ID' , $name_or_start ) : null;
		}
		$query			=	$this->db->get( 'nexo_categories' );
		$query_array	=	$query->result_array();
		if( $name_or_start === 'not-latest' )
		{
			foreach( $query_array as $key	=>	$_category )
			{
				if( ! $this->get_category( riake( 'ID' , $_category ) , 'as_parent' ) )
				{
					unset( $query_array[ $key ] );
				}
			}
		}
		else if( $name_or_start === 'only-latest' )
		{
			foreach( $query_array as $key	=>	$_category )
			{
				if( $this->get_category( riake( 'ID' , $_category ) , 'as_parent' ) )
				{
					unset( $query_array[ $key ] );
				}
			}
		}
		return $query_array;
	}
	function delete_category( $id )
	{
		return 
		$this->category_exists( $id , 'as_id' ) 
			? 	$this->db->where( 'ID' , $id )->delete( 'nexo_categories' ) 
				?	'category-deleted' : 'error-occured' 
			: 'unknow-category';
	}
	/**
	 * 	Generate Code Barre
	**/
	function generate_code()
	{
		do {
			$code	=	$this->randomize_code( $this->code_limitation );
		}
		while( $this->code_exists( $code ) );
		
		return array(
			'FILE_PATH'	=>	$this->barcode->getBarcodePNGPath( $code , $this->codebar_type ),
			'CODE'		=>	$code
		);
	}
	/**
	 * Créer un code bar et enregistrement dans la base de donnée
	**/
	function set_code( $code_data , $ref_article , $ref_article_relationship , $mode = 'create' , $previous_code = null )
	{
		if( ! $this->code_exists( $code_data[ 'CODE' ] ) && $this->product_exists( $ref_article , 'as_id' ) )
		{
			if( $mode == 'edit' )
			{
				$get_relation	=	$this->__get_product_relationship( $previous_code , 'as_product_code' );
				if( $get_relation )
				{
					$this->db->where( 'REF_CODE' , $previous_code )->update( 'nexo_articles_relationship' , array(
						'REF_CODE'						=>	$code_data[ 'CODE' ],
						'DATE_MODIFICATION'				=>	$this->datetime,
						'AUTHOR'						=>	$this->user_id
					) );
				}
			}
			return $this->db->insert( 'nexo_code_barre' , array(
				'CODE'						=>	$code_data[ 'CODE' ],
				'FILE_PATH'					=>	$code_data[ 'FILE_PATH' ],
				'REF_ARTICLE'				=>	$ref_article,
				'REF_ARTICLE_RELATIONSHIP'	=>	$ref_article_relationship,
				'DATE_CREATION'				=>	$this->datetime,
				'AUTHOR'					=>	$this->user_id
			) );

		}
		return 'code-bar-creation-failed';
	}
	/**
	 * Client fonctions
	 *
	**/
	function get_clients( $start = null , $end = null )
	{
		if( is_numeric( $start ) && is_numeric( $end ) )
		{
			$this->db->order_by( 'REG_DATE' , 'desc' )->limit( $start , $end );
		}
		$clients	=	get_instance()->roles->get_users_with_role( riake( 'client_privilege' , $this->options ) );
		return $clients;
	}
	function set_client( $email = '' , $pseudo = '' , $mode = 'create' , $id = null )
	{
		$pseudo		=	'CLIENT-' . count( $this->get_clients() ) . rand( 0 , 9 ) . rand( 0 , 9 ) . rand( 0 , 9 ) . rand( 0 , 9 ) . rand( 0 , 9 );
		if( $email == '' || $email === false )
		{
			$email	=	$pseudo. '@tendoo.org';
		}
		$password	=	'nexo-client-password';
		$client_privilege	=	riake( 'client_privilege' , $this->options );
		if( $client_privilege )
		{		
			if( $mode == 'create' )
			{
				return	current_user()->createAdmin(
					$pseudo,
					$password,
					'MASC',
					$client_privilege,
					$email,
					'TRUE'
				);
			} else {
				$client	=	get_user( $id , 'as_id' );
				return current_user()->setAdminPrivilege(
					$client_privilege,
					$client[ 'PSEUDO' ],
					$email
				);
			}
		}
		return 'set-role-id-first';
	}
	/**
	 * Verifie si un cod existe
	**/
	function code_exists( $code )
	{
		$query	=	$this->db->where( 'CODE' , $code )->get( 'nexo_code_barre' );
		return $query->result_array();
	}
	function delete_code( $code )
	{
		return $this->db->where( 'CODE' , $code )->delete( 'nexo_code_barre' );
	}
	function randomize_code( $limit = 5 )
	{
		$code = '';
		for( $i = 0 ; $i < $limit ; $i++ )
		{
			$code	.= rand(0,9);
		}
		return $code;
	}
	/**
	 * 	Factures d\'achats
	**/
	function set_bill( $raison , $description , $montant , $nature , $ref , $mode = 'create' , $id = null )
	{
		$montant	=	abs( $montant );
		if( ! $this->bill_exists( $raison , 'as_name' ) OR $this->bill_exists( $id , 'as_id' ) )
		{
			if( - $montant + $this->get_cash( 'real' ) < 0 )
			{
				return 'not-enough-cash';
			}
			$array	=	array(
				'TITLE'				=>	$raison,
				'DESCRIPTION'		=>	$description,
				'MONTANT'			=>	$montant,
				'REF'				=>	$ref,
				'NATURE_SOCIALE'	=>	$nature,
				'DATE_MODIFICATION'	=>	$this->datetime,
				'AUTHOR'			=>	$this->user_id
			);
			( $mode == 'create' ) 
				? 	$array[ 'DATE_CREATION' ] = $this->datetime 
				: 	null;
			$exec	=	( $mode == 'edit' ) 
				?	$this->db->where( 'ID' , $id )->update( 'nexo_factures_dachats' , $array ) 
				:	$this->db->insert( 'nexo_factures_dachats' , $array );			
			return $exec ? 'bill-set' : 'error-occured';
		}
		return 'bill-already-exists';
	}
	function delete_bill( $id )
	{
		if( $this->bill_exists( $id , 'as_id' ) )
		{
			$exec 	=	$this->db->where( 'ID' , $id )->delete( 'nexo_factures_dachats' );
			return $exec ? 'bill-deleted' : 'error-occured';
		}
		return 'unknow-bill';
	}
	function bill_exists( $id_or_name , $filter )
	{
		return $this->get_bill( $id_or_name , $filter );
	}
	function get_bill( $start_or_id = null , $end_or_filter = 'as_id' , $extra_param = null )
	{
		if( is_numeric( $start_or_id ) && is_numeric( $end_or_filter ) )
		{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $end_or_filter , $start_or_id );
		}
		else if( $start_or_id != null )
		{
			if( $end_or_filter == 'as_id' )
			{
				$this->db->where( 'ID' , $start_or_id );
			}
			else if( $start_or_id == 'between' && $extra_param != null )
			{
				$this->db->where( 'DATE_CREATION >=' , $end_or_filter )->where( 'DATE_CREATION <=' , $extra_param );
			}
			else if( $start_or_id == 'previous-to' && $end_or_filter != null )
			{
				$this->db->where( 'DATE_CREATION <=' , $end_or_filter );
			}
			else if( $end_or_filter == 'as_name' )
			{
				$this->db->where( 'TITLE' , $start_or_id );
			}
			else if( $end_or_filter == 'as_ref' )
			{
				$this->db->where( 'REF' , $start_or_id );
			}
			else if( $end_or_filter == 'as_ref_and_previous_to' )
			{
				$this->db->where( 'REF' , riake( 'ref' , $start_or_id ) );
				$this->db->where( 'DATE_CREATION <=' , riake( 'date' , $end_or_filter ) );
			}
			else if( $end_or_filter == 'as_ref_and_between' )
			{
				$this->db->where( 'REF' , riake( 'ref' , $start_or_id ) );
				$this->db->where( 'DATE_CREATION >=' , riake( 'start_date' , $start_or_id ) );
				$this->db->where( 'DATE_CREATION <=' , riake( 'end_date' , $start_or_id ) );
			}
		}
		$query	=	$this->db->get( 'nexo_factures_dachats' );
		return $query->result_array();
	}
	/**
	 * 		Log Functions
	**/
	function log_actions( $user , $has_done , $on )
	{
		// waiting. user %s has done this action %s on %s
		
	}
	function notices()
	{
	}
	function money_format($val,$symbol='',$r=2)
	{
		$n = $val; 
		$c = is_float($n) ? 1 : number_format($n,$r);
		$d = ',';
		$t = ',';
		$sign = ($n < 0) ? '-' : '';
		$i = $n=number_format(abs($n),$r,',','.'); 
		$j = ( ( $j = strlen($i) ) > 3) ? $j % 3 : 0; 
	
	   return  $sign .($j ? substr($i,0, $j) + $t : '').preg_replace('/(\d{3})(?=\d)/',"$1" + $t,substr($i,$j)) . ' ' . $symbol ;
	
	}
	function get_cash_for( $MONTH , $YEAR , $type )
	{
		$NBR_DAYS	=	cal_days_in_month( CAL_GREGORIAN , $MONTH , $YEAR );
		$DATE_START	= 	$YEAR . '/' . $MONTH . '/' . 01;
		$DATE_END	= 	$YEAR . '/' . $MONTH . '/' . $NBR_DAYS;
		
		if( $type == 'actif' )
		{
			$total_price	=	0;
			$commands		=	$this->get_commands( 'between' , $DATE_START , $DATE_END , 'doit' );
			foreach( $commands as $_command )
			{
				$total_price	+=	$this->get_command_price( riake( 'ID' , $_command ) , 'as_id' );
			}
			return $total_price;
		}
	}
	function get_products_sold()
	{
		$commands		=	$this->get_commands();
		$products		=	array();
		foreach( force_array( $commands ) as $_command )
		{
			$products	=	array_merge( $products , $this->get_products_in_commands( riake( 'ID' , $_command ) , true , 'as_command' ) );			
		}
		return $products;
	}
	function get_products_sold_global( $item = 'price' )
	{
		$products	=	$this->get_products_sold();
		if( $item === 'quantity' )
		{
			return count( $products );
		}
		else if( $item === 'price' )
		{
			$overall_price	=	0;
			foreach( force_array( $products ) as $_product )
			{
				$overall_price +=	$this->get_product_selling_price( riake( 'ID' , $_product ) );
			}
			return $overall_price;
		}
	}
}