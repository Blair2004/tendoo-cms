<?php
class nexo_class
{
	function __construct()
	{
		module_include( 'third-library/codebar/barcodes.php' , 'nexo' );
		$this->db						=	get_db();
		$this->time						=	get_instance()->tdate;
		$this->notices();
		$this->datetime					=	$this->time->datetime();
		$this->user_id					=	current_user( 'ID' );
		$this->barcode					=	new DNS1DBarcode();
		$this->barcode->save_path		=	module_path( 'barcodes/' );
		$this->code_limitation			=	5;
		$this->codebar_type				=	'CODABAR';
		$this->options					=	get_meta( 'nexo_settings' );
		$this->morning					=	date( 'Y-m-d' , strtotime( $this->datetime ) ) . ' 00:00:00'; // For date like this Y-m-d h:is			
		$this->evening					=	date( 'Y-m-d' , strtotime( $this->datetime ) ) . ' 23:59:59';
	}
	function daily_report( $type )
	{
		$date_start				=	date( 'Y-m-d' , strtotime( $this->datetime ) );
		$date_start				.=	' 00:00:00'; // For date like this Y-m-d h:is			
		$date_end				=	date( 'Y-m-d' , strtotime( $this->datetime ) ) . ' 23:59:59';
		if( $type == 'recap-recettes' )
		{			
			return $factures				=	$this->get_commands( 'between' , $date_start , $date_end );
		}
		else if( $type == 'recap-bills' )
		{
			return $bills					=	$this->get_bill( 'between' , $date_start , $date_end );
		}
		return false;
	}
	/**
	 *
	**/
	function get_bondavoir_real_price( $bondavoir_id )
	{
		$bondavoir		=	farray( $this->get_bondavoir( $bondavoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			$command		=	farray( $this->get_commands( riake( 'REF_COMMAND' , $bondavoir ) , 'as_id' ) );
			if( $command )
			{
				$command_price	=	$this->get_command_real_price( riake( 'ID' , $command ) , 'as_id' , 'without_active_status' );
				return $command_price;
			}
		}
		return 0;
	}
	function get_bondavoir_client_reduction( $bon_davoir_id )
	{
		$bondavoir	=	farray( $this->get_bondavoir( $bon_davoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			$command_price	=	$this->get_command_price( riake( 'REF_COMMAND' , $bondavoir ) , 'without_active_status' );
			return $reduction		=	$this->get_reduction_for_client( riake( 'REF_CLIENT' , $bondavoir ) , $command_price );
		}
		return 0;
	}
	function get_bondavoir_montant_brut( $bon_davoir_id )
	{
		$bondavoir	=	farray( $this->get_bondavoir( $bon_davoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			return $this->get_command_price( riake( 'REF_COMMAND' , $bondavoir ), 'as_id' , 'without_active_status' ); ;
		}
		return 0;
	}
	function count_product_from_bondachat( $bon_davoir_id , $produit_id )
	{
		$bondavoir	=	farray( $this->get_bondavoir( $bon_davoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			$command	=	farray( $this->get_commands( riake( 'REF_COMMAND' , $bondavoir ) , 'as_id' ) );
			$command_id	=	riake( 'ID' , $command );
			if( $command )
			{
				$count_product_from_command	=	$this->count_product_from_command( $command_id , $produit_id , true );
				return $count_product_from_command;
			}
			return 0;
		}
		return 0;
	}
	function get_bondavoir_price( $bondavoir_id ) // Deprecated
	{
		$bondavoir	=	farray( $this->get_bondavoir( $bondavoir_id , 'as_id' ) );
		if( $bondavoir )
		{
			$command	=	farray( $this->get_commands( riake( 'REF_COMMAND' , $bondavoir ) , 'as_id' ) );
			if( $command )
			{
				$price	=	$this->get_command_price( riake( 'ID' , $command  ) );
				return $price;
			}
			return 0;
		}
		return 0;
	}
	function set_bondavoir( $command_id )
	{
		$bondav	=	farray( $this->get_bondavoir( $command_id , 'as_command_id' ) );
		if( ! $bondav )
		{
			$command					=	farray(  $this->get_commands( $command_id , 'as_id' ) );
			$array	=	array(
				'REF_COMMAND'			=>	$command_id,
				'DATE_CREATION'			=>	$this->datetime,
				'DATE_MODIFICATION'		=>	$this->datetime,
				'REF_CLIENT'			=>	riake( 'REF_CLIENT' , $command ),
				'AUTHOR'				=>	$this->user_id
			);
			$this->db->insert( 'bon_davoir' , $array );
			// Changing product Status
			$current_bondavoir			=	farray( $this->get_bondavoir( $command_id , 'as_command_id' ) );
			$array	=	array(
				'REF_BON_DAVOIR'	=>	riake( 'ID' , $current_bondavoir ),
				'STATUS'			=>	0 // set as unavailable
			);
			$this->db->where( 'REF_COMMANDE' , riake( 'ID' , $command ) )->update( 'nexo_commandes_ref_article' , $array );
			return 'bondav-set';
		}
		return 'bondav-already-exists-for-this-command';
	}
	function delete_bondavoir( $id )
	{
		$bondav	=	$this->get_bondavoir( $id , 'as_id' );
		if( $bondav )
		{
			$array	=	array(
				'STATUS'	=>	1
			);
			$this->db->where( 'REF_BON_DAVOIR' , $id )->update( 'nexo_commandes_ref_article' , $array );
			$this->db->where( 'ID' , $id )->delete( 'bon_davoir' );
			return 'bon-davoir-deleted';
		}
		return 'unknow-bon-davoir';
	}
	function get_bondavoir( $start_or_id = null , $filter_or_end = null )
	{
		$this->db->order_by( 'DATE_MODIFICATION' , 'desc' );
		if( is_numeric( $start_or_id ) && is_numeric( $filter_or_end ) )
		{
			$this->db->limit( $filter_or_end , $start_or_id );
		}
		else if( $filter_or_end == 'as_id' && $start_or_id != null )
		{
			$this->db->where( 'ID' , $start_or_id );
		}
		else if( $filter_or_end == 'as_command_id' && $start_or_id != null )
		{
			$this->db->where( 'REF_COMMAND' , $start_or_id );
		}
		else if( $filter_or_end == 'as_client_id' && $start_or_id != null )
		{
			$this->db->where( 'REF_CLIENT' , $start_or_id );
		}
		$query	=	$this->db->get( 'bon_davoir' );
		return $query->result_array();
	}
	/**
	 * 	CRON JOBS
	 * 	Supprime les factures autoamtiquement et etablie des bons d'avoir.
	**/
	function auto_delete_commands()
	{
	}
	/**
	 * 		Flux Input Output
	**/
	function set_flux( $type , $designation , $montant , $description , $mode = 'create' , $id = null )
	{
		$flux_type	= ( $type == 'input' ) ? 1 : 2;
		if( ! $this->flux_exists( $type , $designation , 'as_name' ) || ( ! $this->flux_exists( $id , 'as_id' ) && $mode == 'edit' ))
		{
			$array					=	array(
				'TITLE'				=>	$designation,
				'DESCRIPTION'		=>	$description,
				'MONTANT'			=>	$montant,
				'DATE_MODIFICATION'	=>	$this->datetime,
				'AUTHOR'			=>	$this->user_id
			);
			if( $mode == 'create' )
			{
				$array[ 'DATE_CREATION' ]	=	$this->datetime;
				$array[ 'TYPE' ]			=	$flux_type;
			}
			else
			{
				$this->db->where( 'TYPE' , $flux_type );
			}
			$mode == 'create' ? $this->db->insert( 'nexo_input_output' , $array ) : $this->db->where( 'ID' , $id )->update( 'nexo_input_output' , $array );
			return 'flux-successfully-set';
		}
		return 'flux-already-exists';
	}
	function get_flux( $type , $item = null, $filter = 'as_id' )
	{
		if( $type == 'input' )
		{
			$this->db->where( 'TYPE' , 1 );
		}
		else if( $type == 'output' )
		{
			$this->db->where( 'TYPE' , 2 );
		}
		if( $item === 'previous_to' )
		{
			$this->db->where( 'DATE_CREATION <=' , $filter );
		}
		if( $item === 'as_date_asc' )
		{
			$this->db->where( 'DATE_CREATION >=' , $filter );
		}
		else if( is_numeric( $item ) && is_numeric( $filter ) )
		{ 
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $filter , $item );
		}
		else if( $filter == 'as_id' && $item != null )
		{
			$this->db->where( 'ID' , $item );
		}
		else if( $filter == 'as_name' && $item != null )
		{
			$this->db->where( 'TITLE' , $item );
		}
		$query	=	$this->db->get( 'nexo_input_output' );
		return $query->result_array();
	}
	function flux_exists( $type , $item , $filter = 'as_id' )
	{
		return $this->get_flux( $type , $item , $filter );
	}
	function delete_flux( $id )
	{
		$exec	=	$this->db->where( 'ID' , $id )->delete( 'nexo_input_output' );
		return 'flux-deleted';
	}
	/**
	 * 		Commandes
	**/
	function set_commandes( $client_id , $command_type , $montant_avance , $products_ids , $payment_type , $mode = 'create' , $id = null )
	{
		if( is_array( $products_ids ) )
		{
			$error_count		=	0;
			$final_product_id	=	array();
			foreach( $products_ids as $key	=> &$product_id )
			{
				if( $this->product_exists( $product_id , 'as_id' ) )
				{
					$final_product_id[]	=	$product_id;
				}
				else
				{
					$error_count++;
				}
			}
		}
		else
		{
			return 'require-product';
		}
		$command_code			=	$this->get_command_code();
		$array		=	array(
			'REF_CLIENT'		=>		$client_id,
			'CODE'				=>		$command_code,
			'TYPE'				=>		$command_type,
			'DATE_MODIFICATION'	=>		$this->datetime,
			'AUTHOR'			=>		$this->user_id,
			'AVANCE'			=>		$montant_avance,
			'PAYMENT_TYPE'		=>		$payment_type
		);
		$mode == 'create' ?	$array[ 'DATE_CREATION' ] = $this->datetime : null;
		$mode == 'create' ?	$this->db->insert( 'nexo_commandes' , $array ) : $this->db->where( 'ID' , $id )->update( 'nexo_commandes' , $array );
		// Geting product
		$commande_query			=		$this->db->where( 'CODE' , $command_code )->get( 'nexo_commandes' );
		$commande				=		$commande_query->result_array();
		// Deleting product to refill
		$this->db->where( 'REF_ARTICLE' , $commande[0][ 'ID' ] )->delete( 'nexo_commandes_ref_article' );
		foreach( $final_product_id as $_pid )
		{
			$_id_exploded	=	explode( '|' , $_pid );
			for( $i = 0 ; $i < (int) $_id_exploded[1]; $i++ )
			{
				$this->db->insert( 'nexo_commandes_ref_article' , array(
					'REF_ARTICLE'	=>	$_id_exploded[0],
					'REF_COMMANDE'	=>	$commande[0][ 'ID' ],
					'STATUS'		=>	1 // Set status 1 (active) per default
				) );
			}
		}	
		$command_amount			=	$this->get_command_price( $command_code , 'as_code' );
		$charge					=	$this->get_reduction_for_client( $client_id , $command_amount );	
		$this->db->where( 'CODE' , $command_code )->update( 'nexo_commandes' , array(
			'CHARGE'			=>	$charge
		) );
		return 'commands-successfully-done';
	}
	function command_payment_type( $code )
	{
		if( $code == 1 )
		{
			return 'Espèce';
		}
		else if( $code == 2 )
		{
			return 'Virement';
		}
		else if( $code == 3 )
		{
			return 'Carte Bancaire';
		}
		else if( $code == 4 )
		{
			return 'MTN Mobile Money';
		}
		else if( $code == 5 )
		{
			return 'Orange Money';
		}
	}
	function get_command_price( $item , $filter = 'as_id' , $filter2 = 'with_active_status' )
	{
		$check_product_status	=	( $filter2 == 'with_active_status' ) ? true : false;
		if( $filter == 'as_code' )
		{
			$command	=	farray( $this->get_commands( $item , 'as_code' ) );
			$products	=	$this->get_products_in_commands( $command[ 'ID' ] , $check_product_status );
			$price		=	0;
			foreach( $products as $_product )
			{
				$price += 	$this->get_product_selling_price( riake( 'REF_ARTICLE' , $_product ) , riake( 'ID',  $command ) );
			}
			return $price;
		}
		else if( $filter == 'as_id' )
		{
			$command	=	farray( $this->get_commands( $item , 'as_id' ) );
			$products	=	$this->get_products_in_commands( $command[ 'ID' ] , $check_product_status );
			$price		=	0;
			foreach( $products as $_product )
			{
				$price += 	$this->get_product_selling_price( riake( 'REF_ARTICLE' , $_product ) , riake( 'ID',  $command ) );
			}
			return $price;
		}
		return 0;
	}
	function get_command_real_price( $item , $filter = 'as_id' , $filter2 = 'with_active_status' )
	{
		$command	=	farray( $this->get_commands( $item , $filter ) );
		$price	=	$this->get_command_price( $item , $filter , $filter2 );
		$charge	=	$this->get_reduction_for_client( riake( 'REF_CLIENT' , $command ) , $price );
		return $price - $charge;
	}
	// Recupère les données d'un produit à une date précise
	function get_product_selling_price( $product_id , $command_id )
	{
		$command	=	farray( $this->get_commands( $command_id , 'as_id' ) );
		if( ! $command ): return 0; endif;
		
		if( is_array( $product_id ) )
		{
			$product_vars	=	farray( $this->get_product_vars( riake( 'ID' , $product_id ) , 'as_id' , riake( 'DATE_CREATION' , $command ) ) );
			
			return ( riake( 'PRIX_DACHAT' , $product_vars ) + riake( 'FRAIS_ACCESSOIRES' , $product_vars ) ) * riake( 'TAUX_MARGE' , $product_vars );
		}
		else if( is_numeric( (int) $product_id ) && is_numeric( (int) $command_id ) )
		{
			$product	=	farray( $this->get_product( $product_id , 'as_id' ) );
			
			if( ! $product ) : return 0; endif;
			
			$product_vars	=	farray( $this->get_product_vars( $product_id , 'as_id' , riake( 'DATE_CREATION' , $command ) ) );

			return ( riake( 'PRIX_DACHAT' , $product_vars ) + riake( 'FRAIS_ACCESSOIRES' , $product_vars ) ) * riake( 'TAUX_DE_MARGE' , $product_vars );
		}
	}
	function get_reduction_for_client( $client_id , $current_command_amount )
	{
		$required_product	=	riake( 'client_promo' , $this->options );
		if( ( int )$required_product > 0 )
		{
			$nbr_command	=	count( $this->get_commands( $client_id , 'as_client_for_active_command' ) );
			if( $nbr_command >= $required_product )
			{
				if( between( 1 , 100 , ( $percent = riake( 'pormo_percent' , $this->options ) ) ) )
				{
					return ( $current_command_amount * $percent ) / 100;
				}
				return 0;
			}
			return 0;
		}
		return 0;
	}
	function get_products_in_commands( $pid , $check_status = true ) // Double Compta Ready
	{
		if( $check_status ) : 	$this->db->where( 'STATUS' , 1 ); endif;
		
		$query	=	$this->db->where( 'REF_COMMANDE' , $pid )->get( 'nexo_commandes_ref_article' );
		$result	=	$query->result_array();
		// Double Compta
		$double_compta		=	riake( 'double_compta' , $this->options , 0 );
		if( between( 1 , 100 , $double_compta ) )
		{
			$nbr_product	=	count( $result );
			$limit_product	=	ceil( ( $nbr_product * $double_compta ) / 100 ); 
			$fictive_list	=	array();
			for( $i = 0 ; $i < $limit_product ; $i++ )
			{
				$fictive_list[] =	$result[ $i ];
			}
			$result		=	$fictive_list; // Changin array result.
		}
		return $result;
	}
	function add_to_cart_conditional_test( $id )
	{
		$articles	=	$this->get_product( $id , 'as_code' );
		$_articles	=	farray( $articles );
		if( ! $articles )
		{
			return json_encode( array(
				'msg'		=>		'Article introuvable ou code incorrect.',
				'return'	=>		false
			) );
		}
		// Count if product can be added to cart again
		else if( ( ( int )riake( 'QUANTITY' , $_articles , 0 ) - ( int )riake( 'DEFECTUEUX' , $_articles , 0 ) ) - count( $this->get_products_in_commands( $_articles[ 'ARTICLE_ID' ] ) )  > riake( 'nbr' , $_GET , 0 ) )
		{
			return json_encode( $articles , JSON_FORCE_OBJECT );
		}
		else
		{
			return json_encode( array(
				'msg'		=>		'Impossible d\'ajouter le produit. Le stock est épuisé',
				'return'	=>		false
			) );
		}
	}
	function get_commands( $start_or_id = null, $end_or_filter = null , $extra_param = null )
	{
		if( is_numeric( $start_or_id ) && is_numeric( $end_or_filter ) )
		{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $end_or_filter , $start_or_id );
		}
		else
		{
			if( $end_or_filter == 'as_id' )
			{
				$this->db->where( 'ID' , $start_or_id );
			}
			else if( $end_or_filter == 'as_code' )
			{
				$this->db->where( 'CODE' , $start_or_id );
			}
			else if( $start_or_id == 'previous_to' )
			{
				$this->db->where( 'DATE_CREATION <=' , $end_or_filter );
			}
			else if( $end_or_filter == 'as_date_asc' )
			{
				$this->db->where( 'DATE_CREATION >=' , $start_or_id );
			}
			else if( $start_or_id == 'between' && $end_or_filter != null && $extra_param != null )
			{
				$this->db->where( 'DATE_CREATION >=' , $end_or_filter );
				$this->db->where( 'DATE_CREATION <=' , $extra_param );
			}
			else if( $end_or_filter == 'as_type' )
			{
				$this->db->where( 'TYPE' , $start_or_id );
			}
			else if( $end_or_filter == 'as_client' )
			{
				$this->db->where( 'REF_CLIENT' , $start_or_id );
			}
			else if( $end_or_filter == 'as_client_for_active_command' )
			{
				$this->db->where( 'TYPE' , 1 );
				$this->db->where( 'REF_CLIENT' , $start_or_id );
			}
		}
		$query	=	$this->db->get( 'nexo_commandes' );
		return $query->result_array();
	}
	function get_command_code()
	{
		return 
			date( 'Y' , strtotime( $this->datetime ) ) . 
			date( 'd' , strtotime( $this->datetime ) ) . 
			date( 'H' , strtotime( $this->datetime ) ) . 
			date( 'm' , strtotime( $this->datetime ) ) . 
			date( 's' , strtotime( $this->datetime ) ) .
			rand( 0 , 9 ) . 
			rand( 0 , 9 );
	}
	function get_distinct_from_command( $command_id , $ignore_status = false )
	{
		$this->db->distinct();
		$this->db->select( 'REF_ARTICLE' );
		$this->db->where( 'REF_COMMANDE' , $command_id );
		if( $ignore_status == false )
		{
			$this->db->where( 'STATUS' , 1 );
		}
		$query	=	$this->db->get( 'nexo_commandes_ref_article' );
		$result	=	$query->result_array();
		// Double Compta
		$double_compta		=	riake( 'double_compta' , $this->options , 0 );
		if( between( 1 , 100 , $double_compta ) )
		{
			$nbr_product	=	count( $result );
			$limit_product	=	ceil( ( $nbr_product * $double_compta ) / 100 ); 
			$fictive_list	=	array();
			for( $i = 0 ; $i < $limit_product ; $i++ )
			{
				$fictive_list[] =	$result[ $i ];
			}
			$result		=	$fictive_list; // Changin array result.
		}
		return $result;
	}
	function count_product_from_command( $command_id , $product_id , $ignore_status = false ) // Double compta Ready
	{
		if( $ignore_status == false )
		{
			$this->db->where( 'STATUS' , 1 ); // Get only active product
		}
		$this->db->where( 'REF_COMMANDE' , $command_id )->where( 'REF_ARTICLE' , $product_id );
		$query	=	$this->db->get( 'nexo_commandes_ref_article' );
		$result	=	$query->result_array();
		// Double Compta
		$double_compta		=	riake( 'double_compta' , $this->options , 0 );
		if( between( 1 , 100 , $double_compta ) )
		{
			$nbr_product	=	count( $result );
			$limit_product	=	ceil( ( $nbr_product * $double_compta ) / 100 ); 
			$fictive_list	=	array();
			for( $i = 0 ; $i < $limit_product ; $i++ )
			{
				$fictive_list[] =	$result[ $i ];
			}
			$result		=	$fictive_list; // Changin array result.
		}
		return count( $result );
	}
	function delete_command( $command_id )
	{
		$command = $this->get_commands( $command_id , 'as_id' );
		if( $command )
		{
			$this->db->where( 'REF_COMMANDE' , $command[0][ 'ID' ] )->delete( 'nexo_commandes_ref_article' );
			$this->db->where( 'ID' , $command[0][ 'ID' ] )->delete( 'nexo_commandes' );
			return 'command-deleted';
		}
		return 'unknow-command';
	}
	/**
	 * 		Recupérer le solde de la caisse pour une opération
	**/
	function get_cash( $arg	= 'default' , $date = null )
	{
		$cash	=	0;
		if( $arg === 'default' )
		{
			$facture_dachats	=	$this->get_bill();
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands();
			foreach( $get_commands as $_command )
			{
				$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) ) - ( int ) riake( 'CHARGE' , $_command );
			}
			$flux_input			=	$this->get_flux( 'input' );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'real' )
		{
			$facture_dachats	=	$this->get_bill();
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands();
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
				else if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) ) - ( int ) riake( 'CHARGE' , $_command );
				}
			}
			$flux_input			=	$this->get_flux( 'input' );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'real-today' )
		{
			$facture_dachats	=	$this->get_bill( 'between' , $this->morning , $this->evening );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( $this->morning , 'as_date_asc' );
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
				else if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) ) - ( int ) riake( 'CHARGE' , $_command );
				}
			}
			$flux_input			=	$this->get_flux( 'input' , 'as_date_asc' , $this->morning );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , 'as_date_asc' , $this->morning );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'real-today-without-entree-extra' )
		{
			$facture_dachats	=	$this->get_bill( 'between' , $this->morning , $this->evening );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs( riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( $this->morning , 'as_date_asc' );
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '2' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
				else if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) ) - ( int ) riake( 'CHARGE' , $_command );
				}
			}
		}
		if( $arg === 'entree-extra-today' )
		{
			$flux_input			=	$this->get_flux( 'input' , 'as_date_asc' , $this->morning );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , 'as_date_asc' , $this->morning );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		if( $arg === 'facture-doit' )
		{
			$get_commands		=	$this->get_commands();
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) ) - ( int ) riake( 'CHARGE' , $_command );
				}
			}
		}
		if( $arg === 'facture-doit-today' )
		{
			$get_commands		=	$this->get_commands( $this->morning , 'as_date_asc' );
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) ) - ( int ) riake( 'CHARGE' , $_command );
				}
			}
		}
		if( $arg === 'facture-avance' )
		{
			$get_commands		=	$this->get_commands();
			foreach( $get_commands as $_command )
			{
				if( riake( 'TYPE' , $_command ) == '1' )
				{
					$cash 	+= ( int ) riake( 'AVANCE' , $_command );
				}
			}
		}
		else if( $arg === 'previous_to' )
		{
			$facture_dachats	=	$this->get_bill( $arg , $date );
			foreach( $facture_dachats as $facture )
			{
				$cash -= abs(riake( 'MONTANT' , $facture , 0 ) );
			}		
			$get_commands		=	$this->get_commands( $arg , $date );
			foreach( $get_commands as $_command )
			{
				$cash	+= ( $this->get_command_price( riake( 'ID' , $_command ) , 'as_id' ) ) - ( int ) riake( 'CHARGE' , $_command );
			}
			$flux_input			=	$this->get_flux( 'input' , $arg , $date );
			foreach( $flux_input as $_flux )
			{
				$cash			+=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
			$flux_output		=	$this->get_flux( 'output' , $arg , $date );
			foreach( $flux_output as $_flux )
			{
				$cash			-=	( int ) riake( 'MONTANT' , $_flux , 0 );
			}
		}
		return $cash;
	}
	/**
	 * 		Providers
	**/
	function create_providers( $name , $bp , $cellphone , $email , $mode = 'create' , $id = 0 )
	{
		$user_id			=	current_user( 'ID' );
		$datetime			=	$this->time->datetime();
		if( $mode == 'create' )
		{
			if( ! $this->provider_exists( $name , 'as_name' ) )
			{
				$this->db->insert( 'nexo_fournisseurs' , array(
					'NOM'		=>		$name,
					'BP'		=>		$bp,
					'TEL'		=>		$cellphone,
					'EMAIL'		=>		$email,
					'DATE_CREATION'	=>	$datetime,
					'DATE_MODIFICATION'	=>	$datetime,
					'AUTHOR'	=>		$user_id
				) );
				return 'provider-created';
			}
			return 'provider-already-exists';
			
		} else if ( $mode == 'edit' ) {
			if( ! $this->provider_exists( $name , 'as_name' , $id ) )
			{
				$this->db->where( 'ID' , $id )->update( 'nexo_fournisseurs' , array(
					'NOM'			=>		$name,
					'BP'			=>		$bp,
					'TEL'			=>		$cellphone,
					'EMAIL'			=>		$email,
					'DATE_MODIFICATION'	=>	$datetime,
					'AUTHOR'		=>		$user_id
				) );
				return 'provider-updated';
			}
			return 'provider-already-exists';
		}
	}
	function delete_provider( $id )
	{
		if( $this->provider_exists( $id , 'as_id' ) )
		{
			$provider			=	$this->get_providers( $id , 'as_id' );
			// Log
			$this->log_actions( current_user( 'PSEUDO' ) , 'supprimé le fournisseur ' . $provider[0][ 'NOM' ] , $this->time->datetime() );
			// Return
			return $this->db->where( 'ID' , $id )->delete( 'nexo_fournisseurs' ) ? 'provider-deleted' : 'error_occured' ;
		}
		return 'error_occured';
	}
	function provider_exists( $name , $filter = 'as_name' , $exclude = 0 )
	{
		if( $exclude != null )
		{
			$query	=	$this->db->where( 'NOM' , $name )->where( 'ID !=' , $exclude )->get( 'nexo_fournisseurs' );
			return $query->result_array() ? true : false;
		}
		return $this->get_providers( $name , $filter ) == true ? true : false;
	}
	function get_providers( $name = null , $end = 'as_name' )
	{
		if( is_numeric( $name ) && is_numeric( $end ) )		{ 
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $end , $name );
		} else if( $name != null ){	
			if( $end == 'as_id' ){
				$this->db->where( 'ID' , $name );		
			} else if( $end == 'as_name' ){
				$this->db->where( 'NOM' , $name );		
			}
		}
		$query	= 	$this->db->get( 'nexo_fournisseurs' );
		return $query->result_array();
	}
	/**
	 * 		Shipping Functions
	**/
	function create_shipping( $name , $provider  , $description , $mode = 'create' , $id = 0 ) // Ok
	{
		if( $mode == 'create' ){
			if( ! $this->shipping_exists( $name , 'as_name' ) && $this->provider_exists( $provider , 'as_id' ) ){
				$exec	=	$this->db->insert( 'nexo_arrivages' , array(
					'TITRE'			=>	$name,
					'DESCRIPTION'	=>	$description,
					'DATE_CREATION'	=>	$this->datetime,
					'DATE_MODIFICATION'	=>	$this->datetime,
					'AUTHOR'		=>	$this->user_id,
					'FOURNISSEUR_REF_ID'	=>	$provider
				) );
				return $exec ? 'shipping-created' : 'error-occured';
			} 
			return 'shipping-already-exists-or-unknow-provider';
		} else if( $mode == 'edit' ){
			if( ! $this->shipping_exists( $name , 'as_name' , $id ) && $this->provider_exists( $provider , 'as_id' ) ){
				$exec	=	$this->db->where( 'ID' , $id )->update( 'nexo_arrivages' , array(
					'TITRE'					=>	$name,
					'DESCRIPTION'			=>	$description,
					'DATE_MODIFICATION'		=>	$this->datetime,
					'AUTHOR'				=>	$this->user_id,
					'FOURNISSEUR_REF_ID'	=>	$provider
				) );
				return $exec ? 'shipping-updated' : 'error-occured';
			} 
			return 'shipping-already-exists-or-unknow-provider';
		}
	}
	function shipping_exists( $name , $filter = 'as_name' , $exclude = 0 )
	{
		if( $exclude != null )
		{
			$query	=	$this->db->where( 'TITRE' , $name )->where( 'ID !=' , $exclude )->get( 'nexo_arrivages' );
			return $query->result_array() ? true : false;
		}
		else
		{
			return $this->get_shipping( $name , $filter ) ? true : false;
		}
	}
	function get_shipping( $name = null , $end = 'as_name' )
	{
		if( is_numeric( $name ) && is_numeric( $end ) )	{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $end , $name );
		} else if( $name != null ) {
			if( $end == 'as_id' ){
				$this->db->where( 'ID' , $name );
			} else if( $end ==  'as_name' ){
				$this->db->where( 'TITRE' , $name );
			} 
		}
		$query	=	$this->db->get( 'nexo_arrivages' );
		return $query->result_array();
	}
	function delete_shipping( $id )
	{
		if( $this->shipping_exists( $id , 'as_id' ) )
		{
			$this->db->where( 'ID' , $id )->delete( 'nexo_arrivages' );
			return 'shipping-deleted';
		}
		return 'unknow-shipping';
	}
	/** 
	 * 		Rayons Functions
	**/
	function set_rayon( $name , $description , $mode = 'create' , $id = 0 )
	{
		if( $mode == 'create' )
		{
			if( ! $this->rayon_exists( $name , 'as_name' ) )
			{
				return $this->db->insert( 'nexo_rayons' , array(
					'TITRE'				=>	$name,
					'DESCRIPTION'		=>	$description,
					'DATE_CREATION'		=>	$this->datetime,
					'DATE_MODIFICATION'	=>	$this->datetime,
					'AUTHOR'			=>	$this->user_id
				) ) ? 'rayon-has-been-created' : 'error-occured';
			}
		}
		else if( $mode == 'edit' )
		{
			if( ! $this->rayon_exists( $name , 'as_name' , $id ) )
			{
				return $this->db->where( 'ID' , $id )->update( 'nexo_rayon' , array(
					'TITRE'				=>	$name,
					'DESCRIPTION'		=>	$description,
					'DATE_MODIFICATION'	=>	$this->datetime,
					'AUTHOR'			=>	$this->user_id
				) ) ? 'rayon-has-been-edited' : 'error-occured';
			}
		}
		return 'unable-to-create-or-edit-rayon';
	}
	function rayon_exists( $name , $filter = 'as_name' , $exclude = 0 )
	{
		if( $exclude == null )
		{
			return	$this->get_rayons( $name , $filter );
		}
		else 
		{
			$this->db->where( 'ID !=' , $exclude );
			$query	=	$this->db->where( 'TITRE' , $name )->get( 'nexo_rayons' );
			return $query->result_array();
		}
	}
	function get_rayons( $name = null, $filter_or_end = 'as_name' )
	{
		if( $filter_or_end == 'as_name' && $name != null )
		{
			$this->db->where( 'TITRE' , $name );
		}
		else if( $filter_or_end == 'as_id' && $name != null )
		{
			$this->db->where( 'ID' , $name );
		}
		else if( is_numeric( $name ) && is_numeric( $filter_or_end ) )
		{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $filter_or_end , $name );
		}
		$query	=	$this->db->get( 'nexo_rayons' );
		return $query->result_array();
	}
	function delete_rayons( $name_or_id , $filter )
	{
		if( $rayon	=	$this->rayon_exists( $name_or_id , $filter ) )
		{
			if( $filter == 'as_name' )
			{
				$exec	= $this->db->where( 'TITRE' , $name_or_id )->delete( 'nexo_rayons' );
			}
			else if( $filter == 'as_id' )
			{
				$exec	= $this->db->where( 'ID' , $name_or_id )->delete( 'nexo_rayons' );
			}
			return $exec ? 'rayon-has-been-deleted' : 'error-occurred';
		}
		return 'error-occured';
	}
	/**
	 *  	Product Function
	**/
	function set_product( $name , $arrivage_id , $prix_ttc , $cout_unitaire , $category_id , $rayon_id , $shipping_id , $taille , $couleur , $quantity , $prix_dachat , $frais_accessoires , $taux_marge , $taux_solde , $defectueux ,  $mode  = 'create' , $id = 0 )
	{
		if( ( int ) $quantity < ( int )$defectueux ) : return 'quantity-error'; endif;
		if( ! $this->product_exists( $name , 'as_name' ) || ( ! $this->product_exists( $name , 'as_id' , $id ) && $mode == 'edit' ) )
		{
			if( is_numeric( $frais_accessoires ) && is_numeric( $taux_marge ) && is_numeric( $quantity ) )
			{
				if( 
					$this->shipping_exists( $arrivage_id , 'as_id' ) && 
					$this->category_exists( $category_id , 'as_id' ) &&
					$this->rayon_exists( $rayon_id , 'as_id' ) 
				)
				{
					$data	=	 array(
						'DESIGN'			=>	$name,
						'PRIX_TTC'			=>	$prix_ttc,
						'PRIX_UNITAIRE'		=>	$cout_unitaire,
						'REF_CATEGORIE'		=>	$category_id,
						'REF_SHIPPING'		=>	$shipping_id,
						'REF_RAYON'			=>	$rayon_id,
						'TAILLE'			=>	$taille,
						'COULEUR'			=>	$couleur,
						'QUANTITY'			=>	$quantity >= 1 ? $quantity : 0,
						'AUTHOR'			=>	$this->user_id,
						'DATE_MODIFICATION'	=>	$this->datetime,
						'DEFECTUEUX'		=>	$defectueux >= 1 ? $defectueux : 0
					);
					$vars	=	array(
						'PRIX_DACHAT'		=>	$prix_dachat,
						'FRAIS_ACCESSOIRES'	=>	$frais_accessoires,
						'TAUX_DE_MARGE'		=>	$taux_marge,
						'TAUX_SOLDE'		=>	$taux_solde,
						'DATE_MODIFICATION'	=>	$this->datetime,
						'DATE_CREATION'		=>	$this->datetime, // Pour ce cas spécialement, puisque les données antérieures ne peuvent pas être modifiée
						'AUTHOR'			=>	$this->user_id
					);
					( $mode == 'create' ) ?  $data[ 'DATE_CREATION' ] = $this->datetime : null;
					if( $mode	==	'create' ):
						$this->db->insert( 'nexo_articles' , $data );
					else:
						$vars[ 'REF_ARTICLE' ]	=	$id ;
						$this->db->where( 'ID' , $id )->update( 'nexo_articles' , $data );
					endif;
					// Creating Code Bar
					if( $mode == 'create' )
					{
						$sub_query 	=	$this->db->order_by( 'ID' , 'desc' )->limit( 1 , 0 )->get( 'nexo_articles' );
						$latest		=	$sub_query->result_array();
						$code_data	=	$this->generate_code();
						$latest		=	farray( $latest );
						$creation	=	$this->set_code( $code_data , riake( 'ID' , $latest ) );
						$vars[ 'REF_ARTICLE' ]	=	riake( 'ID' , $latest ) ;
					}
					// Inserting Data vars
					$this->db->insert( 'nexo_articles_vars' , $vars );
					
					return 'product-has-been-created';
				}
				return 'unable-to-find-meta-data';
			}			
			return 'numeric-value-required';	
		}
		return 'product-exists';
	}
	function get_product_related( $item , $element = 'optional' )
	{
		if( $item === 'rayon' )
		{
			$this->db->where( 'REF_RAYON' , $element );
			$query		=	$this->db->get( 'nexo_articles' );
			return $query->result_array();
		}
		else if( $item === 'categories' )
		{
			if( ! function_exists( '__get_categories' ) )
			{
				function __get_categories( $id , $lib )
				{
					$categories 	=	$lib->get_category( $id , 'as_parent' );
					foreach( $categories as $key => $_category )
					{
						$_sub_category	=	__get_categories( riake( 'ID' , $_category ) , $lib );
						$categories[ $key ][ 'SUB_CATEGORY' ]	=	$_sub_category;
					}
					return $categories;
				}
			}
			if( ! function_exists( '__get_category_products' ) )
			{
				function __get_category_products( $lib , $category_array )
				{
					foreach( $category_array as $key => $_category )
					{
						// Si une catégorie n'a pas d'enfant on recupère ses produits
						
						if( count( riake( 'SUB_CATEGORY' , $_category ) ) > 0 )
						{
							$category_array[ $key ][ 'SUB_CATEGORY' ]	=	__get_category_products( $lib , $category_array[ $key ][ 'SUB_CATEGORY' ] );
						}
						else
						{
							$category_array[ $key ][ 'PRODUCTS' ] 		= 	$lib->get_product_related( 'category' , riake( 'ID' , $_category ) );
						}
					}
					return $category_array;
				}
			}
			$categories	=	__get_categories( $item , $this );
			$categories	=	__get_category_products( $this , $categories );
			
			return ( $categories );
		}
		else if( $item == 'category' )
		{
			return $this->get_product( $element , 'as_category' );
		}
		
	}
	function get_product_inside_big_category( $array )
	{
		$final_array =	array();
		foreach( force_array( $array ) as $category )
		{
			$final_array[ riake( 'NOM' , $category ) ]	=	$this->__join_products( array( $category ) );
		}
		return $final_array;
	}
	private function __join_products( $array )
	{
		$cart	=	array();
		foreach( $array as $_ar )
		{
			if( riake( 'PRODUCTS' , $_ar ) )
			{
				$cart	=	array_merge( $cart , riake( 'PRODUCTS' , $_ar ) );
			}
			else if( is_array( riake( 'SUB_CATEGORY' , $_ar ) ) && count( riake( 'SUB_CATEGORY' , $_ar ) ) > 0 )
			{
				$cart	=	array_merge( $cart , $this->__join_products( riake( 'SUB_CATEGORY' , $_ar ) ) );
			}
		}
		return $cart;
	}
	function product_exists( $name , $filter = 'as_id' , $exclude = 0 )
	{
		return $this->get_product( $name , $filter );
	}
	function get_product( $name = null , $filter_or_end = 'as_name' )
	{
		$this->db->select( 
			'*,
			nexo_code_barre.ID as CODEBAR_ID, 
			nexo_articles.ID as ARTICLE_ID,
			' 
		);
		$this->db->join( 'nexo_code_barre' , 'nexo_articles.ID = nexo_code_barre.REF_ARTICLE' , 'left' );
		$this->db->order_by( 'nexo_articles.DATE_MODIFICATION' , 'desc' );
		if( $filter_or_end === 'as_id' && $name != null )
		{
			$this->db->where( 'nexo_articles.ID' , $name );
		}
		else if( $filter_or_end === 'as_code' && $name != null )
		{
			$this->db->where( 'nexo_code_barre.CODE' , $name );
		}
		else if( $filter_or_end === 'as_name' && $name != null )
		{
			$this->db->where( 'DESIGN' , $name );
		}
		else if( $filter_or_end === 'as_shipping' && $name != null )
		{
			$this->db->where( 'REF_SHIPPING' , $name );
		}
		else if( $filter_or_end === 'as_category' && $name != null )
		{
			$this->db->where( 'REF_CATEGORIE' , $name );
		}
		else if( is_numeric( $name ) && is_numeric( $filter_or_end ) )
		{
			$this->db->limit( $filter_or_end , $name );
		}
		$query	=	$this->db->get( 'nexo_articles' );
		$array	=	$query->result_array();
		foreach( $array as $key => $value )
		{
			$query	=	$this->db->where( 'REF_ARTICLE' , $value[ 'ARTICLE_ID' ] )->order_by( 'DATE_MODIFICATION' , 'desc' )->get( 'nexo_articles_vars' );
			$data	=	$query->result_array();
			
			$latest	=	farray( $data );
			$array[ $key ][ 'PRIX_DACHAT' ]			=	riake( 'PRIX_DACHAT' , $latest );
			$array[ $key ][ 'FRAIS_ACCESSOIRES' ]	=	riake( 'FRAIS_ACCESSOIRES' , $latest );
			$array[ $key ][ 'TAUX_DE_MARGE' ]		=	riake( 'TAUX_DE_MARGE' , $latest );
			$array[ $key ][ 'TAUX_SOLDE' ]			=	riake( 'TAUX_SOLDE' , $latest );
		}
		return $array;
	}
	function get_product_vars( $product_id , $filter = 'as_id' , $where_date_is_under = null )
	{
		$produit	=	farray( $this->get_product( $product_id , $filter ) );		
		
		$this->db->order_by( 'DATE_CREATION' , 'desc' );
		
		if( $where_date_is_under != null ) : $this->db->where( 'DATE_MODIFICATION <' , $where_date_is_under ); endif;

		$query		=	$this->db->where( 'ID' , riake( 'ID' , $produit ) )->get( 'nexo_articles_vars' ); // 
		
		return $query->result_array();
	}
	function delete_product( $id )
	{
		if( $this->product_exists( $id ,'as_id' ) )
		{
			$product	=	farray( $this->get_product( $id , 'as_id' ) );
			// Supprime le codebar
			if( is_file( $file_path	=	riake( 'FILE_PATH' , $product ) ) )
			{
				unlink( $file_path );
				$this->db->where( 'REF_ARTICLE' , $id )->delete( 'nexo_code_barre' );
				$this->db->where( 'REF_ARTICLE' , $id )->delete( 'nexo_articles_vars' );
			}
			// 
			if( $this->db->where( 'ID' , $id )->delete( 'nexo_articles' ) )
			{
				return 'product-deleted';
			}
			return 'error-occured';
		}
		return 'unknow-product';
	}
	function refresh_codebar( $products_list )
	{
		if( is_array( $products_list ) )
		{
			foreach( force_array( $products_list ) as $product )
			{
				// Delete Previous Codebar
				if( is_file( $file = module_path( 'barcodes/' . riake( 'CODE' , $product ) , 'nexo' ) . '.png' ) )
				{
					unlink( $file );
				}
				$this->delete_code( riake( 'CODE' , $product ) );
				// Refreshing
				$code_data	=	$this->generate_code();
				$creation	=	$this->set_code( $code_data , riake( 'ARTICLE_ID' , $product ) );
			}
			return 'product-code-refreshed';
		}
		return 'only-array-is-supported';
	}
	/**
	 * 		Category Functions
	**/
	function set_category( $name , $description , $parent , $mode = 'create' , $id = 0 )
	{
		if( $name == $parent ): return 'hierarchy-error'; endif;
		if( ! $this->category_exists( $name , 'as_name' ) || ! $this->category_exists( $name , 'as_name' , $id ) )
		{
			if( $this->category_exists( $parent , 'as_id' ) || $parent == 0 )
			{
				$array	=	array( 
					'NOM'				=>	$name,
					'DESCRIPTION'		=>	$description,
					'AUTHOR'			=>	$this->user_id,
					'DATE_MODIFICATION'	=>	$this->datetime,
					'PARENT_REF_ID'		=>	$parent
				);
				( $mode == 'create' ) ? $array[ 'DATE_CREATION' ] = $this->datetime : null;
				( $mode == 'create' ) ? $this->db->insert( 'nexo_categories' , $array ) : $this->db->where( 'ID' , $id )->update( 'nexo_categories' , $array );
				return 'category-updated';
			}
			return 'parent-category-unknow';
		}
		return 'categoy-name-already-taken';
	}
	function category_exists( $name , $filter , $exclude = 0 )
	{
		// for exclude statement
		$query	=	$this->db->where( 'ID !=' , $exclude )->where( 'NOM' , $name )->get( 'nexo_categories' );
		return $exclude == null ? $this->get_category( $name , $filter ) : $query->result_array();
	}
	function get_category( $name_or_start = null , $filter_or_end = null , $exclude = 0 , $order_by = null )
	{
		if( $order_by == null )
		{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' );
		}
		else if( $order_by == 'name_asc' )
		{
			$this->db->order_by( 'NOM' , 'asc' );
		}
		else if( $order_by == 'name_desc' )
		{
			$this->db->order_by( 'NOM' , 'asc' );
		}
		
		is_numeric( $exclude ) ? $this->db->where( 'ID !=' , $exclude ) : null; // excluding if exclude is provided
		
		if( is_numeric( $name_or_start ) && is_numeric( $filter_or_end ) )
		{
			$this->db->limit( $filter_or_end , $name_or_start );
		}
		else if( is_string( $filter_or_end ) )
		{
			$filter_or_end == 'as_id' 	? $this->db->where( 'ID' , $name_or_start ) : null;
			$filter_or_end == 'as_name' ? $this->db->where( 'NOM' , $name_or_start ) : null;
			$filter_or_end == 'as_parent' ? $this->db->where( 'PARENT_REF_ID' , $name_or_start ) : null;
		}
		$query	=	$this->db->get( 'nexo_categories' );
		return $query->result_array();
	}
	function delete_category( $id )
	{
		return 
		$this->category_exists( $id , 'as_id' ) 
			? 	$this->db->where( 'ID' , $id )->delete( 'nexo_categories' ) 
				?	'category-deleted' : 'error-occured' 
			: 'unknow-category';
	}
	/**
	 * 	Generate Code Barre
	**/
	function generate_code()
	{
		do {
			$code	=	$this->randomize_code( $this->code_limitation );
		}
		while( $this->code_exists( $code ) );
		
		return array(
			'FILE_PATH'	=>	$this->barcode->getBarcodePNGPath( $code , $this->codebar_type ),
			'CODE'		=>	$code
		);
	}
	/**
	 * Créer un code bar et enregistrement dans la base de donnée
	**/
	function set_code( $code_data , $ref_article )
	{
		if( ! $this->code_exists( $code_data[ 'CODE' ] ) && $this->product_exists( $ref_article , 'as_id' ) )
		{
			return $this->db->insert( 'nexo_code_barre' , array(
				'CODE'			=>	$code_data[ 'CODE' ],
				'FILE_PATH'		=>	$code_data[ 'FILE_PATH' ],
				'REF_ARTICLE'	=>	$ref_article,
				'DATE_CREATION'	=>	$this->datetime,
				'AUTHOR'		=>	$this->user_id
			) );
		}
		return 'code-bar-creation-failed';
	}
	/**
	 * Client fonctions
	 *
	**/
	function get_clients( $start = null , $end = null )
	{
		if( is_numeric( $start ) && is_numeric( $end ) )
		{
			$this->db->order_by( 'REG_DATE' , 'desc' )->limit( $start , $end );
		}
		$clients	=	get_instance()->roles->get_users_with_role( riake( 'client_privilege' , $this->options ) );
		return $clients;
	}
	function set_client( $email , $mode = 'create' , $id = null )
	{
		$pseudo		=	'CLIENT-' . count( $this->get_clients() ) . rand( 0 , 9 ) . rand( 0 , 9 ) . rand( 0 , 9 ) . rand( 0 , 9 ) . rand( 0 , 9 );
		$password	=	'nexo-client-password';
		$client_privilege	=	riake( 'client_privilege' , $this->options );
		if( $client_privilege )
		{		
			if( $mode == 'create' )
			{
				return	current_user()->createAdmin(
					$pseudo,
					$password,
					'MASC',
					$client_privilege,
					$email,
					'TRUE'
				);
			} else {
				$client	=	get_user( $id , 'as_id' );
				return current_user()->setAdminPrivilege(
					$client_privilege,
					$client[ 'PSEUDO' ],
					$email
				);
			}
		}
		return 'set-role-id-first';
	}
	/**
	 * Verifie si un cod existe
	**/
	function code_exists( $code )
	{
		$query	=	$this->db->where( 'CODE' , $code )->get( 'nexo_code_barre' );
		return $query->result_array();
	}
	function delete_code( $code )
	{
		return $this->db->where( 'CODE' , $code )->delete( 'nexo_code_barre' );
	}
	function randomize_code( $limit = 5 )
	{
		$code = '';
		for( $i = 0 ; $i < $limit ; $i++ )
		{
			$code	.= rand(0,9);
		}
		return $code;
	}
	/**
	 * 	Factures d\'achats
	**/
	function set_bill( $raison , $description , $montant , $nature , $ref , $mode = 'create' , $id = null )
	{
		$montant	=	abs( $montant );
		if( ! $this->bill_exists( $raison , 'as_name' ) OR $this->bill_exists( $id , 'as_id' ) )
		{
			if( - $montant + $this->get_cash( 'real' ) < 0 )
			{
				return 'not-enough-cash';
			}
			$array	=	array(
				'TITLE'				=>	$raison,
				'DESCRIPTION'		=>	$description,
				'MONTANT'			=>	$montant,
				'REF'				=>	$ref,
				'NATURE_SOCIALE'	=>	$nature,
				'DATE_MODIFICATION'	=>	$this->datetime,
				'AUTHOR'			=>	$this->user_id
			);
			( $mode == 'create' ) 
				? 	$array[ 'DATE_CREATION' ] = $this->datetime 
				: 	null;
			$exec	=	( $mode == 'edit' ) 
				?	$this->db->where( 'ID' , $id )->update( 'nexo_factures_dachats' , $array ) 
				:	$this->db->insert( 'nexo_factures_dachats' , $array );			
			return $exec ? 'bill-set' : 'error-occured';
		}
		return 'bill-already-exists';
	}
	function delete_bill( $id )
	{
		if( $this->bill_exists( $id , 'as_id' ) )
		{
			$exec 	=	$this->db->where( 'ID' , $id )->delete( 'nexo_factures_dachats' );
			return $exec ? 'bill-deleted' : 'error-occured';
		}
		return 'unknow-bill';
	}
	function bill_exists( $id_or_name , $filter )
	{
		return $this->get_bill( $id_or_name , $filter );
	}
	function get_bill( $start_or_id = null , $end_or_filter = 'as_id' , $extra_param = null )
	{
		if( is_numeric( $start_or_id ) && is_numeric( $end_or_filter ) )
		{
			$this->db->order_by( 'DATE_MODIFICATION' , 'desc' )->limit( $end_or_filter , $start_or_id );
		}
		else if( $start_or_id != null )
		{
			if( $end_or_filter == 'as_id' )
			{
				$this->db->where( 'ID' , $start_or_id );
			}
			else if( $start_or_id == 'between' && $extra_param != null )
			{
				$this->db->where( 'DATE_CREATION >=' , $end_or_filter )->where( 'DATE_CREATION <=' , $extra_param );
			}
			else if( $start_or_id == 'previous_to' && $end_or_filter != null )
			{
				$this->db->where( 'DATE_CREATION <=' , $end_or_filter );
			}
			else if( $end_or_filter == 'as_name' )
			{
				$this->db->where( 'TITLE' , $start_or_id );
			}
		}
		$query	=	$this->db->get( 'nexo_factures_dachats' );
		return $query->result_array();
	}
	/**
	 * 		Log Functions
	**/
	function log_actions( $user , $has_done , $on )
	{
		// waiting. user %s has done this action %s on %s
		
	}
	function notices()
	{
	}
}