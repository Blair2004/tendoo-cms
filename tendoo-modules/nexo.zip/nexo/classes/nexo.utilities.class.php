<?php
class nexo_utilities
{
	function __construct()
    {
    	$this->datetime	=	site_datetime();
		$this->errors	=	new nexo_error_handler(); // Hoping nexo_error_handler has been added
    }	
    function current_date()
    {
    	return $this->datetime;
    }
}