<?php
class nexo_error_handler
{
	private $_refer_to_admin					=	'Consultez l\'administrateur pour en savoir plus.';
	private $_refer_to_devmaster				=	'Consultez le manuel d\'utilisation ou l\équipe de développement, si le problème persiste.';
	function __construct()
	{
		$this->push_error( 'not_enough_cash' , 'Fonds insuffisant pour traiter votre demande.' , 'error' );
		$this->push_error( 'incorrect_element' , 'Element de paie incorrect ou introuvable. Consultez l\'administrateur pour en savoir plus.' , 'error' );
		$this->push_error( 'unknow_employee' , 'Employée inconnu ou introuvable.' . $this->_refer_to_admin , 'error' );
		$this->push_error( 'forbidden' , 'Il ne vous est pas permi d\'accéder à cet élément' , 'warning' );
		$this->push_error( 'error_occred_during_employee_payment' , 'Une erreur s\'est produite durant le paiement. ' . $this->_refer_to_devmaster , 'error' );
		$this->push_error( 'payment_done' , 'Le paiement d\'un employé à correctement été effectué' , 'success' );
	}
	private function push_error( $key , $code , $type = 'success' )
	{
		if( $type == 'success' )
		{
			$this->errors[ $key ] 	=	tendoo_success( $code );
		}
		else if( $type == 'info' )
		{
			$this->errors[ $key ]	= 	tendoo_info( $code );
		}
		else if( $type == 'error' )
		{
			$this->errors[ $key ] 	=	tendoo_error( $code );
		}
		else
		{
			$this->errors[ $key ] 	=	tendoo_warning( $code );
		}
	}
	function get_error( $code )
	{
		return ( $code	=	$this->riake( $code , $this->errors ) ) == true ? $code : tendoo_error( $code . ' Error Code is not valid' );
	}
}