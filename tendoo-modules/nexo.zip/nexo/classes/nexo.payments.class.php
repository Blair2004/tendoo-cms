<?php
/*
Parent Herited Methods

->get( key , vars ) / ->get( key );
->riake()
// Operator class
->can( action )
->user()
->current_date()
->get_operator( $current_user )
->log_activity( )
->set_work_date( )
	// Product Class
	->start_cart_session()
	->add_to_cart()
	->remove_from_cart()
	->close_cart_session()

// Employee class
->employee_exists()
->get_employee()
->add_employee()
->delete_employee()

*/
class nexo_payments
{
	private $operator_id;
	private $current_date;
	
	function __construct()
	{
	}
	/**
	*	Pay someone : Pay a created employee, using Shop Money
	**/
	function paysomeone( $created_employee_id , $payment_element_id ) // Save this as action for Operator, count payment as passive.
	{
		if( $this->user->can( 'paysomeone' ) )
		{
			if( $employee = $this->employee_exists( $created_employee_id ) )
			{
				$payment_datas		=	$this->get( 'payment_element' , $payment_element_id );
				$current_balance	=	$this->get( 'current_balance' );
				$safe_balance		=	$this->get( 'safe_balance' ) ? $this->get( 'safe_balance' ) : 0 ; // If no safe balance is set, 0 is used instead.
				
				if( $sal_base = $this->riake( 'sal_base' , $payment_datas ) ) // Payment element should return Element datas or this element doesn't exists
				{
					if( $sal_base - $current_balance > $safe_balance ) // Doit ajouter une mesure preventive avec un seuil endeçât duquel le paiement ne peut plus être effectué
					{
						// Do Action
						$result		=	$this->db->insert( 'nexo_livre_de_paie' , array(
							'TITLE'				=>	'',
							'DESCRIPTION'		=>	'',
							'REF_EMPLOYE_ID'	=>	$created_employee_id,
							'REF_ELEMENT_PAIE'	=>	$payment_element_id
						) );
						if( $result )
						{
							// Log Action
							$this->log( $this->user( 'pseudo' ) . ' a effectué un paiement le ' . $this->current_date() . ' à l\'égard de l\'employé ' . $employee[ 'nom_emp' ] . ', d\'une somme de : ' . $sal_base . '. Consultez le Bulletin de paie pour en savoir plus.' );
						}
						return $result ? 'payment_done' : 'error_occred_during_employee_payment' ;
					}
					return 'not_enough_cash';
				}
				return 'incorrect_element';
			}
			return 'unknow_employee';
		}
		return 'forbidden';
	}
}