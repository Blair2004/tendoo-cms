<?php
/**
*	Nexo Base Class : include first
**/
module_include( 'classes/nexo.error_handler.class.php' , 'nexo' );
module_include( 'classes/nexo.payments.class.php' , 'nexo' );
module_include( 'classes/nexo.utilities.class.php' , 'nexo' );
/**
*	Launching Nexo Class
**/
class nexo extends nexo_utilities
{
	function __construct()
	{
		parent::__construct();
	}
}