<script>
$(document).ready(function(e) {
	$.ctrl = function(key, callback, args ) {
		var isCtrl = false;
		$(document).keydown(function(e) {
			if(!args) args=[]; // IE barks when args is null
			if(e.ctrlKey) isCtrl = true;
			if(e.keyCode == key.charCodeAt(0) && isCtrl) {
				e.preventDefault();
				callback.apply(this, args );
				return false;
			}
		}).keyup(function(e) {
			if(e.ctrlKey) isCtrl = false;
		});        
	};
	new nexo_commands();
});
Number.prototype.format = function(n, x, s, c) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')',
        num = this.toFixed(Math.max(0, ~~n));

    return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
};
function nexo_commands()
{
	var products		=	new Array();
	var table			=	$( '#command_table' );
	var fields			=	$('[name="product_ids"]');
	var cash			=	$('#price');
	var product_added	=	false;
	var add_product_stat	=	true;
	var refresh_product_list	=	function(){
		var solde_cart		=	0;
		var list_refreshed	=	false;
		$( table ).find( 'tbody' ).html('');
		$.map( products , function( value , key ){
			// Empty array are ignored
			if( value != null )
			{
				if( typeof value.ARTICLE_ID != 'undefined' )
				{
					var prix_unitaire 	= ( ( parseInt( value.PRIX_DACHAT ) + parseInt( value.FRAIS_ACCESSOIRES ) ) * value.TAUX_DE_MARGE );
					var prix_total		=	prix_unitaire * value.nbr;
					solde_cart			+=	prix_total;
					list_refreshed	=	true;
					var ligne	=	'<tr><td>' + value.DESIGN + '</td><td>' + prix_unitaire.format( 2, 3, '.', ',' ) + '</td><td>' + value.nbr + '</td><td>' + prix_total.format( 2, 3, '.', ',' ) + ' </td><td><a data-code="' + value.CODE + '" href="javascript:void()">Retirer</a></td></tr>';
					$( table ).find( 'tbody' ).append( ligne );
				}
			}
		});
		$( cash ).text( solde_cart.format( 2, 3, '.', ',' ) );
		$('[name="montant_command"]').val( solde_cart );
		console.log( products );
		if( list_refreshed == false )
		{
			var ligne	=	'<tr><td>-</td><td>--</td><td>--</td><td>--</td></tr>';
			$( table ).find( 'tbody' ).append( ligne );
		}
	}
	var	remove_from_cat	=	function(){
		$( '[data-code]' ).each( function(){
			if( ! $(this).attr( 'bound' ) )
			{
				$(this).attr( 'bound' , 'true' );
				$(this).bind( 'click' , function(){
					$this	=	$(this);
					$.map( products , function( value , key ){
						if( value != null )
						{
							if( value.CODE == $this.attr( 'data-code' ) )
							{
								// if there is no more product in the cart
								value.nbr--
								if( value.nbr == 0 )
								{
									products.splice( key , 1 );
								}
							}
						}
					});
					refresh_product_list();
					remove_from_cat();
				});
			}
		})
	};
	this.start			=	function(){
		$( '[name="add_product"]' ).bind( 'click' , function(){
			if( $(fields).val() != '' )
			{
				$(fields).focus();
				// To avoid Multiple clicks
				if( add_product_stat == false ){ return false; };
				add_product_stat = false;
				
				var nbr	=	0;
				$.map( products , function( value , key ){
					if( value != null )
					{
						if( value.CODE == $(fields).val() )
						{
							nbr		=	value.nbr;
						}
					}
				});
				$.ajax({
					url 		: 	'<?php echo module_url( array( 'articles' , 'ajax_get' ) );?>/' + $(fields).val() +'?nbr=' + nbr,
					dataType	:	'json',
					beforeSend: function(){
						tendoo.loader.display();
						$( fields ).val(''); // Resetting field
						// add_product_stat	=	true;
					},
					success		:	function( data, textStatus, jqXHR ){
						tendoo.loader.hide();
						$( fields ).val(''); // Resetting field
						// Restore add_product_stat
						add_product_stat = true;
						
						if( $.isEmptyObject(data) ) // 3153576948
						{
							tendoo.notice.alert( 'Produit introuvable ou code incorrect.' , 'warning' );
							return false;
						}	
						if( typeof data.msg == 'string' )
						{
							tendoo.notice.timeout(5000).alert( data.msg , 'warning' );
							return false;
						}
						$.map( products , function( value , key ){
							if( value != null )
							{
								if( value.ARTICLE_ID == data[0].ARTICLE_ID )
								{
									products[ key ].nbr++;	
									product_added = true;
								}
							}
						});
						if( products.length == 0 || product_added == false )
						{
							data[0].nbr	=	1;
							products.push(data[0]);
						}
						// Rafraichissement du tableau
						refresh_product_list();
						remove_from_cat();
						
						product_added	=	false;						
						tendoo.notice.alert( 'Le produit a correctement été ajouté.' , 'success' );
					}
				});
			}
			else
			{
				tendoo.notice.timeout(5000).alert( 'Vous devez spécifier un identifiant pour ajouter un nouveau produit' , 'warning' );
			}
			return false;
		});
		$( 'button[type="submit"]' ).bind( 'click' , function(){
			var $this	=	$(this);
			var form	=	$(this).closest( 'form' );
			if( $(this).text() )
			{
				tendoo.modal.confirm( 'Souhaitez-vous enregistrer cette commande ?' , function(){
					// Purify hidden forms
					$( '.product_id_hidden' ).remove();
					$.map( products , function( value , key ){
						// Empty array are ignored
						if( typeof value.ARTICLE_ID != 'undefined'  )
						{
							input	=	'<input type="hidden" class="product_id_hidden" name="product_list_id[]" value="'+ value.RELATION_ID +'|'+ value.nbr +'">';
							$(form).append( input );
							$(form).submit();
						}
					});
				});
			}
			return false;
		} );
		// Avoid Opening Download Page on Google Chrome
		$.ctrl( 'J' , function( s , events ){
			console.log( events );
			$(document).focus();
		}, [] );
	}
	this.start();
}
</script>