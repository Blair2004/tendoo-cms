<?php
if( gui_is_loaded() )
{
	$this->gui->cols_width( 1 , 2 );
	$this->gui->cols_width( 2 , 2 );
	$this->gui->enable( array( 'loader' , 'submit' ) );
	$setting_namespace	=	'nexo_settings';
	$this->gui->set_meta( array(
		'namespace'			=>	'nexo_settings',
		'title'				=>	__( 'Réglages' ),
		'form_wrap'			=>	array(
			'method'		=>	'POST',
			'gui_saver'		=>	true,
			'submit_text'	=>	__( 'Enregistrer les réglages' ),
			'use_namespace'	=>	true
		) 
	) )->push_to( 1 );
	
	// Looping Limit
	for( $i = 1 ; $i < 30 ; $i++ )
	{
		$value[]	=	$i;
	}
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$value,
		'text'			=>	$value,
		'name'			=>	'provider_pp',
		'label'			=>	__( 'Nombre de fournisseur par page' ),
		'description'	=>	__( 'Affecte le nombre de fournisseurs par page' ),
		'active'		=>	riake( 'provider_pp' , $nexo_settings )
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$value,
		'text'			=>	$value,
		'name'			=>	'shipping_pp',
		'label'			=>	__( 'Nombre d\'arrivage par page' ),
		'description'	=>	__( 'Affecte le nombre d\'arrivage par page' ),
		'active'		=>	riake( 'shipping_pp' , $nexo_settings )
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$value,
		'text'			=>	$value,
		'name'			=>	'product_pp',
		'label'			=>	__( 'Nombre d\'articles par page' ),
		'description'	=>	__( 'Affecte le nombre d\'articles par page' ),
		'active'		=>	riake( 'product_pp' , $nexo_settings )
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$value,
		'text'			=>	$value,
		'name'			=>	'rayon_pp',
		'label'			=>	__( 'Nombre de rayon par page' ),
		'description'	=>	__( 'Affecte le nombre de rayon par page' ),
		'active'		=>	riake( 'rayon_pp' , $nexo_settings )
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$value,
		'text'			=>	$value,
		'name'			=>	'category_pp',
		'label'			=>	__( 'Nombre de categories par page' ),
		'description'	=>	__( 'Affecte le nombre de categories par page' ),
		'active'		=>	riake( 'category_pp' , $nexo_settings )
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$value,
		'text'			=>	$value,
		'name'			=>	'commands_pp',
		'label'			=>	__( 'Nombre de commandes par page' ),
		'description'	=>	__( 'Affecte le nombre de commandes par page' ),
		'active'		=>	riake( 'commands_pp' , $nexo_settings )
	) )->push_to( $setting_namespace );	
	
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$value,
		'text'			=>	$value,
		'name'			=>	'expiration_com_aa',
		'label'			=>	__( 'Validité des commandes avec avance (En jours)' ),
		'description'	=>	__( 'Validifté des commandes avec avance' ),
		'active'		=>	riake( 'expiration_com_aa' , $nexo_settings )
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$value,
		'text'			=>	$value,
		'name'			=>	'expiration_com_sa',
		'label'			=>	__( 'Validité des commandes sans avance (En jours)' ),
		'description'	=>	__( 'Validifté des commandes sans avance' ),
		'active'		=>	riake( 'expiration_com_sa' , $nexo_settings )
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'text',
		'value'			=>	riake( 'devise_boutique' , $nexo_settings ),
		'name'			=>	'devise_boutique',
		'label'			=>	__( 'Devise utilisée' ),
		'description'	=>	__( 'Devise utilisée. Exemple (F CFA, €, $, £)' ),
	) )->push_to( $setting_namespace );
	// Client Privilege
	$role_value 		=	$role_text	=	array();
	foreach( force_array( $roles ) as $_role )
	{
		$role_value[]	=	riake( 'ID' , $_role );
		$role_text[]	=	riake( 'NAME' , $_role );
	}
	$this->gui->set_item( array(
		'type'			=>	'select',
		'value'			=>	$role_value,
		'text'			=>	$role_text,
		'name'			=>	'client_privilege',
		'placeholder'	=>	__( 'Veuillez choisir un privilège' ),
		'label'			=>	__( 'Choisir le privilège qui seriva de client' ),
		'description'	=>	__( 'Tous les utilisateus ayance ce privilège seront considérés comme client.' ),
		'active'		=>	riake( 'client_privilege' , $nexo_settings )
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'text',
		'value'			=>	riake( 'double_compta' , $nexo_settings ),
		'name'			=>	'double_compta',
		'label'			=>	__( 'Définir la marge de la double comptabilité (%)' ),
		'description'	=>	__( 'Définir la marge de la double comptabilité. Définir une valeur comprise entre 0 & 100. à "0" la double comptabilité est désactivée.' ),
	) )->push_to( $setting_namespace );
	
	$_value	=	$value;
	array_unshift( $_value , 0 );
	
	$this->gui->set_item( array(
		'type'			=>	'select',
		'text'			=>	$_value,
		'value'			=>	$_value,
		'active'		=>	riake( 'client_promo' , $nexo_settings ),
		'name'			=>	'client_promo',
		'label'			=>	__( 'Réduction Automatique' ),
		'description'	=>	__( 'Après combien d\'achat un client a droit à une remise. A "0" les réductions sont désactivées.' ),
	) )->push_to( $setting_namespace );
	
	$this->gui->set_item( array(
		'type'			=>	'text',
		'value'			=>	riake( 'pormo_percent' , $nexo_settings ),
		'name'			=>	'pormo_percent',
		'label'			=>	__( 'Montant de la réduction' ),
		'description'	=>	__( 'Définir une valeur fixe pour la réduction.' ),
	) )->push_to( $setting_namespace );
	
	
	$this->gui->get();
	
}
