<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nex_bondav_list',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des bon d\'avoir' )
) )->push_to( 1 );

$bondavoirs_array		=	array();

foreach( force_array( $bondavoirs ) as $_bondav )
{
	$author				=	get_user( riake( 'AUTHOR' , $_bondav ) , 'as_id' );
	$client				=	get_user( riake( 'REF_CLIENT' , $_bondav ) , 'as_id' );
	$the_command		=	farray( $lib->get_commands( riake( 'REF_COMMAND' , $_bondav ) , 'as_id' ) );
	
	$bondavoirs_array[]	=	array( 
		riake( 'CODE' , $the_command , 'Commande indisponible ou supprimée' ), 
		riake( 'client_name' , $client ) == '' ? 'Compte Client' : riake( 'client_name' , $client ) , 
		$lib->get_command_price( riake( 'ID' , $the_command ) , 'as_id' , 'ignore_active_status' ) . ' ' . riake( 'devise_boutique' , $nexo_settings , 'F' ),
		riake( 'DATE_CREATION' , $_bondav ) ,
		riake( 'PSEUDO' , $author , 'Indisponible' ) ,
		'<a target="_blank" href="' . module_url( array( 'bondavoir' , 'printable' , riake( 'ID' , $_bondav ) ) ) . '">Afficher la facture</a>' , 
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer ce bon d\'avoir ?<br> Les commandes concernées retrouveront leurs produits. ' ) . '" href="' . module_url( array( 'bondavoir' , 'delete' , riake( 'ID' , $_bondav ) ) ) . '"> Supprimer le bon d\'avoir </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Bon d\'avoir pour la commande' ) , __( 'Client' ) , __( 'Valeur du bon d\'avoir' ) , __( 'Date de création' ) , __( 'Par' ) , __( 'Factures' ) , __( 'Supprimer' ) ),
	'rows'			=>  $bondavoirs_array
) )->push_to( 'nex_bondav_list' );

$this->gui->get();