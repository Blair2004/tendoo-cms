<?php
$this->gui->cols_width( 1 , 3 );
$this->gui->cols_width( 2 , 1 );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'create' , 'clients' ) ),
	'title'		=>	__( 'Ajouter un client' ),
	'form_wrap'	=>	array(
		'type'	=>	'post',
		'submit_text'	=>	__( 'Modifier le client' ),
		'reset_text'	=>	__( 'Effacer le formulaire' )
	)
) )->push_to( 1 );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'client_name',
	'placeholder'	=>	__( 'Entrer son nom' ),
	'value'		=>	riake( 'client_name' , $client ),
	'label'		=>	__( 'Nom' ),
	'description'	=>	__( 'Assurez-vous que le nom du client soit unique.' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'client_bp',
	'placeholder'	=>	__( 'Boite postale du client' ),
	'value'		=>	riake( 'client_bp' , $client ),
	'label'		=>	__( 'BP' ),
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'num_cli',
	'placeholder'	=>	__( 'Num/Raison Sociale' ),
	'value'		=>	riake( 'num_cli' , $client ),
	'label'		=>	__( 'Num/Raison Sociale' ),
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'client_tel',
	'placeholder'	=>	__( 'Numéro de téléphone' ),
	'label'		=>	__( 'Numéro de téléphone' ),
	'value'		=>	riake( 'client_tel' , $client ),
	'description'	=>	__( 'Numéro de téléphone du client.' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'client_email',
	'placeholder'	=>	__( 'E-mail du client' ),
	'label'			=>	__( 'E-mail du client' ),
	'value'		=>	riake( 'EMAIL' , $client ),
	'description'	=>	__( 'Définir une adresse e-mail pour le client.' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'lieu_de_travail_client',
	'placeholder'	=>	__( 'Lieu de travail' ),
	'label'		=>	__( 'Lieu de travail' ),
	'value'		=>	riake( 'lieu_de_travail_client' , $client ),
	'description'	=>	__( 'Lieu de travail du client' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'domicile_client',
	'placeholder'	=>	__( 'Domicile client' ),
	'label'		=>	__( 'Domicile client' ),
	'value'		=>	riake( 'domicile_client' , $client ),
	'description'	=>	__( 'Domicile du client' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'preference_client',
	'placeholder'	=>	__( 'Préférence client' ),
	'label'		=>	__( 'Préférence client' ),
	'value'		=>	riake( 'preference_client' , $client ),
	'description'	=>	__( 'Préférence du client' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'preference_vestimentaire_client',
	'value'		=>	riake( 'preference_vestimentaire_client' , $client ),
	'placeholder'	=>	__( 'Préférence vestimentaire client' ),
	'label'		=>	__( 'Préférence vestimentaire client' ),
	'description'	=>	__( 'Préférence vestimentaire du client' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'select',
	'name'		=>	'alert_pub',
	'active'	=>	riake( 'alert_pub' , $client ),
	'value'		=>	array( 0 , 1 , 2 ),
	'text'		=>	array( 'Hebdomadaire' , '2 semaines' , 'mensuelle' ),
	'placeholder'	=>	__( 'Alerte publicitaire' ),
	'label'		=>	__( 'Alerte publicitaire' ),
	'description'	=>	__( 'Activer les alertes publicitaires pour le client.' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'select',
	'name'		=>	'mode',
	'active'	=>	riake( 'mode' , $client ),
	'value'		=>	array( 'sms' , 'email' , 'both' ),
	'text'		=>	array( 'Sms' , 'E-mail' , 'Les deux' ),
	'placeholder'	=>	__( 'Mode de l\'alerte' ),
	'label'		=>	__( 'Mode de l\'alerte' ),
	'description'	=>	__( 'Définir le mode de l\'alerte.' )
) )->push_to( meta_namespace( array( 'create' , 'clients' ) ) );

$this->gui->get();