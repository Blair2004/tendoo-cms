<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_fournisseurs',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des rayons' )
) )->push_to( 1 );

$rayon_array		=	array();

foreach( $rayons as $_rayon )
{
	$author			=	get_user( riake( 'AUTHOR' , $_rayon ) , 'as_id' );
	$nbr_used		=	$lib->get_product_related( 'rayon' , riake( 'ID' , $_rayon ) );
	$rayon_array[]	=	array( 
		'<a href="' . module_url( array( 'rayons' , 'edit' , riake( 'ID' , $_rayon ) ) ) . '">' . riake( 'TITRE' , $_rayon ) . '</a>' , 
		count( $nbr_used ) > 0 ? count( $nbr_used ). 'fois' : 'Non' , 
		riake( 'DATE_CREATION' , $_rayon ) ,
		timespan( riake( 'DATE_MODIFICATION' , $_rayon ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer ce rayon ?<br>Cette opération risque affecter certains produits.' ) . '" href="' . module_url( array( 'rayons' , 'delete' , riake( 'ID' , $_rayon ) ) ) . '"> Supprimer le rayon </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Intitulé du rayon' ) , __( 'Utilisé (x fois)' ) , __( 'Date de création' ) , __( 'Modifié' ) , __( 'Par' ) , __( 'Supprimer' ) ),
	'rows'			=>  $rayon_array
) )->push_to( 'nexo_fournisseurs' );

$this->gui->get();