<div class="panel">
	<div class="panel-body">
    	<div class="row">
        	<div class="col-lg-6">
                <h3 style="margin:0;">Valeur du bon d'avoir :</h3>
                <h1><span class="valeur_bon">0</span> <?php echo riake( 'devise_boutique' , $nexo_settings , 'F' );?></h1>
            </div>
            <div class="col-lg-6">
            	<h3 style="margin:0;">Informations sur le client :</h3>
                <h4>Nom : <span class="client_name"></span></h4>
                <h4>BP : <span  class="client_bp"></span></h4>
                <h4>Email : <span class="client_email"></span></h4>
                <h4>Tel : <span class="client_tel"></span></h4>
            </div>
        </div>
    </div>
</div>