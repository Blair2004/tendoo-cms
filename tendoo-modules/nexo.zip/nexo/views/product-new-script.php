<script>
	function isInt(n){
		return Number(n)===n && n%1===0;
	}
	function isFloat(n) {
		return n === +n && n !== (n|0);
	}
	function show_prix_de_vente()
	{
		var prix_da		=	isNaN( parseInt( $('[name="prix_dachat"]').val() ) ) ? 0 : parseInt( $('[name="prix_dachat"]').val() );
		var frais_acess	=	isNaN( parseInt( $('[name="frais_access"]').val() ) ) ? 0 : parseInt( $('[name="frais_access"]').val() );
		var taux_marge	=	! isFloat( parseFloat( $('[name="taux_marge"]').val() ) ) && ! isInt( parseFloat( $('[name="taux_marge"]').val() ) ) ? 0 : parseFloat( $('[name="taux_marge"]').val() );
		var prix_vente	=	( prix_da + frais_acess ) * taux_marge;
		$( '#prix_de_vente' ).val( prix_vente );
		//
	}
	function check_if_product_exists()
	{
		var text		=	$('[name="designation_produit"]').val();
		$.ajax( '<?php echo module_url( array( 'articles' , 'check-if-exist' ) );?>',{
			beforeSend : function(){
				tendoo.loader.show();
			},
			success	:	function( a ){
				__check_if_product_exist( a );
			},
			data	:	{
				'field_name'	:	text
			},
			type:'POST',
			dataType:"json"
			
		});
	}
	function automate_taux_de_marge()
	{
		var whished_price	=	isInt( parseInt( $('#price_whished').val() ) ) ? parseInt( $('#price_whished').val() ) : 0;
		// var taux_de_marge	=	$('[name="taux_marge"]').val();
		var frais_access	=	parseInt( $('[name="frais_access"]').val() );
		var prix_dachat		=	parseInt( $('[name="prix_dachat"]').val() );
		//
		var cout_dachat		=	( parseInt( frais_access ) + parseInt( prix_dachat ) )
		var real_tmarge		=	whished_price / cout_dachat;
		
		$('[name="taux_marge"]').val( real_tmarge ).focus().keyup().blur();
		$('#price_whished').focus();
	}
	function __check_if_product_exist( passed )
	{
		if( passed.product_exists == true )
		{
			tendoo.modal.confirm( 'Un produit ayant ce nom existe déjà, souhaitez-vous ajouter des produits dans le stock ?<br>Si vous continuez, vous devez choisir un autre nom.' , function(){
				document.location = '<?php echo module_url( array( 'articles' , 'edit' ) );?>/' + passed.product_id + '?notice=update-stock';
			})
			$('[name="designation_produit"]').val('').attr( 'placeholder' , 'Veuillez choisir une autre désignation pour le produit' );
		}
	}
	$(document).ready( function(){
		$('[name="prix_dachat"]').bind( 'keyup' , function(){
			show_prix_de_vente();
		})
		$('[namep="frais_access"]').bind( 'keyup' , function(){
			show_prix_de_vente();
		})
		$('[name="taux_marge"]').bind( 'keyup' , function(){
			show_prix_de_vente();
		})
		$('[name="designation_produit"]').bind( 'blur' , function(){
			check_if_product_exists();
		});
		$('#price_whished').bind( 'keyup' , function(){
			automate_taux_de_marge();
		});
	});
</script>