<?php
$module	= get_modules( 'filter_namespace' , 'nexo' );
module_include( 'library.php' , 'nexo' );
$reglages	=	get_meta( 'nexo_settings' );
$client_id	=	riake( 'client_privilege' , $reglages );

$lib		=	new nexo_class;
		$cash	=	$lib->get_cash();
		$rayons	=	count( $lib->get_rayons() );
		// Quantité disponible
		$totalQte	=	0;
		foreach( $lib->get_product( null, null , 'sum' ) as $__product )
		{
			$totalQte	+= riake( 'QUANTITY' , $__product );
		}
		$totalQte	-=	$lib->get_products_sold_global( 'quantity' ); // reductiona avec le nombre de produits vendus
		// Quantité disponible fin.
		$today_command	=	count( $lib->get_commands( $lib->morning , 'as_date_asc' ) );
		$shipping		=	count( $lib->get_shipping() );
?>
<div class="panel">
	<div class="panel-heading"><h4>Vue d'ensemble sur la boutique</h4></div>
    	<ul class="list-group no-radius">
			<li class="list-group-item"> <span class="badge <?php echo theme_class();?>"><?php echo $cash ;?></span><?php _e( 'Montant prévisionnel de la caisse' );?></li>
            <?php
			if( $client_id )
			{
				$clients	=	count( get_instance()->roles->get_users_with_role( $client_id ) );
				?>
			<li class="list-group-item"> <span class="badge <?php echo theme_class();?>"><?php echo $clients ;?></span><?php _e( 'Nombre de clients enregistrés' );?></li>
                <?php
			}
			else
			{
				?>
			<li class="list-group-item"> <?php _e( 'Aucun client disponible. Pensez à en ajouter lors d\'une commande.' );?></li>
                <?php
			}
			?>
            <li class="list-group-item"> <span class="badge <?php echo theme_class();?>"><?php echo $rayons ;?></span><?php _e( 'Nombre de rayons disponibles' );?></li>
            <li class="list-group-item"> <span class="badge <?php echo theme_class();?>"><?php echo $totalQte ;?></span><?php _e( 'Nombre d\'articles disponibles' );?></li>
            <li class="list-group-item"> <span class="badge <?php echo theme_class();?>"><?php echo $today_command ;?></span><?php _e( 'Nombre de commandes passées aujourd\'hui' );?></li>
            <li class="list-group-item"> <span class="badge <?php echo theme_class();?>"><?php echo $shipping ;?></span><?php _e( 'Nombre d\'arrivages' );?></li>
		</ul>
</div>