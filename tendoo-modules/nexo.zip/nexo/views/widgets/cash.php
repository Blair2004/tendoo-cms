<?php
$module	= get_modules( 'filter_namespace' , 'nexo' );
module_include( 'library.php' , 'nexo' );
$reglages	=	get_meta( 'nexo_settings' );

		$lib			=	new nexo_class;
		$cash			=	$lib->get_cash( 'real' );
		$cash_doit		=	$lib->get_cash( 'facture-doit' );
		$cash_avance	=	$lib->get_cash( 'facture-avance' );
?>
<div class="panel">
	<div class="panel-body">
    	<h4>Solde de la caisse</h4>
    	<h1><?php echo $cash . ' ' . riake( 'devise_boutique' , $reglages );?></h1>
        <hr class="line-dashed" />
        <h5>Solde Factures doit</h5>
        <h6><?php echo $cash_doit . ' ' . riake( 'devise_boutique' , $reglages );?></h6>
        <h5>Solde Factures avances</h5>
        <h6><?php echo $cash_avance . ' ' . riake( 'devise_boutique' , $reglages );?></h6>
    </div>
</div>