<?php
$module	= get_modules( 'filter_namespace' , 'nexo' );
module_include( 'library.php' , 'nexo' );
$reglages	=	get_meta( 'nexo_settings' );

		$lib			=	new nexo_class;
		$cash_today		=	$lib->get_cash( 'real-today' );
		$cash			=	$lib->get_cash( 'real' );
		$cash_doit		=	$lib->get_cash( 'facture-doit-today' );
		$cash_avance	=	$lib->get_cash( 'facture-avance-today' );
?>
<div class="panel">
	<div class="panel-body">
		<h4>Solde de la caisse du jour</h4>
    	<h1><?php echo $lib->money_format( $cash_today , riake( 'devise_boutique' , $reglages ) );?></h1>	
        <hr class="line-dashed" />
		<h5>Solde de la caisse cumulé</h5>
    	<h5><?php echo $lib->money_format( $cash , riake( 'devise_boutique' , $reglages ) );?></h5>
        <h5>Solde Factures doit</h5>
        <h6><?php echo $lib->money_format( $cash_doit , riake( 'devise_boutique' , $reglages ) );?></h6>
        <h5>Solde Factures avances</h5>
        <h6><?php echo $lib->money_format( $cash_avance , riake( 'devise_boutique' , $reglages ) );?></h6>
    </div>
</div>