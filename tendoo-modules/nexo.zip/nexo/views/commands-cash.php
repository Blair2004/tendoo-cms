<div class="panel">
	<div class="panel-body">
    	<h1 style="margin:10px 0;">Total : <span id="price">0</span> <?php echo riake( 'devise_boutique' , $nexo_settings , 'F' );?></h1>
    </div>
</div>