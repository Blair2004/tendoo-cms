<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_input_list',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des sorties extraordinaires' ) 
) )->push_to( 1 );

$inputs_array		=	array();

foreach( $inputs as $_input )
{
	$author			=	get_user( riake( 'AUTHOR' , $_input ) , 'as_id' );	
	$inputs_array[]	=	array( 
		'<a href="' . module_url( array( 'flux' , 'output' , 'edit' , riake( 'ID' , $_input ) ) ) . '">' . riake( 'TITLE' , $_input ) . '</a>' , 
		riake( 'MONTANT' , $_input , 'Somme inconnu' ) . ' ' . riake( 'devise_boutique' , $nexo_settings ),
		riake( 'DATE_CREATION' , $_input ) ,
		timespan( riake( 'DATE_MODIFICATION' , $_input ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer cette sortie extraordinaire ?<br> Cette opération risque affecter les calculs sur l\'application.' ) . '" href="' . module_url( array( 'flux' , 'output' , 'delete' , riake( 'ID' , $_input ) ) ) . '"> Supprimer l\'entrée </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Désignation' ) , __( 'Montant' ) , __( 'Date de création' ) , __( 'Modifié' ) , __( 'Par' ) , __( 'Supprimer' ) ),
	'rows'			=>  $inputs_array
) )->push_to( 'nexo_input_list' );

$this->gui->get();