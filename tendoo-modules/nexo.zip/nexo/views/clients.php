<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_client_list',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des clients' )
) )->push_to( 1 );

$clients_array		=	array();

foreach( $clients as $_client )
{
	$current_client	=	get_user( riake( 'USER_ID' , $_client ) , 'as_id' );
	$client_name	=	( $_i	=	riake( 'client_name' , $current_client , 'Indisponible' ) ) == false ? 'Indisponible' : $_i;
	$nbr_commandes	=	0;
	$clients_array[]	=	array( 
		'<a href="' . module_url( array( 'clients' , 'edit' , riake( 'ID' , $current_client ) ) ) . '">' . $client_name . '</a>' , 
		riake( 'EMAIL' , $current_client ) ,
		$nbr_commandes, 
		timespan( riake( 'REG_DATE' , $current_client ) ),
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer ce client ?<br> Certaines commandes ne seront plus attributées.' ) . '" href="' . module_url( array( 'clients' , 'delete' , riake( 'ID' , $current_client ) ) ) . '"> Supprimer le client </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Nom' ) , __( 'Email' ) , __( 'Commandes effectuées' ) , __( 'Inscrit depuis' ) ),
	'rows'			=>  $clients_array
) )->push_to( 'nexo_client_list' );

$this->gui->get();