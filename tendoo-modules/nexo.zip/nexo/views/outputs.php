<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_input_list',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des entrées extraordinaires' ) 
) )->push_to( 1 );

$inputs_array		=	array();

foreach( $inputs as $_input )
{
	$author			=	get_user( riake( 'AUTHOR' , $_input ) , 'as_id' );	
	$inputs_array[]	=	array( 
		'<a href="' . module_url( array( 'flux' , 'output' , 'edit' , riake( 'ID' , $_input ) ) ) . '">' . riake( 'TITRE' , $_input ) . '</a>' , 
		riake( 'MONTANT' , $category , 'Somme inconnu' ) . riake( 'devise_boutique' , $nexo_settings ),
		riake( 'DATE_CREATION' , $_input ) ,
		timespan( riake( 'DATE_MODIFICATION' , $_input ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer ce produits ?<br> Cette opération risque affecter les calculs sur l\'application. Toutes les commandes qui où sont ajoutés ce produit, seront également affectées.' ) . '" href="' . module_url( array( 'articles' , 'delete' , riake( 'ARTICLE_ID' , $_input ) ) ) . '"> Supprimer le produit </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Désignation' ) , __( 'Montant' ) , __( 'Date de création' ) , __( 'Modifié' ) , __( 'Par' ) , __( 'Supprimer' ) ),
	'rows'			=>  $inputs_array
) )->push_to( 'nexo_input_list' );

$this->gui->get();