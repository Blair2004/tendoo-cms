<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<title>Fiche récapitulative</title>
</head>
<?php
$format				=	'full';
if( $format == 'A5' )
{
	$width	=	792;
	$height	=	560;
	$css	=	'font-size:80% !important;';
}
if( $format == 'full' )
{
	$width	=	'100%';
	$height	=	560;
	$css	=	'font-size:80% !important;';
}
?>
<body>
    <div class="container" style="width:<?php echo $width;?>px;min-height:<?php echo $height;?>px;<?php echo $css;?>">
    <div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3>FICHE RECAPITULATIVE POUR L'ARRIVAGE : <?php echo riake( 'TITRE' , $shipping );?></h3>
            </div>
            <hr style="margin:0 1%;">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                        	<td><strong>Totaux</strong></td>
                            <td><strong>UNIVERS</strong></td>
                            <td class="text-center"><strong>FAMILLES</strong></td>
                            <td class="text-center"><strong>SOUS-FAMILLE</strong></td>
                            <td class="text-center"><strong>CATEGORIES</strong></td>
                            <td class="text-center"><strong>SOUS-CATEGORIES</strong></td>
                            <td class="text-center"><strong>STOCK</strong></td>
                            <td class="text-right"><strong>CA. Glob</strong></td>
                            <td class="text-right"><strong>PV. Glob</strong></td>
                            <td class="text-right"><strong>MARGE</strong></td>
                            <td class="text-right"><strong>TAUX DE MARGE</strong></td>
                        </tr>
                    </thead>
                    <tbody>
    <?php
	$univ_quantity							=		0;
	$univ_ca								=		0;
	$univ_pv								=		0;
	$univ_marge								=		0;
	$univ_tmarge							=		0;
	foreach( force_array( $parent_categories ) as $_parent )
	{
		$familles	=	$lib->get_category( riake( 'ID' , $_parent ) , 'as_parent' , 0 , 'name_asc' );
		
		$fam_total_quantity								=		0;
		$fam_total_ca									=		0;
		$fam_total_pv									=		0;
		$fam_total_marge								=		0;
		$fam_total_tmarge								=		0;
			
		if( force_array( $familles ) )
		{
			foreach( force_array( $familles ) as $_famille )
			{
				// Reset Familly Count
				$fam_quantity							=		0;
				$fam_ca									=		0;
				$fam_pv									=		0;
				$fam_marge								=		0;
				$fam_tmarge								=		0;
				//
				$sous_fam_total_quantity						=	0;
				$sous_fam_total_ca								=	0;
				$sous_fam_total_pv								=	0;
				$sous_fam_total_marge							=	0;
				$sous_fam_total_tmarge							=	0;
				
				$sous_famille							=	$lib->get_category( riake( 'ID' , $_famille ) , 'as_parent' , 0 , 'name_asc' );				
				
				foreach( force_array( $sous_famille ) as $_sous_fam )
				{		
					// Permet d'éviter le cumul dans les comptes
					$sous_fam_quantity							=	0;
					$sous_fam_ca								=	0;
					$sous_fam_pv								=	0;
					$sous_fam_marge								=	0;
					$sous_fam_tmarge							=	0;
					
					$cat_total_quantity									=	0;
					$cat_total_ca										=	0;
					$cat_total_pv										=	0;
					$cat_total_marge									=	0;
					$cat_total_tmarge									=	0;													
					
					$category		=	$lib->get_category( riake( 'ID' , $_sous_fam ) , 'as_parent' , 0 , 'name_asc' );
					// Verifie une catégorie est utilisée en tant que parent.
					if( force_array( $category ) )
					{
						foreach( force_array( $category ) as $_cat )
						{	
							// Reset	
							$sous_cat_total_quantity			=	0;
							$sous_cat_total_ca					=	0;
							$sous_cat_total_pv					=	0;
							$sous_cat_total_marge				=	0;
							$sous_cat_total_tmarge				=	0;	
													
							$sous_cat							=	$lib->get_category( riake( 'ID' , $_cat ) , 'as_parent' , 0 , 'name_asc' );
							
							$cat_quantity						=	0;
							$cat_ca								=	0;
							$cat_pv								=	0;
							$cat_marge							=	0;
							$cat_tmarge							=	0;
							
							if( force_array( $sous_cat ) )
							{
								// S'il existe une sous catégorie
								foreach( force_array( $sous_cat ) as $_scat )
								{
									// RESET
									$cout_dachat_global			=	0;
									$quantity					=	0;
									$global_vente				=	0;
									$sous_cat_quantity			=	0;
									$sous_cat_ca				=	0;
									$sous_cat_pv				=	0;
									$sous_cat_marge				=	0;
									$sous_cat_tmarge			=	0;
									// ...
									$get_products	=	$lib->get_product( 	array(
										'category_id'		=>	riake( 'ID' , $_scat ),
										'shipping_id'		=>	$shipping_id	
									) , 'as_category_and_shipping'  );
									foreach( $get_products as $_product )
									{
										$unique_quantity	=	( riake( 'QUANTITY' , $_product ) - riake( 'DEFECTUEUX' , $_product ) );
										$cout_dachat_unique	=	( riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) ) * $unique_quantity;
										$unique_vente_glob	=	( ( riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) ) * riake( 'TAUX_DE_MARGE' , $_product ) ) * $unique_quantity;
										$quantity			+=	$unique_quantity;
										$cout_dachat_global	+=	$cout_dachat_unique;
										$global_vente		+=	$unique_vente_glob;									
									}
									
									// Affecting
									$sous_cat_total_quantity		+=	$sous_cat_quantity	=	$quantity;
									$sous_cat_total_ca				+=	$sous_cat_ca		=	$cout_dachat_global;
									$sous_cat_total_pv				+=	$sous_cat_pv		=	$global_vente;
									$sous_cat_total_marge			+=	$sous_cat_marge		=	$marge	=	( $global_vente - $cout_dachat_global );
									$sous_cat_total_tmarge			+=	$sous_cat_tmarge	=	$tmarge	=	( int ) $global_vente == 0 ? 0 : ( $global_vente - $cout_dachat_global ) / $global_vente;
									?>
									<tr>
										<td class="text-center"></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_parent );?></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_famille );?></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_sous_fam );?></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_cat );?></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_scat );?></td>
										<td class="text-center"><?php echo $quantity;?></td>
										<td class="text-center"><?php echo $lib->money_format( $cout_dachat_global , '' );?></td>
										<td class="text-center"><?php echo $lib->money_format( $global_vente , '' );?></td>
										<td class="text-center"><?php echo $lib->money_format( $marge	,  '' );?></td>
										<?php
										if( ( int ) $global_vente == 0 )
										{
										?>
										<td class="text-center">0</td>
										<?php
										}
										else
										{
											?>
										<td class="text-center"><?php echo $tmarge;?></td>
											<?php
										}
										?>
									</tr>
								<?php
								}
								
								// Category Attribution
								
								$cat_quantity				+=	$sous_cat_quantity;
								$cat_ca						+=	$sous_cat_ca;
								$cat_pv						+=	$sous_cat_pv;
								$cat_marge					+=	$sous_cat_marge;
								$cat_tmarge					+=	$sous_cat_tmarge;
							}
							else
							{
								$quantity				=	0;
								$cout_dachat_global		=	0;
								$global_vente			=	0;
								
								$get_products			=	$lib->get_product( array(
									'category_id'		=>	riake( 'ID' , $_cat ),
									'shipping_id'		=>	$shipping_id	
								) , 'as_category_and_shipping' );
								foreach( $get_products as $_product )
								{
									$unique_quantity	=	( riake( 'QUANTITY' , $_product ) - riake( 'DEFECTUEUX' , $_product ) );
									$cout_dachat_unique	=	( riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) ) * $unique_quantity;
									$unique_vente_glob	=	( ( riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) ) * riake( 'TAUX_DE_MARGE' , $_product ) ) * $unique_quantity;
									$quantity			+=	$unique_quantity;
									$cout_dachat_global	+=	$cout_dachat_unique;
									$global_vente		+=	$unique_vente_glob;
								}
								
								// Affecting
								
								$cat_quantity				+=	$quantity;
								$cat_ca						+=	$cout_dachat_global;
								$cat_pv						+=	$global_vente;
								$cat_marge					+=	$marge	=	$global_vente - $cout_dachat_global;
								$cat_tmarge					+=	$tmarge	=	( int ) $global_vente == 0 ? 0 : ( $global_vente - $cout_dachat_global ) / $global_vente;
								
								?>
									<tr>
										<td class="text-center"></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_parent );?></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_famille );?></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_sous_fam );?></td>
										<td class="text-center"><?php echo riake( 'NOM' , $_cat );?></td>
										<td class="text-center"></td>
										<td class="text-center"><?php echo $quantity;?></td>
										<td class="text-center"><?php echo $lib->money_format( $cout_dachat_global , '' );?></td>
										<td class="text-center"><?php echo $lib->money_format( $global_vente , '' );?></td>
										<td class="text-center"><?php echo $lib->money_format( $marge ,  '' );?></td>
										<?php
										if( ( int ) $global_vente == 0 )
										{
										?>
										<td class="text-center">0</td>
										<?php
										}
										else
										{
											?>
										<td class="text-center"><?php echo $cat_tmarge;?></td>
											<?php
										}
										?>
									</tr>
								<?php
							}
							if( force_array( $sous_cat ) ) // Uniquement lorsque les catégories contienent des sous-catégories
							{
							?>
						<tr style="background:#FFF1C4">
							<td class="text-center"><?php echo __( 'Total Catégories' . ' ' . riake( 'NOM' , $_cat ));?></td>
							<td class="text-center"></td>
							<td class="text-center"></td>
							<td class="text-center"></td>
							<td class="text-center"></td>
							<td class="text-center"></td>
							<td class="text-center"><?php echo $cat_quantity;?></td>
							<td class="text-center"><?php echo $lib->money_format( $cat_ca , '' );?></td>
							<td class="text-center"><?php echo $lib->money_format( $cat_pv , '' );?></td>
							<td class="text-center"><?php echo $lib->money_format( $cat_marge , '' );?></td>
							<td class="text-center"><?php echo $cat_tmarge;?></td>
						</tr>
						<?php
							}
							
							$cat_total_quantity					+=	$cat_quantity;
							$cat_total_ca						+=	$cat_ca;
							$cat_total_pv						+=	$cat_pv;
							$cat_total_marge					+=	$cat_marge;
							$cat_total_tmarge					+=	$cat_tmarge;
						}
						
						$sous_fam_quantity				+=	$cat_total_quantity;
						$sous_fam_ca					+=	$cat_total_ca;
						$sous_fam_pv					+=	$cat_total_pv;
						$sous_fam_marge					+=	$cat_total_marge;
						$sous_fam_tmarge				+=	$cat_total_tmarge;
					}
					else
					{
						$quantity				=	0;
						$cout_dachat_global		=	0;
						$global_vente			=	0;
						
						$get_products	=	$lib->get_product( array(
							'category_id'		=>	riake( 'ID' , $_sous_fam ),
							'shipping_id'		=>	$shipping_id	
						) , 'as_category_and_shipping' );
						foreach( $get_products as $_product )
						{
							$unique_quantity	=	( riake( 'QUANTITY' , $_product ) - riake( 'DEFECTUEUX' , $_product ) );
							$cout_dachat_unique	=	( riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) ) * $unique_quantity;
							$unique_vente_glob	=	( ( riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) ) * riake( 'TAUX_DE_MARGE' , $_product ) ) * $unique_quantity;
							$quantity			+=	$unique_quantity;
							$cout_dachat_global	+=	$cout_dachat_unique;
							$global_vente		+=	$unique_vente_glob;
						}
						
						// Affecting
						
						$sous_fam_quantity				+=	$quantity;
						$sous_fam_ca					+=	$cout_dachat_global;
						$sous_fam_pv					+=	$global_vente;
						$sous_fam_marge					+=	$marge	=	$global_vente - $cout_dachat_global;
						$sous_fam_tmarge				+=	$tmarge	=	( int ) $global_vente == 0 ? 0 : ( $global_vente - $cout_dachat_global ) / $global_vente ;

						?>
						<tr>
							<td class="text-center"></td>
							<td class="text-center"><?php echo riake( 'NOM' , $_parent );?></td>
							<td class="text-center"><?php echo riake( 'NOM' , $_famille );?></td>
							<td class="text-center"><?php echo riake( 'NOM' , $_sous_fam );?></td>
							<td class="text-center"></td>
							<td class="text-center"></td>
							<td class="text-center"><?php echo $quantity;?></td>
							<td class="text-center"><?php echo $lib->money_format( $cout_dachat_global , '' );?></td>
							<td class="text-center"><?php echo $lib->money_format( $global_vente , '' );?></td>
							<td class="text-center"><?php echo $lib->money_format( $sous_fam_marge ,  '' );?></td>
							<?php
							if( ( int ) $global_vente == 0 )
							{
							?>
							<td class="text-center">0</td>
							<?php
							}
							else
							{
								?>
							<td class="text-center"><?php echo $sous_fam_tmarge;?></td>
								<?php
							}
							?>
						</tr>
						<?php
					}
					?>
                    <tr class="bg-warning">
                        <td class="text-center"><?php echo __( 'Total Sous-famille' . ' ' . riake( 'NOM' , $_sous_fam ) );?></td>
                        <td class="text-center"></td>
                        <td class="text-center"></td>
                        <td class="text-center"></td>
                        <td class="text-center"></td>
                        <td class="text-center"></td>
                        <td class="text-center"><?php echo $sous_fam_quantity;?></td>
                        <td class="text-center"><?php echo $lib->money_format( $sous_fam_ca , '' );?></td>
                        <td class="text-center"><?php echo $lib->money_format( $sous_fam_pv , '' );?></td>
                        <td class="text-center"><?php echo $lib->money_format( $sous_fam_marge ,  '' );?></td>
                        <td class="text-center"><?php echo $sous_fam_tmarge;?></td>
                    </tr>
                    <?php
					$sous_fam_total_quantity					+=	$sous_fam_quantity;
					$sous_fam_total_ca							+=	$sous_fam_ca;
					$sous_fam_total_pv							+=	$sous_fam_pv;
					$sous_fam_total_marge						+=	$sous_fam_marge;
					$sous_fam_total_tmarge						+=	$sous_fam_tmarge;	
				}
			
				$fam_quantity							+=	$sous_fam_total_quantity;
				$fam_ca									+=	$sous_fam_total_ca;
				$fam_pv									+=	$sous_fam_total_pv;
				$fam_marge								+=	$sous_fam_total_marge;
				$fam_tmarge								+=	$sous_fam_total_tmarge;
				
				$fam_total_quantity						+=	$fam_quantity;
				$fam_total_ca							+=	$fam_ca;
				$fam_total_pv							+=	$fam_pv;
				$fam_total_marge						+=	$fam_marge;
				$fam_total_tmarge						+=	$fam_tmarge;

			?>
            <tr class="bg-success">
            	<td class="text-center"><?php echo __( 'Total Famille' . ' ' . riake( 'NOM' , $_famille ) );?></td>
                <td class="text-center"></td>
                <td class="text-center"></td>
                <td class="text-center"></td>
                <td class="text-center"></td>
                <td class="text-center"></td>
                <td class="text-center"><?php echo $fam_quantity;?></td>
                <td class="text-center"><?php echo $lib->money_format( $fam_ca , '' );?></td>
                <td class="text-center"><?php echo $lib->money_format( $fam_pv , '' );?></td>
                <td class="text-center"><?php echo $lib->money_format( $fam_marge , '' );?></td>
                <td class="text-center"><?php echo $fam_tmarge;?></td>
            </tr>
            <?php	
			}
			
			$univ_quantity							+=		$fam_total_quantity;
			$univ_ca								+=		$fam_total_ca;
			$univ_pv								+=		$fam_total_pv;
			$univ_marge								+=		$fam_total_marge;
			$univ_tmarge							+=		$fam_total_tmarge;
		}
		else
		{
			$get_products			=	$lib->get_product( array(
				'category_id'		=>	riake( 'ID' , $_parent ),
				'shipping_id'		=>	$shipping_id	
			) , 'as_category_and_shipping'  );
			$quantity				=	0;
			$cout_dachat_global		=	0;
			$global_vente			=	0;
			
			foreach( $get_products as $_product )
			{
				$unique_quantity	=	( riake( 'QUANTITY' , $_product ) - riake( 'DEFECTUEUX' , $_product ) );
				$cout_dachat_unique	=	( riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) ) * $unique_quantity;
				$unique_vente_glob	=	( ( riake( 'PRIX_DACHAT' , $_product ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) ) * riake( 'TAUX_DE_MARGE' , $_product ) ) * $unique_quantity;
				$quantity			+=	$unique_quantity;
				$cout_dachat_global	+=	$cout_dachat_unique;
				$global_vente		+=	$unique_vente_glob;
			}
			
			$fam_total_quantity				+=	$quantity;
			$fam_total_ca					+=	$cout_dachat_global;
			$fam_total_pv					+=	$global_vente;
			$fam_total_marge				+=	$global_vente - $cout_dachat_global;
			$fam_total_tmarge				+=	( int ) $global_vente == 0 ? 0 : ( $global_vente - $cout_dachat_global ) / $global_vente;
			?>
				<tr>
					<td class="text-center"></td>
					<td class="text-center"><?php echo riake( 'NOM' , $_parent );?></td>
					<td class="text-center"></td>
					<td class="text-center"></td>
					<td class="text-center"></td>
					<td class="text-center"></td>
					<td class="text-center"><?php echo $quantity;?></td>
					<td class="text-center"><?php echo $lib->money_format( $cout_dachat_global , '' );?></td>
					<td class="text-center"><?php echo $lib->money_format( $global_vente , '' );?></td>
					<td class="text-center"><?php echo $lib->money_format( $fam_marge ,  '' );?></td>
					<?php
					if( ( int ) $global_vente == 0 )
					{
					?>
					<td class="text-center">0</td>
					<?php
					}
					else
					{
						?>
					<td class="text-center"><?php echo $fam_tmarge;?></td>
						<?php
					}
					?>
				</tr>
			<?php
			$univ_quantity							+=		$fam_total_quantity;
			$univ_ca								+=		$fam_total_ca;
			$univ_pv								+=		$fam_total_pv;
			$univ_marge								+=		$fam_total_marge;
			$univ_tmarge							+=		$fam_total_tmarge;
		}
		?>
        <tr class="bg-info">
        	<td class="text-center"><?php echo __( 'Total Univers' . ' ' . riake( 'NOM' , $_parent ) );?></td>
        	<td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"></td>
            <td class="text-center"><?php echo $fam_total_quantity;?></td>
            <td class="text-center"><?php echo $lib->money_format( $fam_total_ca , '' );?></td>
            <td class="text-center"><?php echo $lib->money_format( $fam_total_pv , '' );?></td>
            <td class="text-center"><?php echo $lib->money_format( $fam_total_marge , '' );?></td>
            <td class="text-center"><?php echo $fam_total_tmarge;?></td>
        </tr>
        <?php
	}
	?>
    <tr style="background:#FFB9B9">
        <td class="text-center"><?php echo __( 'Total Collection' );?></td>
        <td class="text-center"></td>
        <td class="text-center"></td>
        <td class="text-center"></td>
        <td class="text-center"></td>
        <td class="text-center"></td>
        <td class="text-center"><?php echo $univ_quantity;?></td>
        <td class="text-center"><?php echo $lib->money_format( $univ_ca , '' );?></td>
        <td class="text-center"><?php echo $lib->money_format( $univ_pv , '' );?></td>
        <td class="text-center"><?php echo $lib->money_format( $univ_marge , '' );?></td>
        <td class="text-center"><?php echo $univ_tmarge;?></td>
    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>
    </div>
</div>
<style type="text/css">
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>
