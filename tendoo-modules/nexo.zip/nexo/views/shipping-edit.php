<?php
$this->gui->cols_width( 1 , 3 );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'shipping' , 'new' ) ),
	'title'		=>	__( 'Modifier l\'arrivage' ),
	'form_wrap'	=>	array(
		'type'	=>	'post'
	)
) )->push_to( 1 );

foreach( $providers as $prov )
{
	$text[]			=	riake( 'NOM' , $prov );
	$value[]		=	riake( 'ID' , $prov );
}
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'shipping_name',
	'placeholder'	=>	__( 'Modifier le nom' ),
	'label'			=>	__( 'Définir le nom de l\'arrivage' ),
	'value'			=>	$shipping[0][ 'TITRE' ],
	'description'	=>	__( 'Veuillez choisir un nom assez explicatif, exemple : "Arrivage Londres 16", "Arrivage Londres 18" ' )
) )->push_to( meta_namespace( array( 'shipping' , 'new' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'select',
	'name'			=>	'shipping_provider',
	'placeholder'	=>	__( 'Choissisez un fournisseur' ),
	'label'			=>	__( 'choisissez un fournisseur' ),
	'description'	=>	__( 'Veuillez définir le fournisseur de ce nouvel arrivage' ),
	'text'			=>	$text,
	'value'			=>	$value,
	'active'		=>	$shipping[0][ 'FOURNISSEUR_REF_ID' ]
) )->push_to( meta_namespace( array( 'shipping' , 'new' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'textarea',
	'name'			=>	'shipping_description',
	'placeholder'	=>	__( 'Description de l\'arrivage' ),
	'label'			=>	__( 'Description' ),
	'value'			=>	$shipping[0][ 'DESCRIPTION' ],
	'description'	=>	__( 'Ce champ n\'est pas obligatoire.' )
) )->push_to( meta_namespace( array( 'shipping' , 'new' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'buttons',
	'name'		=>	array( 'create_new_product' , 'create' , 'create_new_category' ),
	'value'		=>	array(	__( 'Enregistrer l\'arrivage et ajouter un produit' ) , __( 'Enregistrer tout simplement l\'arrivage' ) , __( 'Enregistrer l\'arrivage et ajouter une catégorie' ) ),
) )->push_to( meta_namespace( array( 'shipping' , 'new' ) ) );

$this->gui->get();