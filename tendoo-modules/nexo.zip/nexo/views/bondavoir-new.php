<?php
$this->gui->cols_width( 1 , 2 );
$this->gui->cols_width( 2 , 2 );
$this->gui->enable( 'loader' );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'create' , 'bonavoir' ) ),
	'title'		=>	__( 'Créer un nouveau bon d\'avoir' ),
	'form_wrap'	=>	array(
		'type'	=>	'post',
		'submit_text'	=>	__( 'Créer le bon d\'avoir et Afficher le reçu' ),
		'reset_text'	=>	__( 'Effacer le formulaire' )
	)
) )->push_to( 1 );

$this->gui->set_meta( array(
	'type'		=>	'unwrapped',
	'namespace'	=>	'details_bon',
	'title'		=>	__( 'Créer une nouvelle commande' ),
) )->push_to( 2 );

$commands		=	$lib->get_commands();

$command_text	=	array();
$command_value	=	array();

foreach( $commands as $_command )
{
	$comomand_text[]	=	riake( 'CODE' , $_command );
	$comomand_value[]	=	riake( 'ID' , $_command );
}

$this->gui->set_item( array( 
	'type'		=>	'select',
	'attrs'		=>	array(
		'combobox'	=>	'combobox'
	),
	'name'		=>	'command_id',
	'placeholder'	=>	__( 'Choisir une commande' ),
	'label'		=>	__( 'Choisir un commande' ),
	'text'		=>	$comomand_text,
	'value'		=>	$comomand_value,
	'description'	=>	__( 'Veuillez choisir la commande pour laquelle vous souhaitez créer un bon d\'avoir. La commande choisie sera annulée et les produits seront remise en stock.' )
) )->push_to( meta_namespace( array( 'create' , 'bonavoir' ) ) );

$this->gui->set_item( array(
	'type'		=>	'dom',
	'value'		=>	module_view( 'views/bondavoir-script' , true , 'nexo' )
) )->push_to( meta_namespace( array( 'create' , 'bonavoir' ) ) );

$this->gui->set_item( array(
	'type'		=>	'dom',
	'value'		=>	module_view( 'views/bondavoir-widget' , true , 'nexo' )
) )->push_to( 'details_bon' );

$this->gui->get();