<?php
$this->gui->cols_width( 1 , 2 );
$this->gui->cols_width( 2 , 2 );
$this->gui->enable( 'loader' );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'command' , 'fields' ) ),
	'title'		=>	__( 'Créer une nouvelle commande' ),
	'form_wrap'	=>	array(
		'type'	=>	'post',
		'submit_text'	=>	__( 'Enregistrer la commande' ),
	)
) )->push_to( 1 );

$this->gui->set_meta( array(
	'type'		=>	'unwrapped',
	'namespace'	=>	meta_namespace( array( 'commands' , 'cash_status' ) ),
	'title'		=>	__( 'Liste des produits' )
) )->push_to( 2 );

$this->gui->set_meta( array(
	'type'		=>	'panel-ho',
	'namespace'	=>	meta_namespace( array( 'commands' , 'list' ) ),
	'title'		=>	__( 'Liste des produits' )
) )->push_to( 2 );

$clients_text	=	array( __( 'Ne pas attribuer à un client' ) );
$clients_value	=	array( 0 );

$clients		=	$this->roles->get_users_with_role( riake( 'client_privilege' , $nexo_settings , 0 ) );

foreach( $clients as $_client )
{
	$current_client		=	get_user( riake( 'USER_ID' , $_client ) , 'as_id' );
	$clients_text[]		=	riake( 'client_name' , $current_client );
	$clients_value[]	=	riake( 'ID' , $current_client );
}

$this->gui->set_item( array( 
	'type'		=>	'select',
	'name'		=>	'client_id',
	'value'		=>	$clients_value,
	'text'		=>	$clients_text,
	'placeholder'	=>	__( 'Client concerné' ),
	'label'		=>	__( 'Client concerné' ),
	'description'	=>	__( 'Assurez-vous que le nom du client soit unique.' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) );

/**

$this->gui->set_item( array(
	'type'			=>	'select',
	'name'			=> 	'command_type',
	'value'			=>	array( 1 , 2 , 3 ), // 1 : normal, 2 : avance , 3 : devis
	'text'			=>	array( __( 'Commande normale' ) , __( 'Commande avec avance' ) , __( 'Commande Sans Avance' ) ),
	'placeholder'	=>	__( 'Veuillez définir le type de la commande' ),
	'label'			=>	__( 'Type de la commande' ),
	'description'	=>	__( 'Veuillez définir le type de la commande' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) ) ;

**/

$this->gui->set_item( array(
	'type'			=>	'select',
	'name'			=> 	'payment_type',
	'value'			=>	array( 1 , 2 , 3 , 4 , 5 ), // 1 Espece , Virement
	'text'			=>	array( __( 'Espèce' ) , __( 'Virement' ) , __( 'Carte Bancaire' ) , __( 'MTN Mobile Money' ) , __( 'Orange Money' ) ),
	'placeholder'	=>	__( 'Veuillez définir le mode du règlement' ),
	'label'			=>	__( 'Mode de règlement' ),
	'active'		=>	1,
	'description'	=>	__( 'Veuillez définir le mode du règlement' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) ) ;

$this->gui->set_item( array(
	'type'		=>	'text',
	'name'		=>	'product_ids',
	'placeholder'	=>	__( 'Veuillez entrer l\'identifiant d\'un produit' ),
	'label'		=>	__( 'Code du produit' ),
	'description'	=>	__( 'Veuillez entrer l\'identifiant d\'un produit' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) ) ;

$this->gui->set_item( array(
	'type'		=>	'buttons',
	'name'		=>	array( 'add_product' ),
	'text'		=>	array( __( 'Ajouter l\'article' ) ),
	'value'		=>	array( __( 'Ajouter l\'article' ) ) ,
	'placeholder'	=>	__( 'Veuillez entrer l\'identifiant d\'un produit' ),
	'label'		=>	__( 'Code du produit' ),
	'description'	=>	__( 'Vous pouvez ajouter autant d\'article qu\'il en existe en stock.' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) ) ;

$this->gui->set_item( array(
	'type'			=>	'text',
	'name'			=>	'montant_avancee',
	'placeholder'	=>	__( 'Montant avancé ou reçu' ),
	'label'			=>	__( 'Montant avancé ou reçu' ),
	'description'	=>	__( 'Précisez le montant avancé/reçu.' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) ) ;

$this->gui->set_item( array(
	'type'			=>	'text',
	'name'			=>	'rrr',
	'placeholder'	=>	__( 'Reduction expresse' ),
	'label'			=>	__( 'Reduction expresse' ),
	'description'	=>	__( 'Appliquer une reduction expresse sur une commande.' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) ) ;

$this->gui->set_item( array(
	'type'			=>	'hidden',
	'name'			=>	'montant_command',
	'placeholder'	=>	__( 'Montant' ),
	'label'			=>	__( 'Montant' ),
	'description'	=>	__( 'Précisez le montant avancé/reçu.' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) ) ;

$this->gui->set_item( array(
	'type'		=>	'dom',
	'value'		=>	module_view( 'views/commands-script' , true , 'nexo' )
) )->push_to( meta_namespace( array( 'command' , 'fields' ) ) );

$this->gui->set_item( array(
	'type'			=>	'dom',
	'value'			=>	module_view( 'views/commands-cash' , true , 'nexo' )
) )->push_to( meta_namespace( array( 'commands' , 'cash_status' ) ) );


$this->gui->set_item( array(
    'type'    =>    'table-panel',
	'attrs'	  =>	array(
		'id'	=>	'command_table'
	),
    'cols'    =>    array( __( 'Désignation' ) , __( 'Prix Unitaire' ) , __( 'Quantité' ) ,  __( 'Prix Total' ) , __( 'Operation' ) ),
    'rows'    =>    array(
        array( '--' , __( '--' ) , __( '--' ) , '--' , '--' ),
    )
) )->push_to( meta_namespace( array( 'commands' , 'list' ) ) );

$this->gui->get();