<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<title>Version Imprimable des articles</title>
</head>
<body>
    <div class="container">
    <!--<div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3>Etiquette Article en Rayon</h3>
            </div>
            <hr style="margin:0 1%;">
        </div>
    </div>-->
    <div class="row">
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive" style="width:100%">
            	
                <table class="table table-bordered" style="font-size:12px !important;">
                    <thead>
    
<?php
	$index = 0;
    foreach( $products as $_product )
    {
		$author			=	get_user( riake( 'AUTHOR' , $_product ) , 'as_id' );
		$category		=	farray( $lib->get_category( riake( 'REF_CATEGORIE' , $_product ) , 'as_id' ) );	
		$shipping		=	farray( $lib->get_shipping( riake( 'REF_SHIPPING' , $_product ) , 'as_id' ) );
		$products_array[]	=	array( 
			'<a href="' . module_url( array( 'articles' , 'edit' , riake( 'ARTICLE_ID' , $_product ) ) ) . '">' . riake( 'DESIGN' , $_product ) . '</a>' , 
			riake( 'QUANTITY' , $_product ) , 
			riake( 'NOM' , $category , 'Catégorie Inconnu' ),
			riake( 'TITRE' , $shipping , 'Arrivage Inconnue' ),
			riake( 'DATE_CREATION' , $_product ) ,
			timespan( riake( 'DATE_MODIFICATION' , $_product ) ), 
			riake( 'PSEUDO' , $author ) ,
			'<img src="' . get_instance()->url->main_url() . riake( 'FILE_PATH' , $_product ) . '" alt=" '. riake( 'DESIGN' , $_product )  .' ">',
			'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer ce produits ?<br> Cette opération risque affecter les calculs sur l\'application. Toutes les commandes qui où sont ajoutés ce produit, seront également affectées.' ) . '" href="' . module_url( array( 'articles' , 'delete' , riake( 'ARTICLE_ID' , $_product ) ) ) . '"> Supprimer le produit </a>' , 
		);
		$cout_dachat	=	riake( 'PRIX_DACHAT' , $_product , 0 ) + riake( 'FRAIS_ACCESSOIRES' , $_product );
		$prix_de_vente	=	$cout_dachat * riake( 'TAUX_DE_MARGE' , $_product , 1 );
		for( $__i = 0 ; $__i < riake( 'QUANTITY' , $_product ) ; $__i++ )
		{
			if( $index == 0 )
			{
				?>
				<tr>
				<?php
			}
			?>
					<td style="font-size:10px;">
						<img style="width:100%;height:30px;float:left;" src="<?php echo get_instance()->url->main_url() . riake( 'FILE_PATH' , $_product );?>" alt="<?php echo riake( 'DESIGN' , $_product );?>">
						<p style="font-size:12px;display:inline-block;background:#FFF;margin-top:0;padding:1px;height:25px;"><?php echo riake( 'DESIGN' , $_product );?></p><br>
						<hr class="line-dashed" style="margin:5px 0px;">
						<span style="margin:5px 0;">Col : <?php echo riake( 'TITRE' , $shipping , 'Arrivage Inconnue' );?> / <?php echo riake( 'NOM' , $category , 'Catégorie Inconnu' );?></span><br>
						<span>Code : <?php echo riake( 'CODE' , $_product );?></span><br>
						<span>Prix : <?php echo $prix_de_vente;?> <?php echo riake( 'devise_boutique' , $nexo_settings );?></span>
					</td>
			<?php
			if( $index == 4 )
			{
				?>
				</tr>
				<?php
				$index = -1;
			}
			$index++;
		}
	}
	?>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
				<?php echo bs_pagination( $pagination_data );?> <a href="<?php echo module_url( array( 'articles' ) );?>">Revenir a la version normale</a>
            </div>
        </div>
		<?php // echo bs_pagination( $pagination_data );?>
		<!--
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>-->
    </div>
</div>
<style type="text/css">
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>
