<?php
		$prefs	=	array (
		   'show_next_prev'  => TRUE,
		   'next_prev_url'   => module_url( array( 'reports' , 'daily' ) , 'nexo' )
		 );
		 $prefs['template'] = '
		
		   {table_open}<table border="0" cellpadding="0" cellspacing="0" class="table table-bordered">{/table_open}
		
		   {heading_row_start}<tr>{/heading_row_start}
		
		   {heading_previous_cell}<th><a href="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
		   {heading_title_cell}<th colspan="{colspan}">{heading}</th>{/heading_title_cell}
		   {heading_next_cell}<th><a href="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}
		
		   {heading_row_end}</tr>{/heading_row_end}
		
		   {week_row_start}<tr>{/week_row_start}
		   {week_day_cell}<td class="text-right">{week_day}</td>{/week_day_cell}
		   {week_row_end}</tr>{/week_row_end}
		
		   {cal_row_start}<tr>{/cal_row_start}
		   {cal_cell_start}<td class="text-right">{/cal_cell_start}
		
		   {cal_cell_content}<a href="{content}">{day}</a>{/cal_cell_content}
		   {cal_cell_content_today}<div class="highlight"><a href="{content}">{day}</a></div>{/cal_cell_content_today}
		
		   {cal_cell_no_content}{day}{/cal_cell_no_content}
		   {cal_cell_no_content_today}<div class="highlight">{day}</div>{/cal_cell_no_content_today}
		
		   {cal_cell_blank}&nbsp;{/cal_cell_blank}
		
		   {cal_cell_end}</td>{/cal_cell_end}
		   {cal_row_end}</tr>{/cal_row_end}
		
		   {table_close}</table>{/table_close}
		';
		get_instance()->load->library( 'calendar' , $prefs );
		$date		=	get_instance()->date->time( '' , true );
		$YEAR		=	( $YEAR  === 'DEFAULT' ) ? riake( 'y' , $date ) : $YEAR;
		$MONTH		=	( $MONTH  === 'DEFAULT' ) ? riake( 'm' , $date ) : $MONTH;
		$DAY		=	( $DAY	=== 'DEFAULT' ) ? unsinglerize( riake( 'd' , $date ) ) : $DAY;
		
		$timestamp	=	strtotime( $YEAR .'-' . $MONTH . '-01' ) ;
		$NBR_DAYS	=	cal_days_in_month( CAL_GREGORIAN , $MONTH , $YEAR );
		$date_start	=	date( 'Y-m-' , $timestamp ) . $DAY . ' 00:00:00';
		$date_end	=	date( 'Y-m-' , $timestamp ) . $DAY . ' 23:59:59';
 		// var_dump(  );
		// $commands	=	$lib->get_commands( 'between' , date( 'Y-m-' , $timestamp ) . 01 , date( 'Y-m-' , $timestamp ) . $NBR_DAYS );
		
		$daily_recettes				=	$this->lib->daily_report( 'recap-recettes' , $date_start , $date_end );
		
		$facture_dachats			=	$this->lib->daily_report( 'recap-bills' , $date_start , $date_end );
		
		$final_array				=	array();
		
		for( $i = 0 ; $i<= $NBR_DAYS ; $i++ )
		{
			$final_array[]			=	module_url( array( 'reports' , 'daily' , $YEAR , $MONTH , unsinglerize( $i ) ) , 'nexo' );
		}
$TITLE	=	'Rapport Journalier : ' . $date_start . ' au ' . $date_end;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<title><?php echo $TITLE;?></title>
</head>
<body>
    <div class="container">
    <div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3><?php echo $TITLE;?></h3>
            </div>
            <hr style="margin:0 1%;">
        </div>
    </div>
    <div class="row">
    	<div class="col-lg-4 col-lg-offset-4 noPrint">
        	<?php		
		echo get_instance()->calendar->generate( $YEAR , $MONTH , $final_array );
			?>
        </div>
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive">
            	<?php 
				$nbr_command_doit 	=	0;
				$nbr_command_avance = 	0;
				$ca_command_doit	=	0;
				$ca_command_avance	=	0;
				$debt_command_avance=	0;
				$rrr_total			=	0;
				foreach( force_array( $daily_recettes ) as $_daily )
				{
					$rrr_total		+=	( int ) riake( 'CHARGE' , $_daily );
					if( riake( 'TYPE' , $_daily ) == 1 )
					{
						$nbr_command_doit++;
						$ca_command_doit	+=	$lib->get_command_real_price( riake( 'ID' , $_daily ) , 'as_id' );
					}
					else if( riake( 'TYPE' , $_daily ) == 2 )
					{
						$nbr_command_avance++;
						// On soutrait la valeur réelle de la commande à la valeur perçu pour trouver la somme restante
						$debt_command_avance	+=	$lib->get_command_real_price( riake( 'ID' , $_daily ) , 'as_id' ) - ( int ) riake( 'AVANCE' , $_daily );
						$ca_command_avance		+=	( int ) riake( 'AVANCE' , $_daily );
					}
				}
				?>
                <table class="table table-bordered">
                    <thead style="background:#CAFCC7">
                    	<tr>
                        	<td colspan="4">RECAPITULATIF DES RECETTES</td>
                        </tr>
                        <tr>
                        	<td><strong>N°</strong></td>
                            <td><strong>TYPE DE DOCUMENT</strong></td>
                            <td class="text-center"><strong>QUANTITE</strong></td>
                            <td class="text-center"><strong>CA COLLECTIF ( <?php echo riake( 'devise_boutique' , $nexo_settings );?> )</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                        	<td>1</td>
                            <td>Commandes Doit</td>
                            <td><?php echo $nbr_command_doit;?></td>
                            <td><?php echo $ca_command_doit;?></td>
                        </tr>
                        <tr>
                        	<td>2</td>
							<td>Commandes Avances</td>
                            <td><?php echo $nbr_command_avance;?></td>
                            <td><?php echo $ca_command_avance;?></td>
                        </tr>
                        <tr>
                        	<td></td>
							<td></td>
                            <td>CA Journalier</td>
                            <td><?php echo $ca_command_avance + $ca_command_doit;?></td>
                        </tr>
                        <tr>
                        	<td></td>
							<td></td>
                            <td>CA à Recouvrer</td>
                            <td><?php echo $debt_command_avance;?></td>
                        </tr>
                    </tbody>
                </table>
                <table class="table table-bordered">
                    <thead style="background:#CAFCC7">
                    	<tr>
                        	<td colspan="4">RECAPITULATIF DES DEPENSES</td>
                        </tr>
                        <tr>
                        	<td><strong>N°</strong></td>
                            <td><strong>TYPE DE DOCUMENT</strong></td>
                           <!-- <td class="text-center"><strong>QUANTITE</strong></td>-->
                            <td class="text-center"><strong>MONTANT ( <?php echo riake( 'devise_boutique' , $nexo_settings );?> )</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
					$montant_total 	=	0;
					$montant_total	+=	$rrr_total;
						?>
                        <tr>
                        	<td>/</td>
                            <td><?php _e( 'RRR (Express ou Fidelité)' );?></td>
                            <td><?php echo $rrr_total;?></td>
                        </tr>
                        <?php
					foreach( force_array( $facture_dachats ) as $facture )
					{
						$montant_total += ( int ) riake( 'MONTANT' , $facture );
						?>
                        <tr>
                        	<td><?php echo riake( 'ID' , $facture );?></td>
                            <td><?php echo riake( 'TITLE' , $facture );?></td>
                            <td><?php echo riake( 'MONTANT' , $facture );?></td>
                        </tr>
                        <?php
					}
					?>
                    <tr>
                    	<td colspan="1"></td>
                        <td>Total Dépenses</td>
                        <td><?php echo $montant_total;?></td>
                    </tr>
                    
                        
                    </tbody>
                </table>
                <table class="table table-bordered">
                    <thead style="background:#CAFCC7">
                    	<tr>
                        	<td colspan="4">BILAN TRESORERIE</td>
                        </tr>
                        <tr>
                        	<td colspan="2"><strong>Solde Initial ( <?php echo riake( 'devise_boutique' , $nexo_settings );?> )</strong></td>
                            <td><strong><?php echo $solde_initial	=	$lib->get_cash( 'previous-to-without-discounts' , $date_start );?></strong></td>
                           <!-- <td class="text-center"><strong>QUANTITE</strong></td>-->
                            <td class="text-center"><strong>MONTANT ( <?php echo riake( 'devise_boutique' , $nexo_settings );?> )</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                    	<td colspan="1">(+)</td>
                        <td>RECETTES</td>
                        <td><?php echo $lib->get_cash( 'real-today-without-discounts'  );?></td>
	                    <td><?php echo riake( 'devise_boutique' , $nexo_settings );?></td>
                    </tr>
                    <tr>
                    	<td colspan="1">(-)</td>
                        <td>DEPENSES</td>
                        <td><?php echo $montant_total;?></td>
	                    <td><?php echo riake( 'devise_boutique' , $nexo_settings );?></td>
                    </tr>
					<tr>
                    	<td colspan="1">(=)</td>
                        <td>SOLDE FINAL</td>
                        <td><?php echo ( $lib->get_cash( 'real-today-without-discounts'  ) - $montant_total ) + $solde_initial;?></td>
	                    <td><?php echo riake( 'devise_boutique' , $nexo_settings );?></td>
                    </tr>
                    <tr style="background:#FFBFBF">
                    	<td colspan="1">(*)</td>
                        <td>NET A PERCEVOIR (Factures Doit)</td>
                        <td><?php echo $lib->get_cash( 'facture-doit-today'  );?></td>
	                    <td><?php echo riake( 'devise_boutique' , $nexo_settings );?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>
    </div>
</div>
<style type="text/css">
@media print { .noPrint { display:none; } }
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>
