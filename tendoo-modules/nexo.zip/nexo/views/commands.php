<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_command_list',
	'type'			=>	'panel',
	'title'			=>	__( 'Liste des commandes' )
) )->push_to( 1 );

$commands_array		=	array();

foreach( force_array( $commands ) as $_command )
{
	$author			=	get_user( riake( 'AUTHOR' , $_command ) , 'as_id' );
	$client			=	get_user( riake( 'REF_CLIENT' , $_command ) , 'as_id' );
	$produits_cli	=	$lib->get_products_in_commands( $_command[ 'ID' ] , 'as_command' );
	$prix			=	0;
	foreach( $produits_cli as $_product )
	{
		$produit_details=	farray( $lib->get_product( $_product[ 'REF_ARTICLE' ] , 'as_id' ) );
		$product_vars	=	farray( $lib->get_product_vars( riake( 'ID' , $produit_details ) , 'as_id' , riake( 'DATE_CREATION' , $_command ) ) );

		$cout_dachat	=	( int ) riake( 'PRIX_DACHAT' , $product_vars , 0 ) + ( int ) riake( 'FRAIS_ACCESSOIRES' , $product_vars );
		$prix_de_vente	=	$cout_dachat * ( float ) riake( 'TAUX_DE_MARGE' , $product_vars , 1 );
		// var_dump( $cout_dachat * ( float ) riake( 'TAUX_DE_MARGE' , $product_vars , 1 ) );
		$prix			=	$prix +	$prix_de_vente;
	}
	$brut				=	$prix;
	$prix				-= 	riake( 'CHARGE' , $_command , 0 );
	$facture_type 		=	'Inconnu';
	if( riake( 'TYPE' , $_command ) == 1 )
	{
		$ticket_de_caisse	=	'<a target="_blank" href="' . module_url( array( 'commands' , 'ticket' , riake( 'ID' , $_command ) ) ) . '">Afficher</a>';
		$facture_type 	=	'Doit';
	}
	else if( riake( 'TYPE' , $_command ) == 2 )
	{
		$ticket_de_caisse	=	'Indisponible';
		$facture_type 	=	'Avance';
	}
	else if( riake( 'TYPE' , $_command ) == 3 )
	{
		$ticket_de_caisse	=	'Indisponible';
		$facture_type 		=	'Devis';
	}
	$commands_array[]	=	array( 
		// '<a href="' . module_url( array( 'articles' , 'edit' , riake( 'ARTICLE_ID' , $_command ) ) ) . '">' . riake( 'CODE' , $_command ) . '</a>' , 
		riake( 'client_name' , $client ) == '' ? 'N/A' : riake( 'client_name' , $client ) , 
		$facture_type		,
		$lib->money_format( $brut ),
		$lib->money_format( riake( 'CHARGE' , $_command )  ),
		$lib->money_format( $prix ),
		$lib->money_format( ( int ) riake( 'AVANCE' , $_command ) ),
		$lib->money_format( abs( $prix - ( int ) riake( 'AVANCE' , $_command ) ) ),
		// riake( 'DATE_CREATION' , $_command ) ,
		riake( 'DATE_MODIFICATION' , $_command ),  // timespan( riake( 'DATE_MODIFICATION' , $_command ) )
		riake( 'PSEUDO' , $author ) ,
		'<a target="_blank" href="' . module_url( array( 'commands' , 'printable' , riake( 'ID' , $_command ) ) ) . '">Afficher</a>' , 
		$ticket_de_caisse,
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer cette commande ?<br> Supprimer une commande renverra les produits vendus en stock. ' ) . '" href="' . module_url( array( 'commands' , 'delete' , riake( 'ID' , $_command ) ) ) . '"> Supprimer</a>' , 
		'<span>' . riake( 'CODE' , $_command ) . '</span>'
	);
}

// __( 'Code' ) ,
$this->gui->set_item( array(
	'type'			=>	'dynamic-table',
	'cols'			=>	array( 
		__( 'Client' ) , 
		__( 'Type' ) , 
		__( 'MTT Brut' . ' <br>' . riake( 'devise_boutique' , $nexo_settings , 'F' ) ) , 
		__( 'RRR' . ' <br>' . riake( 'devise_boutique' , $nexo_settings , 'F' ) ) , 
		__( 'Total' . ' <br>' .  riake( 'devise_boutique' , $nexo_settings , 'F' ) ) , 
		__( 'Avance / MTT Perçu' . ' <br>' .  riake( 'devise_boutique' , $nexo_settings , 'F' ) ) , 
		__( 'Reste' . ' <br>' . riake( 'devise_boutique' , $nexo_settings , 'F' ) ),
		/* __( 'Date de création' ) ,*/ 
		__( 'Modifié' ) , 
		__( 'Par' ) , 
		__( 'Facture' ) , 
		__( 'Ticket de Caisse' ) , 
		__( 'Supprimer' ) , 
		__( 'Code' ) 
	),
	'rows'			=>  $commands_array
) )->push_to( 'nexo_command_list' );

$this->gui->get();