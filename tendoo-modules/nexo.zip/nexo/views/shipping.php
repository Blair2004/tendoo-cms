<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_shippings',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des arrivages' )
) )->push_to( 1 );

$shipping_array		=	array();

foreach( $shippings as $ship )
{
	$provider		=	$lib->get_providers( riake( 'FOURNISSEUR_REF_ID' , $ship ) , 'as_id' );
	$author			=	get_user( riake( 'AUTHOR' , $ship ) , 'as_id' );
	$shipping_array[]	=	array( 
		'<a href="' . module_url( array( 'shipping' , 'edit' , riake( 'ID' , $ship ) ) ) . '">' . riake( 'TITRE' , $ship ) . '</a>' , 
		riake( 'NOM' , riake( 0 , $provider ) , __( 'Fournisseur introuvable' ) ) , 
		'<a target="_blank" href="' . module_url( array( 'shipping' , 'fiche' , riake( 'ID' , $ship ) ) ) . '">Fiche de contrôle</a>' , 
		riake( 'DATE_CREATION' , $ship ) ,
		timespan( riake( 'DATE_MODIFICATION' , $ship ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer cet arrivage & ses produits ?' ) . '" href="' . module_url( array( 'shipping' , 'delete' , riake( 'ID' , $ship) ) ) . '"> Supprimer l\'arrivage et ses produits </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Désignation de l\'arrivage' ) , __( 'Fournisseur' ) , __( 'Fiche de contrôle de l\'arrivage' ) , __( 'Date de création' ) , __( 'Modifié' ) , __( 'Par' ) , __( 'Supprimer' ) ),
	'rows'			=>  $shipping_array
) )->push_to( 'nexo_shippings' );

$this->gui->get();