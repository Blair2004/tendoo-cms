<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_category',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des catégories' )
) )->push_to( 1 );

$category_array		=	array();

foreach( force_array( $category ) as $_category )
{
	$author			=	get_user( riake( 'AUTHOR' , $_category ) , 'as_id' );
	$nbr_used		=	$lib->get_product_related( 'category' , riake( 'ID' , $_category ) );
	// $lib->get_product_related( 'categories' , riake( 'ID' , $_category ) );
	$entite_parente	=	$lib->get_category( riake( 'PARENT_REF_ID' , $_category ) , 'as_id' );
	$category_array[]	=	array( 
		'<a href="' . module_url( array( 'category' , 'edit' , riake( 'ID' , $_category ) ) ) . '">' . riake( 'NOM' , $_category ) . '</a>' , 
		riake( 'NOM' , riake( 0 , $entite_parente ) , 'Aucun parent' ),		
		count( $nbr_used ) > 0 ? count( $nbr_used ). 'fois' : 'Non' , 
		riake( 'DATE_CREATION' , $_category ) ,
		timespan( riake( 'DATE_MODIFICATION' , $_category ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer cette catégorie ?<br>Cette opération risque affecter certains produits.' ) . '" href="' . module_url( array( 'category' , 'delete' , riake( 'ID' , $_category ) ) ) . '"> Supprimer la catégorie </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Intitulé de la catégorie' ) , __( 'Entité parente' ) , __( 'Utilisé (x fois)' ) , __( 'Date de création' ) , __( 'Modifié' ) , __( 'Par' ) , __( 'Supprimer' ) ),
	'rows'			=>  $category_array
) )->push_to( 'nexo_category' );

$this->gui->get();