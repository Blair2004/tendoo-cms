<?php
$this->gui->cols_width( 1 , 3 );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'create' , 'rayon' ) ),
	'title'		=>	__( 'Modifier un rayon' ),
	'form_wrap'	=>	array(
		'type'	=>	'post',
		'submit_text'	=>	__( 'Modifier le rayon' )
	)
) )->push_to( 1 );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'designation_rayon',
	'placeholder'	=>	__( 'Désignation rayon' ),
	'label'		=>	__( 'Désignation du rayon' ),
	'description'	=>	__( 'Veuillez ajouter une designation assez clair et précise pour le rayon.' )
) )->push_to( meta_namespace( array( 'create' , 'rayon' ) ) );
// Description
$this->gui->set_item( array( 
	'type'		=>	'textarea',
	'name'		=>	'description_rayon',
	'placeholder'	=>	__( 'Ajouter une description pour le rayon' ),
	'label'		=>	__( 'Description du rayon' ),
	'description'	=>	__( 'La description n\'est pas obligatoire, mais nécessaire.' )
) )->push_to( meta_namespace( array( 'create' , 'rayon' ) ) );

$this->gui->get();