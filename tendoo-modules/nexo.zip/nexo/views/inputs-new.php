<?php
$this->gui->cols_width( 1 , 3 );
$this->gui->cols_width( 2 , 1 );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'create' , 'inputs' ) ),
	'title'		=>	__( 'Ajouter un nouveau flux' ),
	'form_wrap'	=>	array(
		'type'	=>	'post',
		'submit_text'	=>	__( 'Ajouter le flux' ),
		'reset_text'	=>	__( 'Effacer le formulaire' )
	)
) )->push_to( 1 );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'entre_name',
	'placeholder'	=>	__( 'Entrer son nom' ),
	'label'		=>	__( 'Désignation du flux' ),
	'description'	=>	__( 'Veuillez fournir une raison la cause de ce flux.' )
) )->push_to( meta_namespace( array( 'create' , 'inputs' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'textarea',
	'name'			=>	'entre_desc',
	'placeholder'	=>	__( 'Description du flux' ),
	'label'			=>	__( 'Description' ),
	'description'	=>	__( 'Veuillez donner une description à ce flux.' )
) )->push_to( meta_namespace( array( 'create' , 'inputs' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'entre_amount',
	'placeholder'	=>	__( 'Montant' ),
	'label'			=>	__( 'Montant' ),
	'description'	=>	__( 'Veuillez spécifier une valeur numérique supérieure à 0.' )
) )->push_to( meta_namespace( array( 'create' , 'inputs' ) ) );

$this->gui->get();