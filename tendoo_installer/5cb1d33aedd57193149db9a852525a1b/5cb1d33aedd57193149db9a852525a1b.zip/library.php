<?php
class modus_lib
{
	public function __construct()
	{
		$this->core	=	Controller::instance();
	}
}