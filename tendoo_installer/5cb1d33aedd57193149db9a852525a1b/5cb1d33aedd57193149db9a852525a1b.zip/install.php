﻿<?php
$this->installSession();
$this->appType('THEME');
$this->appVers(0.1);
$this->appTendooVers(0.96);
$this->appTableField(array(
	'NAMESPACE'		=> 'Tendoo_Revera',
	'HUMAN_NAME'	=> 'Tendoo - Revera',
	'AUTHOR'		=> 'Blair Jersyer',
	'DESCRIPTION'	=> 'Thème officiel de la version 0.9.6 de Tendoo',
	'TENDOO_VERS'	=> 0.96
));