<footer id="footer"> 
    <!-- 960 Container -->
    <div class="container"> 
        <!-- Contact Details -->
        <?php $this->parseBottomWidgets();?>
    </div>
    <!-- 960 Container / End --> 
    
</footer>
<footer id="footer-bottom">
	<!-- 960 Container -->
	<div class="container">

		<!-- Copyrights -->
		<div class="eight columns">
			<div class="copyright">
				© Designed by Nevia for <?php echo get('core_version');?>
			</div>
		</div>

		<!-- Menu -->
		<div class="eight columns">
			<nav id="sub-menu">
				<ul>
					<li><a href="#">FAQ's</a></li>
					<li><a href="#">Sitemap</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</nav>
		</div>

	</div>
</footer>
	<!-- 960 Container / End -->