<?php
$PARENTS_ITEMS	=	array(
	'index','blog','contact'
);
$CHILDS_ITEMS	=	array(
	'caroussel','featuredElements','tabShowCase','lastestElements','aboutUs','ouPartners'
);