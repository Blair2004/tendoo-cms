<?php $this->installSession();
$this->appType('THEME');
$this->appVers(0.1);
$this->appTendooVers(0.98);
$this->appTableField(array(
	'NAMESPACE'		=> "nevia",
	'HUMAN_NAME'	=> "Nevia",
	'AUTHOR'		=> "admin",
	'DESCRIPTION'	=> "Nevia",
	'TENDOO_VERS'	=> 0.98 
));