Tendoo-cms
=========
v1.4 
---------
An easiest way to create web apps and blogs. Tendon has been improved, and for this release, you offer you the best tool, lightweight, customizable than ever.
We are proud of this and thank all community members. Just help us make it more powerful than ever, by submitting issues or joining developers team.

Whats new ?
--------------
- New Dashboard (AdminLTE v2.0)
- Dashboard UI has changed. System menu doesn't exists no more, and all his sub-menu has been separated.
- Events and Filters hooks introduced.
- A fully customizable admin menu.
- App Mode : which can fully turn Tendoo into a WebApp without Frontend.
- Translated to english : This has been decided by Core team. English is now set as default language for future releases.
- Blogster Update.
- Tendoo Media Manager Update.
- New UI.
- New API, Library, Helpers.
- Translation to english 80%.
- Unique dashboard for account and admin.
- New docs (being prepared)
- Gui Bugs fixes
- Messenger disabled temporarily
- Tools disabled temporarily


System Requirement
------------------

Apache 	: 2.22.2
PHP 	: 5.4
Mysql 	: 5.5.24

** It may work with PHP 5.3, but we're haven't yet tried all feature on it. **

