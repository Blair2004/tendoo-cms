<section id="bottom" class="wet-asphalt bg-inverse" style="background:#333;">
    <div class="container">
        <div class="row">
        	<?php get_widgets( 'bottom' );?>
        </div>
    </div>
</section>