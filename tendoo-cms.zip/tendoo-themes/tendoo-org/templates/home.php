<?php get_items( 'slider' );?>
<?php get_items( 'list_services' );?>
<?php get_items( 'testimony' );?>