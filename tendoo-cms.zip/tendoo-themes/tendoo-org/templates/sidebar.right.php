<div class="span3">
    <?php get_widgets( 'right' );?>
</div>
