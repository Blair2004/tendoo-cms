<footer class="footer">
  <div class="container">
    <p>© 2015 Conçu pour <?php echo get('core_version');?> avec Bootflat skin for <a href="http://twitter.github.io/bootstrap/" target="_blank">Bootstrap</a>.</p>
  </div>
</footer>