<?php 
declare_theme( 'tendoo' , array(
	'name' 	=>		'tendoo',
	'author'		=>		'Tendoo.org',
	'description'	=>		"Thème Officiel de la plateforme Tendoo",
	'version'		=>		0.1,
	'compatible'	=>		1.3
) );