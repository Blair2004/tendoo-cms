<?php 
declare_theme( 'eva' , array(
	'name' 	=>		'Eva',
	'author'		=>		'Tendoo.org',
	'description'	=>		"Eve est un thème WP attapté à Tendoo 1.3. Il est responsive et offre plusieurs fonctionnalités, qui nous l'espérons, séduiront ses utilisateurs.",
	'version'		=>		0.2,
	'compatible'	=>		1.3
) );