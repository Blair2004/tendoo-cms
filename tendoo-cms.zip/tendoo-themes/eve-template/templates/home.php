<section class="wrapper"> 
    
    <!--Start Slider-->
    <?php get_items( 'fraction_slider' );?>
    <?php if( true == false ):?>
    <div class="slider-wrapper">
        <div class="slider">
            <div class="fraction-slider" style="overflow: visible; width: auto; height: auto;">
                <div class="slide" style="left: 0%; top: 0%; display: none;"> 
                    <!--1- slide background--> 
                    <img src="images/fraction-slider/gadgets/laptop-lg.png" data-position="-6.666666666666667,28.645833333333336" data-in="bottom" data-delay="500" data-out="fade" width="41.66666666666667%" height="166.66666666666666%" rel="0" class="fs_obj" style="width: 41.6666666666667%; height: 166.666666666667%; font-size: 7.91555555555556px; line-height: 100%; opacity: 0; top: -6.66666666666667%; left: 28.6458333333333%; display: none;" data-fontsize="13px"> <!--3- laptop-->
                    
                    <p class="para-new fs_obj" data-position="2.2222222222222223,31.25" data-in="top" data-out="Right" data-delay="" rel="0" data-fontsize="55px" style="font-size: 33.4888888888889px; line-height: 100%; opacity: 1; top: 2.22222222222222%; left: 31.25%; display: none;">Welcome to Eve</p>
                </div>
                <div class="slide active-slide" style="left: 0%; top: 0%; display: block;"> <img src="images/fraction-slider/fraction_2.png" data-in="fade" data-delay="" data-out="fade" width="100%" height="100%" rel="1" class="fs_obj fs_obj_active" style="width: 100%; height: 100%; font-size: 7.91555555555556px; line-height: 100%; opacity: 1; top: 0%; left: 0%; display: inline;" data-fontsize="13px"> <!--2- slide background--> 
                    
                    <img src="images/fraction-slider/slider-boy.png" width="31.25%" height="133.33333333333334%" data-position="1.7777777777777777,64.58333333333334" data-in="bottomLeft" data-delay="500" data-out="fade" style="width: 31.25%; height: 133.333333333333%; font-size: 7.91555555555556px; line-height: 100%; opacity: 1; top: 1.77777777777777%; left: 64.5833333333333%; display: inline;" rel="1" class="fs_obj fs_obj_active" data-fontsize="13px">
                    <p class="claim light-pink fs_obj fs_obj_active" data-position="8.88888888888889,11.979166666666668" data-in="top" data-out="left" data-delay="1800" data-ease-in="easeOutBounce" rel="1" data-fontsize="24px" style="font-size: 14.6133333333333px; line-height: 100%; opacity: 1; top: 8.88888888888889%; left: 11.9791666666667%; display: block;">the Rain template design</p>
                    <p class="teaser turky small fs_obj fs_obj_active" data-position="33.333333333333336,11.979166666666668" data-in="left" data-out="left" data-delay="5500" rel="1" data-fontsize="14px" style="width: 13.0208333333333%; font-size: 8.52444444444445px; line-height: 100%; opacity: 1; top: 33.3333333333333%; left: 11.9791666666667%; display: block;">unlimited elements</p>
                    <p class="teaser turky small fs_obj fs_obj_active" data-position="46.666666666666664,11.979166666666668" data-in="left" data-out="left" data-delay="6500" rel="1" data-fontsize="14px" style="width: 13.0208333333333%; font-size: 8.52444444444445px; line-height: 100%; opacity: 1; top: 46.6666666666667%; left: 11.9791666666667%; display: block;">many transitions</p>
                    <p class="teaser turky small fs_obj fs_obj_active" data-position="60,11.979166666666668" data-in="left" data-out="left" data-delay="8000" rel="1" data-fontsize="14px" style="width: 13.0208333333333%; font-size: 8.52444444444445px; line-height: 100%; opacity: 1; top: 60%; left: 11.9791666666667%; display: block;">unlimited elements</p>
                    <p class="teaser turky small fs_obj fs_obj_active" data-position="33.333333333333336,34.895833333333336" data-in="right" data-out="right" data-delay="5500" rel="1" data-fontsize="14px" style="width: 13.0208333333333%; font-size: 8.52444444444445px; line-height: 100%; opacity: 1; top: 33.3333333333333%; left: 34.8958333333333%; display: block;">unlimited slides</p>
                    <p class="teaser turky small fs_obj fs_obj_active" data-position="46.666666666666664,34.895833333333336" data-in="right" data-out="right" data-delay="6500" rel="1" data-fontsize="14px" style="width: 13.0208333333333%; font-size: 8.52444444444445px; line-height: 100%; opacity: 1; top: 46.6666666666667%; left: 34.8958333333333%; display: block;">background animation</p>
                    <p class="teaser turky small fs_obj fs_obj_active" data-position="60,34.895833333333336" data-in="right" data-out="right" data-delay="8000" rel="1" data-fontsize="14px" style="width: 13.0208333333333%; font-size: 8.52444444444445px; line-height: 100%; opacity: 1; top: 60%; left: 34.8958333333333%; display: block;">unlimited slides</p>
                    <a href="" class="slider-read fs_obj fs_obj_active" data-position="77.77777777777777,11.979166666666668" data-in="bottom" data-out="Right" data-delay="9500" rel="1" data-fontsize="16px" style="font-size: 9.74222222222222px; line-height: 100%; opacity: 1; top: 77.7777777777778%; left: 11.9791666666667%; display: inline;">Download Now</a> </div>
                <div class="slide"> <img src="images/fraction-slider/build.png" data-in="fade" data-out="fade" width="100%" height="100%" rel="2" class="fs_obj" style="width: 100%; height: 100%; font-size: 7.91555555555556px; line-height: 100%;" data-fontsize="13px"> <!--3- slide background-->
                    
                    <p class="claim light-pink fs_obj" data-position="6.666666666666667,13.020833333333334" data-in="top" data-out="top" data-ease-in="easeOutBounce" data-delay="1500" rel="2" data-fontsize="24px" style="font-size: 14.6133333333333px; line-height: 100%;">Easy Responsive Design</p>
                    <p class="claim  theme-colored fs_obj" data-position="24.444444444444443,13.020833333333334" data-in="left" data-out="Right" data-delay="2500" rel="2" data-fontsize="24px" style="font-size: 14.6133333333333px; line-height: 100%;">Easy customization</p>
                    <img src="images/fraction-slider/gadgets/laptop.png" width="23.75%" height="60.44444444444444%" data-position="22.88888888888889,61.458333333333336" data-in="bottom" data-out="bottom" data-delay="400" rel="2" class="fs_obj" style="width: 23.75%; height: 60.4444444444444%; font-size: 7.91555555555556px; line-height: 100%;" data-fontsize="13px"> <img src="images/fraction-slider/gadgets/mack.png" width="18.59375%" height="69.55555555555556%" data-position="13.333333333333334,54.16666666666667" data-in="top" data-out="bottom" data-delay="200" rel="2" class="fs_obj" style="width: 18.59375%; height: 69.5555555555556%; font-size: 7.91555555555556px; line-height: 100%;" data-fontsize="13px"> <img src="images/fraction-slider/gadgets/ipad.png" width="6.25%" height="37.77777777777778%" data-position="51.111111111111114,53.645833333333336" data-in="left" data-delay="300" data-out="left" rel="2" class="fs_obj" style="width: 6.25%; height: 37.7777777777778%; font-size: 7.91555555555556px; line-height: 100%;" data-fontsize="13px"> <img src="images/fraction-slider/gadgets/smartphone.png" width="3.6458333333333335%" height="31.11111111111111%" data-position="60,68.75" data-in="right" data-delay="300" data-out="right" rel="2" class="fs_obj" style="width: 3.64583333333333%; height: 31.1111111111111%; font-size: 7.91555555555556px; line-height: 100%;" data-fontsize="13px">
                    <div class="para-2 fs_obj" data-position="44.44444444444444,13.020833333333334" data-in="left" data-out="right" data-delay="3000" rel="2" data-fontsize="12px" style="font-size: 7.30666666666667px; line-height: 100%;"> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad, aspernatur consequatur consequuntur debitis
                        delectus nostrum quam quod reiciendis sit! </div>
                    <a href="" class="slider-read fs_obj" data-position="80,13.020833333333334" data-in="bottom" data-out="Right" data-delay="3500" rel="2" data-fontsize="16px" style="font-size: 9.74222222222222px; line-height: 100%;">Free Download</a> </div>
                <div class="slide"> <img src="images/fraction-slider/fraction_6.png" data-in="fade" data-out="fade" width="100%" height="NaN%" rel="3" class="fs_obj" style="width: 100%; font-size: 7.91555555555556px; line-height: 100%;" data-fontsize="13px"> <!--4- slide background-->
                    
                    <p class="claim light-pink fs_obj" data-position="11.11111111111111,54.6875" data-in="top" data-out="top" data-ease-in="jswing" rel="3" data-fontsize="24px" style="font-size: 14.6133333333333px; line-height: 100%;">We Design Creative Websites</p>
                    <p class="teaser turky fs_obj" data-position="26.666666666666668,61.458333333333336" data-in="left" data-delay="1500" rel="3" data-fontsize="14px" style="width: 17.9166666666667%; font-size: 8.52444444444445px; line-height: 100%;">animate multiple elements</p>
                    <p class="teaser turky fs_obj" data-position="37.77777777777778,61.458333333333336" data-in="left" data-delay="3000" rel="3" data-fontsize="14px" style="width: 17.9166666666667%; font-size: 8.52444444444445px; line-height: 100%;">full control over each element</p>
                    <p class="teaser turky fs_obj" data-position="48.888888888888886,61.458333333333336" data-in="left" data-delay="4500" data-out="none" rel="3" data-fontsize="14px" style="width: 17.9166666666667%; font-size: 8.52444444444445px; line-height: 100%;">opensource and free</p>
                    <p class="teaser turky fs_obj" data-position="60,61.458333333333336" data-in="left" data-delay="5500" data-out="none" rel="3" data-fontsize="14px" style="width: 17.9166666666667%; font-size: 8.52444444444445px; line-height: 100%;">Download free</p>
                    <img src="images/fraction-slider/slider-girl.png" width="25%" height="106.66666666666667%" data-position="-4.444444444444445,13.020833333333334" data-in="right" data-delay="500" data-out="fade" style="width: 25%; height: 106.666666666667%; font-size: 7.91555555555556px; line-height: 100%;" rel="3" class="fs_obj" data-fontsize="13px"> <a href="" class="slider-read fs_obj" data-position="75.55555555555556,69.27083333333334" data-in="bottom" data-out="top" data-delay="6500" rel="3" data-fontsize="16px" style="font-size: 9.74222222222222px; line-height: 100%;">download Now</a> </div>
                <a href="#" class="prev"></a><a href="#" class="next"></a>
                <div class="fs-stretcher" style="width: 1170px; height: 274.21875px;"></div>
            </div>
        </div>
    </div>
    <?php endif;?>
    
    <!--End Slider--> 
    <?php get_items( 'promo_box' );?>
    <!--start info service-->
    <?php get_items( 'list_services' );?>
    <!--end info service--> 
    
    <!--Start recent work-->
    <?php get_items( 'recents_works' );?>
    <!--Start recent work-->
    
    <section class="fetaure_bottom">
        <div class="container">
            <div class="row sub_content">
                <?php get_items( 'testimonials' );?>
                <div class="col-lg-6 ">
                    <?php get_items( 'feature_list' );?>
                </div>
            </div>
        </div>
    </section>
    <?php if( true == false ) : ?>
    <section class="clients">
        <div class="container">
            <div class="row sub_content">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="dividerHeading">
                        <h4><span>Our Clients</span></h4>
                    </div>
                    <div class="our_clients">
                        <ul class="client_items clearfix">
                            <li class="col-sm-3 col-md-3 col-lg-3"><a href="services.html" data-placement="bottom" data-toggle="tooltip" title="Client 1"><img src="images/clients/1.png" alt=""></a></li>
                            <li class="col-sm-3 col-md-3 col-lg-3"><a href="services.html" data-placement="bottom" data-toggle="tooltip" title="Client 2"><img src="images/clients/2.png" alt=""></a></li>
                            <li class="col-sm-3 col-md-3 col-lg-3"><a href="services.html" data-placement="bottom" data-toggle="tooltip" title="Client 3"><img src="images/clients/3.png" alt=""></a></li>
                            <li class="col-sm-3 col-md-3 col-lg-3"><a href="services.html" data-placement="bottom" data-toggle="tooltip" title="Client 4"><img src="images/clients/4.png" alt=""></a></li>
                        </ul>
                        <!--/ .client_items--> 
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif;?>
</section>