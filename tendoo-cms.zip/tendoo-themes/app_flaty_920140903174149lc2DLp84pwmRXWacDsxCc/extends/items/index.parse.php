<div id="content">

<!-- LayerSlider  -->
<?php $this->parseCaroussel();?>
<!-- LayerSlider / End -->

<!-- 960 Container -->
<?php $this->parseTextList();?>
<!-- 960 Container / End -->


<!-- 960 Container -->
<div class="container floated">
	<?php // echo $this->parseTabShowCase();?>
</div>
<!-- 960 Container / End -->


<!-- 960 Container -->
<div class="container">

	<!-- Recent News -->
	<?php $this->parseLastestElements();?>

	<!-- Testimonials -->

</div>
<?php $this->parseIndexAboutUs();?>
<!-- 960 Container / End -->

</div>