<body>
<?php echo current_user("menu"); ?>
<div id="wrapper"> 
	<?php echo $header;?>
    <div id="content"> 
        <?php echo $module_content;?>        
    </div>
</div>
<?php echo $footer;?>
</body>
</html>