<?php
get_db()->query('DROP TABLE IF EXISTS `'.DB_ROOT.'tendoo_widget_administrator_bottom`');
get_db()->query('DROP TABLE IF EXISTS `'.DB_ROOT.'tendoo_widget_administrator_left`');
get_db()->query('DROP TABLE IF EXISTS `'.DB_ROOT.'tendoo_widget_administrator_right`');