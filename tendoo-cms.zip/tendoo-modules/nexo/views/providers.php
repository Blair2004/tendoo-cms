<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( 'pagination' );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_fournisseurs',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des fournisseurs' )
) )->push_to( 1 );

foreach( $providers as $prov )
{
	$author			=	get_user( riake( 'AUTHOR' , $prov ) , 'as_id' );
	$providers_array[]	=	array( 
		'<a href="' . module_url( array( 'providers' , 'edit' , riake( 'ID' , $prov ) ) ) . '">' . riake( 'NOM' , $prov ) . '</a>' , 
		riake( 'EMAIL' , $prov ) , 
		riake( 'DATE_CREATION' , $prov ) ,
		timespan( riake( 'DATE_MODIFICATION' , $prov ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer ce fournisseur ?' ) . '" href="' . module_url( array( 'providers' , 'delete' , riake( 'ID' , $prov ) ) ) . '"> Supprimer le fournisseur </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'table-panel',
	'cols'			=>	array( __( 'Nom du fournisseur' ) , __( 'Email' ) , __( 'Date de création' ) , __( 'Modifié' ) , __( 'Par' ) , __( 'Supprimer' ) ),
	'rows'			=>  $providers_array
) )->push_to( 'nexo_fournisseurs' );

$this->gui->get();