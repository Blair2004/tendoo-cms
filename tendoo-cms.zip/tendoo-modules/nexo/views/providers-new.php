<?php
$this->gui->cols_width( 1 , 3 );
$this->gui->cols_width( 2 , 1 );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'create' , 'providers' ) ),
	'title'		=>	__( 'Ajouter un fournisseur' ),
	'form_wrap'	=>	array(
		'type'	=>	'post',
		'submit_text'	=>	__( 'Ajouter le fournisseur' ),
		'reset_text'	=>	__( 'Effacer le formulaire' )
	)
) )->push_to( 1 );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'provider_name',
	'placeholder'	=>	__( 'Entrer son nom' ),
	'label'		=>	__( 'Nom' ),
	'value'		=>	$this->input->post( 'provider_name' ),
	'description'	=>	__( 'Assurez-vous que le nom du fournisseur soit unique. Dans le cas contraire, une alerte sera affichée.' )
) )->push_to( meta_namespace( array( 'create' , 'providers' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'provider_bp',
	'placeholder'	=>	__( 'Boite Postale' ),
	'label'		=>	__( 'BP' ),
	'value'		=>	$this->input->post( 'provider_bp' ),
	'description'	=>	__( 'Veuillez spécifier une adresse postale pour le fournisseur.' )
) )->push_to( meta_namespace( array( 'create' , 'providers' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'provider_tel',
	'value'		=>	$this->input->post( 'provider_tel' ),
	'placeholder'	=>	__( 'Numéro de téléphone' ),
	'label'		=>	__( 'Téléphone' ),
	'description'	=>	__( 'Veuillez spécifier un numéro de téléphone pour le fournisseur.' )
) )->push_to( meta_namespace( array( 'create' , 'providers' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'provider_email',
	'value'		=>	$this->input->post( 'provider_email' ),
	'placeholder'	=>	__( 'Email fournisseur' ),
	'label'		=>	__( 'Email' ),
	'description'	=>	__( 'Veuillez spécifier une addresse email pour le fournisseur.' )
) )->push_to( meta_namespace( array( 'create' , 'providers' ) ) );

$this->gui->get();