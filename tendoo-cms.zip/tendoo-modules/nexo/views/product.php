<?php
$this->gui->cols_width( 1 , 4 );

$this->gui->enable( array( 'pagination' , 'dynamic-tables' ) );

$this->gui->set_meta( array(
	'namespace'		=>	'nexo_product_list',
	'type'			=>	'panel-ho',
	'title'			=>	__( 'Liste des produits' ) . ' - <a target="_blank" href="' . module_url( array( 'articles', 'printable' ) )  . '">' . __( 'Version imprimable' ) . '</a>  - <a confirm-do="follow-link" confirm-text="Cette opération est très délicate. Tous les précédents code-barre ne seront plus valides. Confirmez votre action." href="' . module_url( array( 'articles', 'restore_codebar' , get_core_vars( 'current_page' ) ) )  . '">' . __( 'Regénérer les codes-barre' ) . '</a>' 
) )->push_to( 1 );

$products_array		=	array();

foreach( $products as $_product )
{
	$author			=	get_user( riake( 'AUTHOR' , $_product ) , 'as_id' );
	$category		=	farray( $lib->get_category( riake( 'REF_CATEGORIE' , $_product ) , 'as_id' ) );	
	$shipping		=	farray( $lib->get_shipping( riake( 'REF_SHIPPING' , $_product ) , 'as_id' ) );
	
	$products_array[]	=	array( 
		riake( 'NOM' , $category , 'Catégorie Inconnu' ),
		'<a href="' . module_url( array( 'articles' , 'edit' , riake( 'RELATION_ID' , $_product ) ) ) . '">' . riake( 'DESIGN' , $_product ) . '</a>' , 
		$cout_dachat	=	riake( 'PRIX_DACHAT' , $_product , 0 ) + riake( 'FRAIS_ACCESSOIRES' , $_product ) , 
		riake( 'QUANTITY' , $_product ),
		$cout_dachat * riake( 'QUANTITY' , $_product ),
		$cout_dachat * riake( 'TAUX_DE_MARGE' , $_product , 1 ),
		riake( 'TITRE' , $shipping , 'Arrivage Inconnue' ),
		riake( 'DATE_CREATION' , $_product ) ,
		timespan( riake( 'DATE_MODIFICATION' , $_product ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<img src="' . get_instance()->url->main_url() . riake( 'FILE_PATH' , $_product ) . '" alt=" '. riake( 'DESIGN' , $_product )  .' ">',
		riake( 'CODE' , $_product ),
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer ce produits ?<br> Cette opération risque affecter les calculs sur l\'application. Toutes les commandes qui où sont ajoutés ce produit, seront également affectées.' ) . '" href="' . module_url( array( 'articles' , 'delete' , riake( 'ARTICLE_ID' , $_product ) ) ) . '"> Supprimer le produit </a>' , 
	);
}

$this->gui->set_item( array(
	'type'			=>	'dynamic-table',
	'cols'			=>	array( __( 'Entité' ) , __( 'Désignation' ) , __( 'Ca U' ) , __( 'Qte' ) , __( 'Ca Globale' ) , __( 'Pv U' ) ,  __( 'Arrivage' ) , __( 'Date de création' ) , __( 'Modifié' ) , __( 'Par' ) , __( 'Codebar (CODABAR)' ) , __( 'Code' ), __( 'Supprimer' ) ),
	'rows'			=>  $products_array
) )->push_to( 'nexo_product_list' );

$this->gui->get();