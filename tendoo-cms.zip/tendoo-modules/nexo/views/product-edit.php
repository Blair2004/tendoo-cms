<?php
$this->gui->cols_width( 1 , 3 );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'edit' , 'articles' ) ),
	'title'		=>	__( 'Modifier un produit' ),
	'form_wrap'	=>	array(
		'type'	=>	'post'
	)
) )->push_to( 1 );

// Rayon Array
$rayon_array	=	array();
foreach( $rayons as $_rayon )
{
	$rayon_text[]		=	$_rayon[ 'TITRE' ];
	$rayon_value[]		=	$_rayon[ 'ID' ];
}

// Shipping
$shipping_array	=	array();
foreach( $shippings as $_shipping )
{
	$shipping_text[]	=	$_shipping[ 'TITRE' ];
	$shipping_value[]	=	$_shipping[ 'ID' ];
}

// Category
$category_array	=	array();
$category_text	=	array();
$category_value	=	array();
foreach( force_array( $categories )	as $_category )
{
	$category_text[]	=	$_category[ 'NOM' ];
	$category_value[]	=	$_category[ 'ID' ];
}

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'designation_produit',
	'placeholder'	=>	__( 'Désignation article' ),
	'label'		=>	__( 'Désignation de l\'article' ),
	'value'		=>	riake( 'DESIGN' , $product ), // Loaded value
	'description'	=>	__( 'Veuillez ajouter une designation assez clair et précise de l\'article' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'select',
	'name'		=>	'shipping_id',
	'placeholder'	=>	__( 'Choisir un arrivage' ),
	'text'		=>	$shipping_text,
	'value'	=>	$shipping_value,
	'label'		=>	__( 'Définir l\'arrivage' ),
	'active'		=>	riake( 'REF_SHIPPING' , $product ), // loaded Value
	'description'	=>	__( 'Veuillez choisir l\'arrivage à laquelle vous souhaitez assigner l\'article' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
/** 
// PRIX TTC
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'prix_ttc',
	'placeholder'	=>	__( 'Prix TTC' ),
	'label'			=>	__( 'Prix TTC' ),
	'value'			=>	riake( 'PRIX_TTC' , $product ), // default value
	'description'	=>	__( 'Veuiller définir une valeur numérique.' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// Cout Unitaire
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'cu',
	'placeholder'	=>	__( 'Cout Unitaire' ),
	'label'			=>	__( 'Cout Unitaire' ),
	'value'			=>	riake( 'PRIX_UNITAIRE' , $product ), // defaut value
	'description'	=>	__( 'Veuiller définir une valeur numérique.' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
**/

// CATEGORIE ARTICLE ACHETE
$this->gui->set_item( array( 
	'type'		=>	'select',
	'name'		=>	'cat_aa',
	'placeholder'	=>	__( 'Choisir une catégorie' ),
	'text'		=>	$category_text,
	'value'		=>	$category_value,
	'active'	=>	riake( 'REF_CATEGORIE' , $product ),
	'label'		=>	__( 'Choisir une catégorie' ),
	'description'	=>	__( 'Veuillez choisir une catégorie à attribuer à l\'article.' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// Rayonage
$this->gui->set_item( array( 
	'type'		=>	'select',
	'name'		=>	'rayon',
	'placeholder'	=>	__( 'Choisir le rayon de l\'article' ),
	'text'		=>	$rayon_text,
	'value'		=>	$rayon_value,
	'active'	=>	riake( 'REF_RAYON' , $product ),
	'label'		=>	__( 'Rayon' ),
	'description'	=>	__( 'Veuillez choisir un rayon à attribuer à l\'article.' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// Cout Unitaire
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'taille',
	'placeholder'	=>	__( 'Taille' ),
	'label'			=>	__( 'Taille' ),
	'value'			=>	riake( 'TAILLE' , $product ),
	'description'	=>	__( 'Veuillez définir la taille de l\'article' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// Couleur
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'couleur',
	'placeholder'	=>	__( 'Couleur' ),
	'value'			=>	riake( 'COULEUR' , $product ),
	'label'			=>	__( 'Couleur' ),
	'description'	=>	__( 'Veuillez définir la couleur de l\'article' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// Quantité
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'quantity',
	'value'			=>	riake( 'QUANTITY' , $product ),
	'placeholder'	=>	__( 'Quantité' ),
	'label'			=>	__( 'Quantité' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique.' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// Defectueux
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'defectueux',
	'placeholder'	=>	__( 'Quantité défectueuse' ),
	'label'			=>	__( 'Quantité défectueuse' ),
	'value'			=>	riake( 'DEFECTUEUX' , $product ),
	'description'	=>	__( 'Veuillez définir une valeur numérique. La quantité défectueuse ne peux pas être supérieure à la quantité disponible des produits.' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// PRix d'achat
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'prix_dachat',
	'value'			=>	riake( 'PRIX_DACHAT' , $product ),
	'placeholder'	=>	__( 'Prix d\'achat' ),
	'label'			=>	__( 'Prix d\'achat' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique' ),
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// Frais accessoires
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'frais_access',
	'value'			=>	riake( 'FRAIS_ACCESSOIRES' , $product ),
	'placeholder'	=>	__( 'Frais accessoires' ),
	'label'			=>	__( 'Frais accessoires' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique' ),
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );
// Taux de marge
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'taux_marge',
	'value'			=>	riake( 'TAUX_DE_MARGE' , $product ),
	'placeholder'	=>	__( 'Taux de marge' ),
	'label'			=>	__( 'Taux de marge' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique' ),
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'price_whished',
	// 'value'			=>	$this->input->post( 'price_whished' ),
	'placeholder'	=>	__( 'Prix de vente souhaité' ),
	'label'			=>	__( 'Prix de vente souhaité' ),
	'attrs'			=>	array(
		'id'		=>	'price_whished',
	),
	'description'	=>	__( 'Ce champ vous permet de calculer le taux de marge, en fournissant un prix de vente souhaité. Vous n\'aurez plus besoin d\'enregistrer un taux de marge, le calcul sera automatique.' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'prix_de_vente',
	'value'			=>	$this->input->post( 'taux_solde' ),
	'placeholder'	=>	__( 'Prix de vente' ),
	'label'			=>	__( 'Prix de vente' ),
	'attrs'			=>	array(
		'id'		=>	'prix_de_vente',
		'readonly'	=>	'readonly'
	),
	'description'	=>	__( 'Cette valeur est calculée automatiquement' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );	
// 
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'taux_solde',
	'value'			=>	riake( 'TAUX_SOLDE' , $product ),
	'placeholder'	=>	__( 'Taux de solde' ),
	'label'			=>	__( 'Taux de solde' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique comprise entre 0-100' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'dom',
	'value'			=>	module_view( 'views/product-edit-script' , true , 'nexo' )
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );

// 
$this->gui->set_item( array( 
	'type'		=>	'buttons',
	'name'		=>	array( 'edit' ),
	'value'		=>	array( __( 'Modifier le produit' ) ),
) )->push_to( meta_namespace( array( 'edit' , 'articles' ) ) );

$this->gui->get();