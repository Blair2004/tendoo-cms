<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<title>Facture</title>
</head>
<?php
$facture_type	=	'Facture Doit';
$facture_code	=	'';

$client			=	get_user( riake( 'REF_CLIENT' , $command ) , 'as_id' );
$operateur		=	get_user( riake( 'AUTHOR' , $command ) , 'as_id' );
switch( (int) riake( 'TYPE' , $command ) )
{
	case 1 : $type	=	__( 'Facture Doit' ); break;
	case 2 : $type	=	__( 'Facture Avance' ); break;
	case 3 : $type	=	__( 'Facture Devis' ); break;
	default : $type = __( 'Type Inconnu' );
}
$distinct_product	=	$lib->get_distinct_from_command( riake( 'ID' , $command ) );

$format				=	'A5';

$categories_string	=	'';

foreach( force_array( $distinct_product ) as $index => $_product )
{	
	$__product			=	farray( $lib->get_product( $_product[ 'REF_ARTICLE' ] , 'as_id' ) );

	$_product_category	=	farray( $lib->get_category( riake( 'REF_CATEGORIE' , $__product ) , 'as_id' ) );
	if( $index + 1 < count( $distinct_product ) )
	{
		$categories_string  .= 	riake( 'NOM' , $_product_category ) . ', ';
	}
	else
	{
		$categories_string  .= 	riake( 'NOM' , $_product_category ) . ' ';
	}
}

if( $format == 'A5' )
{
	$width	=	792;
	$height	=	560;
	$css	=	'font-size:80% !important;';
}
?>
<body>
    <div class="container" style="width:<?php echo $width;?>px;height:<?php echo $height;?>px;<?php echo $css;?>">
    <div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3><?php echo $type;?> - N°<?php echo riake( 'CODE' , $command );?></h3>
            </div>
            <hr style="margin:0 1%;">
            <div class="row">
                <div class="col-xs-6 col-md-6 col-lg-6 pull-left">
                <?php
				if( riake( 'TYPE' , $command ) == 2 )
				{
					$nbr_days			=	riake( 'expiration_com_aa' , $nexo_settings );
					$str				=	get_instance()->date->datetime(); 
					$days_timestamp		=	( int ) $nbr_days * 86400;
					$paiement_timestamp	=	$days_timestamp + strtotime( $str );
					?>
                    <h4>Date Avance : <?php echo date( 'd-m-Y' , strtotime( riake( 'DATE_CREATION' , $command ) ) );?></h4>
					<h4>Délai Solde : <?php echo date( 'd-m-Y' , $paiement_timestamp );?></h4>
                    <?php
				}
				else
				{
				?>
                    <h4>Date : <?php echo date( 'd-m-Y' , strtotime( riake( 'DATE_CREATION' , $command ) ) );?></h4>
				<?php
				}
				?>
                    <h4>Heure : <?php echo date( 'H:i:s' , strtotime( riake( 'DATE_CREATION' , $command ) ) );?></h4>
                    <h4>Opérateur : <?php echo riake( 'nom_emp' , $operateur , riake( 'PSEUDO' , $operateur ) );?></h4>
                    <h4>Mle Op : <?php echo riake( 'mat_emp' , $operateur , 'Matricule indisponible' );?></h4>
                    <h4>Cat.art acheté : <?php echo $categories_string;?></h4>
                </div>
                <div class="col-xs-6 col-md-6 col-lg-6">
                	<h4>Nom du client : <?php echo riake( 'client_name' , $client , 'Compte Client' );?></h4>
                    <h4>B.P : <?php echo riake( 'client_bp' , $client ) == '' ? __( 'Indisponible' ) : riake( 'client_bp' , $client );?></h4>
                    <h4>Tel : <?php echo riake( 'client_tel' , $client ) == '' ? __( 'Indisponible' ) : riake( 'client_tel' , $client );?></h4>
                    <h4>Mail : <?php echo riake( 'client_email' , $client ) == '' ? __( 'Indisponible' ) : riake( 'client_email' , $client );?></h4>
                    <h4>Mode Reg :  <?php echo $lib->command_payment_type( riake( 'PAYMENT_TYPE' , $command ) );?> </h4>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <td><strong>REFERENCE</strong></td>
                            <td class="text-center"><strong>DESIGNATION</strong></td>
                            <td class="text-center"><strong>P.U</strong></td>
                            <td class="text-center"><strong>QUANTITE</strong></td>
                            <td class="text-right"><strong>MONTANT</strong></td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
					foreach( force_array( $distinct_product ) as $_product )
					{
						$__product	=	farray( $lib->get_product( $_product[ 'REF_ARTICLE' ] , 'as_id' ) );
						$__product_vars	=	farray( $lib->get_product_vars( $_product[ 'REF_ARTICLE' ] , 'as_id' , riake( 'DATE_CREATION' , $command ) ) );
						$nbr_product=	$lib->count_product_from_command( riake( 'ID' , $command ) , $_product[ 'REF_ARTICLE' ] );
						$prix_unitaire	=	( (int) riake( 'PRIX_DACHAT' , $__product_vars ) + (int) riake( 'FRAIS_ACCESSOIRES' , $__product_vars ) ) * ( float ) riake( 'TAUX_DE_MARGE' , $__product_vars );?> <?php riake( 'devise_boutique' , $nexo_settings );
		
					?>
                        <tr>
                            <td><?php echo riake( 'CODE' , $__product );?></td>
                            <td class="text-center"><?php echo riake( 'DESIGN' , $__product );?></td>
                            <td class="text-center"><?php echo $prix_unitaire;?></td>
                            <td class="text-right"><?php echo $nbr_product;?></td>
                            <td class="text-right"><?php echo ( int ) $nbr_product * $prix_unitaire;?></td>
                        </tr>
					<?php
					}
					?>
                        <tr>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;" class="text-right">Montant Brut</td>
                            <td class="text-right"><?php echo $lib->get_command_real_price( riake( 'ID' , $command ) , 'as_id' );?></td>
                        </tr>
                        <tr>
                            <td style="border:none;"><strong>VISA DE LA CAISSE</strong></td>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;" class="text-right">RRR (Express ou fidelité)</td>
                            <td class="text-right"><?php echo riake( 'CHARGE' , $command );?></td>
                        </tr>
                        <tr style="border:none;">
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;" class="text-right">NET A PAYER</td>
                            <td class="text-right"><?php echo $NAP	=	$lib->get_command_price( riake( 'ID' , $command ) );?></td>
                        </tr>                          
                        <tr>
                            <td style="border:none;"><strong>VISA DU CLIENT</strong></td>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;" class="text-right">
							<?php
							if( riake( 'TYPE' , $command ) == 2 )
							{
								echo 'Avance Versée';
							}
							else
							{
								echo 'Montant reçu';
							}
							?>
							 </td>
                            <td class="text-right"><?php echo riake( 'AVANCE' , $command );?></td>
                        </tr>
                        <tr>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;"></td>
                            <td style="border:none;" class="text-right">Reste</td>
                            <td class="text-right"><?php echo abs( $NAP - ( int ) riake( 'AVANCE' , $command ) );?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>
    </div>
</div>
<style type="text/css">
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>
