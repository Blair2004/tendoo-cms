<?php
$this->gui->cols_width( 1 , 3 );

$this->gui->set_meta( array(
	'type'		=>	'panel',
	'namespace'	=>	meta_namespace( array( 'create' , 'articles' ) ),
	'title'		=>	__( 'Ajouter un nouvel article' ),
	'form_wrap'	=>	array(
		'type'	=>	'post'
	)
) )->push_to( 1 );

$category_text	=	$category_value = $rayon_text = $rayon_value = $shipping_text = $shipping_value = array();
// Rayon Array
$rayon_array	=	array();
foreach( $rayons as $_rayon )
{
	$rayon_text[]		=	$_rayon[ 'TITRE' ];
	$rayon_value[]		=	$_rayon[ 'ID' ];
}

// Shipping
$shipping_array	=	array();
foreach( $shippings as $_shipping )
{
	$shipping_text[]	=	$_shipping[ 'TITRE' ];
	$shipping_value[]	=	$_shipping[ 'ID' ];
}

// Category
$category_array	=	array();
foreach( $categories	as $_category )
{
	$category_text[]	=	$_category[ 'NOM' ];
	$category_value[]	=	$_category[ 'ID' ];
}

$this->gui->set_item( array( 
	'type'		=>	'text',
	'name'		=>	'designation_produit',
	'value'		=>	$this->input->post( 'designation_produit' ),
	'placeholder'	=>	__( 'Désignation article' ),
	'label'		=>	__( 'Désignation de l\'article' ),
	'description'	=>	__( 'Veuillez ajouter une designation assez clair et précise de l\'article' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );

$this->gui->set_item( array( 
	'type'		=>	'select',
	'active'	=>	$this->input->post( 'shipping_id' ),
	'name'		=>	'shipping_id',
	'placeholder'	=>	__( 'Choisir un arrivage' ),
	'text'		=>	$shipping_text,
	'value'	=>	$shipping_value,
	'label'		=>	__( 'Définir l\'arrivage' ),
	'description'	=>	__( 'Veuillez choisir l\'arrivage à laquelle vous souhaitez assigner l\'article' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// PRIX TTC
/** 
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'prix_ttc',
	'placeholder'	=>	__( 'Prix TTC' ),
	'label'			=>	__( 'Prix TTC' ),
	'description'	=>	__( 'Veuiller définir une valeur numérique.' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// Cout Unitaire
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'cu',
	'placeholder'	=>	__( 'Cout Unitaire' ),
	'label'			=>	__( 'Cout Unitaire' ),
	'description'	=>	__( 'Veuiller définir une valeur numérique.' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );

**/

// CATEGORIE ARTICLE ACHETE
$this->gui->set_item( array( 
	'type'		=>	'select',
	'name'		=>	'cat_aa',
	'active'	=>	$this->input->post( 'cat_aa' ),
	'placeholder'	=>	__( 'Choisir une catégorie' ),
	'text'		=>	$category_text,
	'value'		=>	$category_value,
	'label'		=>	__( 'Choisir une catégorie' ),
	'description'	=>	__( 'Veuillez choisir une catégorie à attribuer à l\'article.' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// Rayonage
$this->gui->set_item( array( 
	'type'		=>	'select',
	'active'	=>	$this->input->post( 'rayon' ),
	'name'		=>	'rayon',
	'placeholder'	=>	__( 'Choisir le rayon de l\'article' ),
	'text'		=>	$rayon_text,
	'value'		=>	$rayon_value,
	'label'		=>	__( 'Rayon' ),
	'description'	=>	__( 'Veuillez choisir un rayon à attribuer à l\'article.' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// Cout Unitaire
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'taille',
	'value'			=>	$this->input->post( 'taille' ),
	'placeholder'	=>	__( 'Taille' ),
	'label'			=>	__( 'Taille' ),
	'description'	=>	__( 'Veuillez définir la taille de l\'article' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// Couleur
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'couleur',
	'placeholder'	=>	__( 'Couleur' ),
	'label'			=>	__( 'Couleur' ),
	'value'			=>	$this->input->post( 'couleur' ),
	'description'	=>	__( 'Veuillez définir la couleur de l\'article' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// Quantité
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'quantity',
	'placeholder'	=>	__( 'Quantité' ),
	'label'			=>	__( 'Quantité' ),
	'value'			=>	$this->input->post( 'quantity' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique.' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// Défectueux
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'defectueux',
	'placeholder'	=>	__( 'Quantité défectueuse' ),
	'label'			=>	__( 'Quantité défectueuse' ),
	'value'			=>	$this->input->post( 'defectueux' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique. La quantité défectueuse ne peux pas être supérieure à la quantité disponible des produits.' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// PRix d'achat
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'prix_dachat',
	'value'			=>	$this->input->post( 'prix_dachat' ),
	'placeholder'	=>	__( 'Prix d\'achat' ),
	'label'			=>	__( 'Prix d\'achat' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// Frais accessoires
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'frais_access',
	'value'			=>	$this->input->post( 'frais_access' ),
	'placeholder'	=>	__( 'Frais accessoires' ),
	'label'			=>	__( 'Frais accessoires' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// Taux de marge
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'taux_marge',
	'value'			=>	$this->input->post( 'taux_marge' ),
	'placeholder'	=>	__( 'Taux de marge' ),
	'label'			=>	__( 'Taux de marge' ),
	'attrs'			=>	array(
		'id'		=>	'taux_de_marge'
	),
	'description'	=>	__( 'Veuillez définir une valeur numérique' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
// 
$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'price_whished',
	// 'value'			=>	$this->input->post( 'price_whished' ),
	'placeholder'	=>	__( 'Prix de vente souhaité' ),
	'label'			=>	__( 'Prix de vente souhaité' ),
	'attrs'			=>	array(
		'id'		=>	'price_whished',
	),
	'description'	=>	__( 'Ce champ vous permet de calculer le taux de marge, en fournissant un prix de vente souhaité. Vous n\'aurez plus besoin d\'enregistrer un taux de marge, le calcul sera automatique.' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'prix_de_vente',
	'value'			=>	$this->input->post( 'taux_solde' ),
	'placeholder'	=>	__( 'Prix de vente' ),
	'label'			=>	__( 'Prix de vente' ),
	'attrs'			=>	array(
		'id'		=>	'prix_de_vente',
		'readonly'	=>	'readonly'
	),
	'description'	=>	__( 'Cette valeur est calculée automatiquement' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'taux_solde',
	'value'			=>	$this->input->post( 'taux_solde' ),
	'placeholder'	=>	__( 'Taux de solde' ),
	'label'			=>	__( 'Taux de solde' ),
	'description'	=>	__( 'Veuillez définir une valeur numérique comprise entre 0-100' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );

$this->gui->set_item( array( 
	'type'			=>	'dom',
	'value'			=>	module_view( 'views/product-new-script' , true , 'nexo' )
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );
//
$this->gui->set_item( array( 
	'type'		=>	'buttons',
	'name'		=>	array( 'create_new_product' , 'create_and_back' ),
	'value'		=>	array(	__( 'Enregistrer l\'article et recommencer' ) , __( 'Enregistrer tout simplement l\'article' ) ),
) )->push_to( meta_namespace( array( 'create' , 'articles' ) ) );

$this->gui->get();