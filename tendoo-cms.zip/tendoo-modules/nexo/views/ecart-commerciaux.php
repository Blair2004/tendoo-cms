<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<title>Ecarts Commerciaux</title>
</head>
<?php
$format				=	'full';
if( $format == 'A5' )
{
	$width	=	792;
	$height	=	560;
	$css	=	'font-size:80% !important;';
}
if( $format == 'full' )
{
	$width	=	'100%';
	$height	=	560;
	$css	=	'font-size:80% !important;';
}
?>
<body>
    <div class="container" style="width:<?php echo $width;?>px;min-height:<?php echo $height;?>px;<?php echo $css;?>">
    <div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3>ANALYSE DES ECARTS COMMERCIAUX POUR : <?php echo riake( 'TITRE' , $shipping );?></h3>
            </div>
            <hr style="margin:0 1%;">
        </div>
    </div>
    <div class="row">
    	<div class="col-md-12">
        	<h3 style="text-align:center;">Années</h3>
        </div>
        <div class="col-md-12">
        	<?php
			$i__= 1;
			$date_after		=	( $date + 5 );
			$date_before	=	( $date - 5 );
			for( $i = $date_before ; $i <= $date_after ; $i++ )
			{
				$style 		=	'';
				if( $i == $date )
				{
					$style  = 'style="color:red"';
				}
				if( $i__ < 12 )
				{
					?>
                    <div class="col-lg-1" style="text-align:center;"><a  <?php echo $style;?> href="<?php echo module_url( array( 'shipping', 'ecarts-commerciaux' , $page , $i ) );?>"><h3><?php echo $i;?></h3></a></div>
                    <?php
				}
				else if( $i__ == 12 )
				{
					?>
                    <div class="col-lg-1"><a <?php echo $style;?> href="<?php echo module_url( array( 'shipping', 'ecarts-commerciaux' , $page , $i ) );?>"><h3><?php echo $i;?></h3></a></div>
                 </div>
                 <div class="row">
                    <?php
					$i__ = 1;
				}
				$i__++;
			}
			?>
        </div>
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive">
            	<?php 
				$months		=	array( 'Janvier' , 'Février' , 'Mars' , 'Avril' , 'Mai' , 'Juin' , 'Juillet' , 'Aout' , 'Septembre' , 'Octobre' , 'Novembre' , 'Decembre' );
				?>
                <table class="table table-bordered">
                	<thead>
                	<tr>
                    	<td class="text-right"><a <?php echo riake( 'displays' , $_GET ) == 1 ? 'style="color:red"' : '';?> href="<?php echo module_url( array( 'shipping' , 'ecarts-commerciaux' , $shipping_id , $date ) , 'nexo' ) . '?displays=1';?>">Afficher : Janvier, Fevrier, Mars</a>
                        </td>
                    	<td class="text-right">
                        	<a <?php echo riake( 'displays' , $_GET ) == 2 ? 'style="color:red"' : '';?> href="<?php echo module_url( array( 'shipping' , 'ecarts-commerciaux' , $shipping_id , $date ) , 'nexo' ) . '?displays=2';?>">Afficher : Avril, Mai, Juin</a>
                            </td>
                    	<td class="text-right">
                        	<a <?php echo riake( 'displays' , $_GET ) == 3 ? 'style="color:red"' : '';?> href="<?php echo module_url( array( 'shipping' , 'ecarts-commerciaux' , $shipping_id , $date ) , 'nexo' ) . '?displays=3';?>">Afficher : Juillet, Aout, Septembre</a>
                            </td>
                    	<td class="text-right">
                        	<a <?php echo riake( 'displays' , $_GET ) == 4 ? 'style="color:red"' : '';?> href="<?php echo module_url( array( 'shipping' , 'ecarts-commerciaux' , $shipping_id , $date ) , 'nexo' ) . '?displays=4';?>">Afficher : Octobre, Novembre, Decembre</a>
                            </td>
                    </tr>
                    </thead>
                </table>
                <?php
				$__i	=	0;
				$limit	=	2;
				
				$__i2	=	0;
				$limit2	=	2;
				
				if( false == true && $displays	=	riake( 'displays' , $_GET ) )
				{
					if( $displays	== 1 )
					{
						$__i2	=	0;
						$limit2	=	2;
						$__i	=	0;
						$limit	=	2;
					}
					else if( $displays	== 2 )
					{
						$__i2	=	3;
						$limit2	=	6;
						$__i	=	3;
						$limit	=	6;
					}
					else if( $displays	== 3 )
					{
						$__i2	=	6;
						$limit2	=	8;
						$__i	=	6;
						$limit	=	8;
					}
					else if( $displays	== 4 )
					{
						$__i2	=	8;
						$limit2	=	11;
						$__i	=	8;
						$limit	=	11;
					}
				}
				$__start=	( riake( 'displays' , $_GET ) >= 2 ) ? riake( 'displays' , $_GET ) - 1 : 1;
				$total_previsions	=	array( 0 =>	0, 1 => 0 , 2 => 0 );
				$total_realisation	=	array( 0 =>	0, 1 => 0 , 2 => 0 );
				$total_marge		=	array( 0 =>	0, 1 => 0 , 2 => 0 );
				for( $i = 1 ; $i <= 1 ; $i++ )
				{
					?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                        	<td class="text-right"></td>
                            <?php
							for( $iterator_1 = 0 ; $iterator_1 < 3 ; $iterator_1 ++ )
							{
								if( $__i < $limit )
								{
									?>
									<td class="text-center" colspan="3"><strong><?php echo riake( $__i, $months );?></strong></td>
									<?php
									$__i++;
								}
								else if( $__i == $limit )
								{
									?>
									<td class="text-center" colspan="3"><strong><?php echo riake( $__i , $months );?></strong></td>
									<?php
									$__i = $limit + 1;
									$limit	+= 1;
								}
							}
							?>
                        </tr>
                    </thead>
                    <tbody>
                    	<tr>
	                        <td class="text-right">VENTES MENSUELLES</td>
                            <?php
							for( $iterator_1 = 0 ; $iterator_1 < 3 ; $iterator_1++ )
							{
							?>
                            <td class="text-right">PREVISIONS</td>
                            <td class="text-right">REALISATION</td>
                            <td class="text-right">Tx REAL</td>
                            <?php
							}
							?>
                        </tr>
                        <?php
							foreach( force_array( $parent_categories ) as $_parent )
							{
								?>
                                <tr>
	                        	<td class="text-right"><?php echo riake( 'NOM' , $_parent );?></td>
    	                        <?php
								for( $iterator_1 = 0 ; $iterator_1 < 3 ; $iterator_1 ++ )
								{
									$month_id		=	sprintf("%02d", ( $__i2 + 1 ) );
									$the_date		=	$date . '-' . $month_id . '-01 00:00:00';
									$days_in_month	=	cal_days_in_month(CAL_GREGORIAN, $month_id, $date);
									$the_end_date	=	$date . '-' . $month_id . '-' . $days_in_month . ' 00:00:00';
									
									$parent_worth			=	$lib->get_shipping_products_worth( $shipping_id , riake( 'ID' , $_parent ) );
									$solde_before			=	$lib->get_products_price_sold_before_a_date( $shipping_id , riake( 'ID' , $_parent ) , $the_date );
									$sold_now				=	$lib->get_products_price_sold_between_a_date( $shipping_id , riake( 'ID' , $_parent ) , $the_date , $the_end_date );
									$before_insight			=	$parent_worth - $solde_before;
									if( $before_insight != 0 && $sold_now != 0 )
									{
										$taux_real				=	$sold_now / $before_insight;
									}
									else
									{
										$taux_real				=	0;
									}
									$total_previsions[ $iterator_1 ]			+=	$before_insight;
									$total_realisation[ $iterator_1 ]			+=	$sold_now;
									$total_marge[ $iterator_1 ]					+=	$taux_real;
									if( $__i2 < $limit2 )
									{
										?>
										<td class="text-right"><?php echo $lib->money_format( $before_insight , '')?></td>
										<td class="text-right"><?php echo $lib->money_format( $sold_now , '' );?></td>
										<td class="text-right"><?php echo $taux_real * 100;?></td>
										<?php
										$__i2++;
									}
									else if( $__i2 == $limit2 )
									{
										?>
										<td class="text-right"><?php echo $lib->money_format( $before_insight , '' ) ;?></td>
										<td class="text-right"><?php echo $lib->money_format( $sold_now , '' );?></td>
										<td class="text-right"><?php echo $taux_real * 100;?></td>
										<?php
										$__i2 = $limit2 + 1;
										$limit2	+= 1;
									}
								}
								?>
                                </tr>
                                <?php								
								$__i2 		-= 3;
								$limit2		-= 3;
							}
							$__i2			+=	3;
							$limit2			+=	3;
							?>
                        <tr>
	                        <td class="text-right">TOTAL</td>
                            <?php
							for( $iterator_1 = 0 ; $iterator_1 < 3 ; $iterator_1++ )
							{
							?>
                            <td class="text-right"><?php echo $lib->money_format( $total_previsions[ $iterator_1 ] );?></td>
                            <td class="text-right"><?php echo $lib->money_format( $total_realisation[ $iterator_1 ] );?></td>
                            <td class="text-right"><?php echo ( $total_realisation[ $iterator_1 ] / $total_previsions[ $iterator_1 ] ) * 100;?></td>
                            <?php
							 //	 $total_marge[ $iterator_1 ] 
							}
							?>
                        </tr>
                    </tbody>
                </table>
                <?php
				}
				?>
            </div>
        </div>
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>
    </div>
</div>
<style type="text/css">
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>
