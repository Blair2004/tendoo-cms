<?php
$this->gui->cols_width( 1 , 3 );

$this->gui->set_meta( array(
	'type'				=>	'panel',
	'namespace'			=>	meta_namespace( array( 'edit' , 'category-nexo' ) ),
	'title'				=>	__( 'Modifier une catégorie' ),
	'form_wrap'			=>	array(
		'type'			=>	'post',
		'submit_text'	=>	__( 'Modifier la catégorie' )
	)
) )->push_to( 1 );

$this->gui->set_item( array( 
	'type'			=>	'text',
	'name'			=>	'designation_category',
	'placeholder'	=>	__( 'Désignation de la catégorie' ),
	'label'			=>	__( 'Désignation de la catégorie' ),
	'value'			=>	riake( 'NOM' , $current_category ),
	'description'	=>	__( 'Veuillez ajouter une designation assez clair et précise pour la catégorie.' )
) )->push_to( meta_namespace( array( 'edit' , 'category-nexo' ) ) );
// Parent catégorie

$text	=	$value	=	array();
$text[]				=	'Ne pas affecter un parent';
$value[]			=	0;


foreach( force_array( $categories ) as $_category )
{
	$value[]		=	$_category[ 'ID' ];
	$text[]			=	$_category[ 'NOM' ];
}

$this->gui->set_item( array( 
	'type'			=>	'select',
	'active'		=>	riake( 'PARENT_REF_ID' , $current_category ),
	'name'			=>	'identifiant_parent',
	'placeholder'	=>	__( 'Choisir le parent' ),
	'label'			=>	__( 'Choisir un parent' ),
	'text'			=>	$text,
	'value'			=>	$value,
	'description'	=>	__( 'Veuillez choisir une catégorie parente pour cette nouvelle catégorie.' )
) )->push_to( meta_namespace( array( 'edit' , 'category-nexo' ) ) );
// Description
$this->gui->set_item( array( 
	'type'			=>	'textarea',
	'value'			=>	riake( 'DESCRIPTION' , $current_category ),
	'name'			=>	'description_category',
	'placeholder'	=>	__( 'Ajouter une description pour le rayon' ),
	'label'			=>	__( 'Description de la catégorie' ),
	'description'	=>	__( 'La description n\'est pas obligatoire, mais nécessaire.' )
) )->push_to( meta_namespace( array( 'edit' , 'category-nexo' ) ) );

$this->gui->get();