<?php
$TITLE	=	get_page( 'title' );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" href="<?php echo module_assets_url( 'assets/css/bootstrap.css' , 'nexo' );?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Bootstrap, a sleek, intuitive, and powerful mobile first front-end framework for faster and easier web development.">
<meta name="keywords" content="HTML, CSS, JS, JavaScript, framework, bootstrap, front-end, frontend, web development">
<meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
<link rel="stylesheet" href="<?php echo module_assets_url( 'third-library/SimpleCalendar-master/lib/css/SimpleCalendar.css' , 'nexo' );?>" />
<title><?php echo $TITLE;?></title>
</head>
<body>
    <div class="container">
    <div class="row">
    	<div class="col-xs-12" style="border-bottom:solid 4px #AAA;padding-bottom:10px;">
            <div style="display:inline-block;width:33.33%;height:50px;font-stretch:wider">
            	<h2 style="font-size:50px;margin:0;color:#E60000">Ne<span style="color:#333;font-size:55px;">x</span>t</h2>
                <span style="color:#E60000;position:relative;top:-10px;left:63px;">By Olivia</span>
            </div>
            <div style="display:inline-block;width:32%;height:50px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
            	<p>Be unique !</p>
                <p>Be different !</p>
                <p>Be NEXT !</p>
            </div>
            <div style="padding-top:8px;display:inline-block;width:33%;height:80px;font-stretch:wider;font-family:'Comic Sans MS', cursive;font-style:italic;font-weight:600; text-align:center;">
				<img style="height:80px;float:right;maring-left:10px;" src="<?php echo module_assets_url( array( 'assets' , 'ban1.png' ), 'nexo' );?>" alt="ban" />
            </div>
        </div>
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h3><?php echo $TITLE;?></h3>
            </div>
            <hr style="margin:0 1%;">
        </div>
    </div>
    <div class="row">
    	<div class="col-md-12">
        <?php
		$prefs	=	array (
		   'show_next_prev'  => TRUE,
		   'next_prev_url'   => module_url( array( 'reports' , 'monthly' ) , 'nexo' )
		 );
		 $prefs['template'] = '
		
		   {table_open}<table border="0" cellpadding="0" cellspacing="0">{/table_open}
		
		   {heading_row_start}<tr>{/heading_row_start}
		
		   {heading_previous_cell}<th><a href="{previous_url}">&lt;&lt;</a></th>{/heading_previous_cell}
		   {heading_title_cell}<th colspan="{colspan}">{heading}</th>{/heading_title_cell}
		   {heading_next_cell}<th><a href="{next_url}">&gt;&gt;</a></th>{/heading_next_cell}
		
		   {heading_row_end}</tr>{/heading_row_end}
		
		   {week_row_start}<tr>{/week_row_start}
		   {week_day_cell}<td>{week_day}</td>{/week_day_cell}
		   {week_row_end}</tr>{/week_row_end}
		
		   {cal_row_start}<tr>{/cal_row_start}
		   {cal_cell_start}<td>{/cal_cell_start}
		
		   {cal_cell_content}<a href="{content}">{day}</a>{/cal_cell_content}
		   {cal_cell_content_today}<div class="highlight"><a href="{content}">{day}</a></div>{/cal_cell_content_today}
		
		   {cal_cell_no_content}{day}{/cal_cell_no_content}
		   {cal_cell_no_content_today}<div class="highlight">{day}</div>{/cal_cell_no_content_today}
		
		   {cal_cell_blank}&nbsp;{/cal_cell_blank}
		
		   {cal_cell_end}</td>{/cal_cell_end}
		   {cal_row_end}</tr>{/cal_row_end}
		
		   {table_close}</table>{/table_close}
		';
		get_instance()->load->library( 'calendar' , $prefs );
		
		$timestamp	=	strtotime( $YEAR .'-' . $MONTH . '-01' ) ;
		
		$date		=	get_instance()->date->time( '' , true );
		$YEAR		=	( $YEAR  === 'DEFAULT' ) ? riake( 'y' , $date ) : $YEAR;
		$MONTH		=	( $MONTH  === 'DEFAULT' ) ? riake( 'm' , $date ) : $MONTH;
				
		echo get_instance()->calendar->generate( $YEAR , $MONTH );
		
		// var_dump( $commands );
		?>
        </div>
        <div class="col-md-12" style="font-size:12px;">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="bg-warning">
                    	<tr>
                        	<td colspan="19"><?php echo $TITLE;?></td>
                        </tr>
						<tr>
							<td class="text-center">Libelle/Mois</td>
							<td class="text-center">Janvier</td>
							<td class="text-center">Février</td>
							<td class="text-center">Mars</td>
							<td class="text-center">Avril</td>
							<td class="text-center">Mai</td>
							<td class="text-center">Juin</td>
							<td class="text-center">Juillet</td>
							<td class="text-center">Aout</td>
							<td class="text-center">Sept</td>
							<td class="text-center">Oect</td>
							<td class="text-center">Nov</td>
							<td class="text-center">Dec</td>
							<td class="text-center">Total</td>
						</tr>
                        
                    </thead>
                    <tbody>  
						<tr>
							<td class="text-center">Recettes</td>
							<?php
							$total		=	0;
							for( $i = 1 ; $i <= 12 ; $i++ )
							{
								?>
								<td class="text-center"><?php echo $cash = ( int ) $lib->get_cash_for( 0 . $i , $YEAR , 'actif' );?></td>
								<?php
								$total	+=	$cash;
							}
							?>
							<td class="text-center"><?php echo $total;?></td>
						</tr>
						<tr>
							<td colspan="14"></td>
						</td>
						<tr>
							<td class="text-center">Depenses</td>
						</tr>
						<tr>
							<td colspan="14"></td>
						</td>
						<tr>
							<td class="text-center">Cash Flow</td>
						</tr>
						<tr>
							<td colspan="14"></td>
						</td>
						<tr>
							<td class="text-center">Cumul</td>
						</tr>
						
                    </tbody>
                </table>
                
                
            </div>
        </div>
        <div class="col-xs-12" style="font-family:'Comic Sans MS', cursive;border-top:solid 4px #AAA;padding-top:10px;">
        	<p>Situé à la descente Calafatas en direction du Capitole</p>
            <p>N° CTR: P098100508541P	<span style="margin-left:30px;">N° RCCM: RC/YAO/2012/A/138</span></p>
            <p>E-mail : <span style="text-decoration:underline;color:#005EBB">nextbyolivia@yahoo.fr</span>
        </div>
    </div>
</div>
<style type="text/css">
h2
{
	font-size:150%;
}
h3
{
	font-size:140%;
}
h4
{
	font-size:120%;
}
h5
{
	font-size:100%;
}
.headish
{
	background: #ff7f7f; /* Old browsers */
	background: -moz-linear-gradient(top, #ff7f7f 0%, #bf2222 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#ff7f7f), color-stop(100%,#bf2222)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top, #ff7f7f 0%,#bf2222 100%); /* IE10+ */
	background: linear-gradient(to bottom, #ff7f7f 0%,#bf2222 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ff7f7f', endColorstr='#bf2222',GradientType=0 ); /* IE6-9 */
}
@media print {
	BODY {font-size: 8pt !important; line-height: 120%; background: white;}
}
</style>
</body>
</html>

