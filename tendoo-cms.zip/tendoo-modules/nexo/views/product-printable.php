<?php

$products_array		=	array();

?>
<!DOCTYPE>
<html>
<head>
	<title>Version Imprimable des articles</title>
</head>
<body>
<div class="CSSTableGenerator" >
    <table >
        <tr>
            <td>
                Etiquette Article en Rayon
            </td>
        </tr>
<?php
foreach( $products as $_product )
{
	$author			=	get_user( riake( 'AUTHOR' , $_product ) , 'as_id' );
	$category		=	farray( $lib->get_category( riake( 'REF_CATEGORY' , $_product ) ) );	
	$shipping		=	farray( $lib->get_shipping( riake( 'REF_SHIPPING' , $_product ) , 'as_id' ) );
	$products_array[]	=	array( 
		'<a href="' . module_url( array( 'articles' , 'edit' , riake( 'ARTICLE_ID' , $_product ) ) ) . '">' . riake( 'DESIGN' , $_product ) . '</a>' , 
		riake( 'QUANTITY' , $_product ) , 
		riake( 'NOM' , $category , 'Catégorie Inconnu' ),
		riake( 'TITRE' , $shipping , 'Arrivage Inconnue' ),
		riake( 'DATE_CREATION' , $_product ) ,
		timespan( riake( 'DATE_MODIFICATION' , $_product ) ), 
		riake( 'PSEUDO' , $author ) ,
		'<img src="' . get_instance()->url->main_url() . riake( 'FILE_PATH' , $_product ) . '" alt=" '. riake( 'DESIGN' , $_product )  .' ">',
		'<a confirm-do="follow-link" confirm-text=" ' . __( 'Souhaitez vous supprimer ce produits ?<br> Cette opération risque affecter les calculs sur l\'application. Toutes les commandes qui où sont ajoutés ce produit, seront également affectées.' ) . '" href="' . module_url( array( 'articles' , 'delete' , riake( 'ARTICLE_ID' , $_product ) ) ) . '"> Supprimer le produit </a>' , 
	);
	$cout_dachat	=	riake( 'PRIX_DACHAT' , $_product , 0 ) + riake( 'FRAIS_ACCESSOIRES' , $_product );
	$prix_de_vente	=	$cout_dachat * riake( 'TAUX_DE_MARGE' , $_product , 1 );
	?>
    <tr>
        <td>
        	<div style="width:70%;display:inline-block;">
                <h3>N° Col : <?php echo riake( 'TITRE' , $shipping , 'Arrivage Inconnue' );?></h3>
                <h3>Désignation : <?php echo riake( 'DESIGN' , $_product );?></h3>
                <h3>Prix : <?php echo $prix_de_vente;?></h3>
            </div>
			<div style="width:20%;display:inline-block;">
            	<img style="width:100%" src="<?php echo get_instance()->url->main_url() . riake( 'FILE_PATH' , $_product );?>" alt="<?php echo riake( 'DESIGN' , $_product );?>">
            </div>
        </td>
    </tr>
    <?php
}
?>             
                </table>
            </div>
            <style>
.CSSTableGenerator {
	margin:0px;padding:0px;
	width:100%;
	box-shadow: 10px 10px 5px #888888;
	border:1px solid #000000;
	
	-moz-border-radius-bottomleft:0px;
	-webkit-border-bottom-left-radius:0px;
	border-bottom-left-radius:0px;
	
	-moz-border-radius-bottomright:0px;
	-webkit-border-bottom-right-radius:0px;
	border-bottom-right-radius:0px;
	
	-moz-border-radius-topright:0px;
	-webkit-border-top-right-radius:0px;
	border-top-right-radius:0px;
	
	-moz-border-radius-topleft:0px;
	-webkit-border-top-left-radius:0px;
	border-top-left-radius:0px;
}.CSSTableGenerator table{
    border-collapse: collapse;
        border-spacing: 0;
	width:100%;
	height:100%;
	margin:0px;padding:0px;
}.CSSTableGenerator tr:last-child td:last-child {
	-moz-border-radius-bottomright:0px;
	-webkit-border-bottom-right-radius:0px;
	border-bottom-right-radius:0px;
}
.CSSTableGenerator table tr:first-child td:first-child {
	-moz-border-radius-topleft:0px;
	-webkit-border-top-left-radius:0px;
	border-top-left-radius:0px;
}
.CSSTableGenerator table tr:first-child td:last-child {
	-moz-border-radius-topright:0px;
	-webkit-border-top-right-radius:0px;
	border-top-right-radius:0px;
}.CSSTableGenerator tr:last-child td:first-child{
	-moz-border-radius-bottomleft:0px;
	-webkit-border-bottom-left-radius:0px;
	border-bottom-left-radius:0px;
}.CSSTableGenerator tr:hover td{
	
}
.CSSTableGenerator tr:nth-child(odd){ background-color:#ffffff; }
.CSSTableGenerator tr:nth-child(even)    { background-color:#fcfcfc; }.CSSTableGenerator td{
	vertical-align:middle;
	
	
	border:1px solid #000000;
	border-width:0px 1px 1px 0px;
	text-align:left;
	padding:14px;
	font-size:10px;
	font-family:Arial;
	font-weight:normal;
	color:#000000;
}.CSSTableGenerator tr:last-child td{
	border-width:0px 1px 0px 0px;
}.CSSTableGenerator tr td:last-child{
	border-width:0px 0px 1px 0px;
}.CSSTableGenerator tr:last-child td:last-child{
	border-width:0px 0px 0px 0px;
}
.CSSTableGenerator tr:first-child td{
		background:-o-linear-gradient(bottom, #e8e8e8 5%, #b7b7b7 100%);	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #e8e8e8), color-stop(1, #b7b7b7) );
	background:-moz-linear-gradient( center top, #e8e8e8 5%, #b7b7b7 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#e8e8e8", endColorstr="#b7b7b7");	background: -o-linear-gradient(top,#e8e8e8,b7b7b7);

	background-color:#e8e8e8;
	border:0px solid #000000;
	text-align:center;
	border-width:0px 0px 1px 1px;
	font-size:14px;
	font-family:Arial;
	font-weight:bold;
	color:#000000;
}
.CSSTableGenerator tr:first-child:hover td{
	background:-o-linear-gradient(bottom, #e8e8e8 5%, #b7b7b7 100%);	background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #e8e8e8), color-stop(1, #b7b7b7) );
	background:-moz-linear-gradient( center top, #e8e8e8 5%, #b7b7b7 100% );
	filter:progid:DXImageTransform.Microsoft.gradient(startColorstr="#e8e8e8", endColorstr="#b7b7b7");	background: -o-linear-gradient(top,#e8e8e8,b7b7b7);

	background-color:#e8e8e8;
}
.CSSTableGenerator tr:first-child td:first-child{
	border-width:0px 0px 1px 0px;
}
.CSSTableGenerator tr:first-child td:last-child{
	border-width:0px 0px 1px 1px;
}
</style>
<?php echo bs_pagination( $pagination_data );?> <a href="<?php echo module_url( array( 'articles' ) );?>">Revenir a la version normale</a>
</body>
</html>