<?php
$MENU_CONFIG		=	array();
$MENU_CONFIG['showcategory']	=	array(
	'MENU_NAME'		=>	'Blogster - Afficher les cat&eacute;gories',	// nom du widget
	'MENU_NAMESPACE'			=>	'showcategory', // Espace nom du widget, il doit être unique.
	'MENU_CLASS_FILE'		=>	'/api/showcategory.php',	//  Chemin d'acces au fichier
	'MENU_MODULE_NAMESPACE'	=>	'news'	// Espace nom du module sur lequel le widge test attaché.
);
