<?php
		if($delete === true)
		{
		?>
{"requestStatus" : true}<?php
		}
		else
		{
		?>
{"requestStatus" : false}<?php
		}
	