<?php
	/*$theme->defineBlogPost(
		'Uno',
		'Doss',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'Auteur',
		'#',
		10202093,
		'cat',
		'#'
	);
	$theme->defineBlogPost(
		'Uno',
		'Doss',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'Auteur',
		'#',
		10202093,
		'cat',
		'#'
	);
	$theme->defineBlogPost(
		'Uno',
		'Doss',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'Auteur',
		'#',
		10202093,
		'cat',
		'#'
	);
	$theme->defineBlogPost(
		'Uno',
		'Doss',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'Auteur',
		'#',
		10202093,
		'cat',
		'#'
	);
	$theme->defineBlogPost(
		'Uno',
		'Doss',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'Auteur',
		'#',
		10202093,
		'cat',
		'#'
	);
	
	$theme->parseBlog();*/
	/*$data['firstLink']	=	'#';
	$data['firstLinkText'] = 'Premier lien';
	$data['LinkText']		=	'Current';
	$data['lastLinkText']	=	'Last';
	$data['totalPage']		=	10;
	$data['activeLink']		=	'#';
	$data['activeLinkText']	=	'Active link';
	$data['innerLink']		=	array(
		array(
			'state'	=>	'active',
			'text'	=>	'active',
			'link'	=>	'#'
		),
		array(
			'state'	=>	'none',
			'text'	=>	'Pas active',
			'link'	=>	'#'
		),
		array(
			'state'	=>	'none',
			'text'	=>	'Pas active',
			'link'	=>	'#'
		),
		array(
			'state'	=>	'none',
			'text'	=>	'Pas active',
			'link'	=>	'#'
		),
		array(
			'state'	=>	'none',
			'text'	=>	'Pas active',
			'link'	=>	'#'
		),
		array(
			'state'	=>	'none',
			'text'	=>	'Pas active',
			'link'	=>	'#'
		)
	);
	$theme->set_pagination_datas($data);*/
	
	/*$theme->defineGalleryShowCaseTitle('THe WHocase');
	$theme->defineGalleryShowCase(
		'Titre du produit',
		'Description du produit',
		'http://localhost/autoSlide/img/photos/1.jpg',
		'http://localhost/autoSlide/img/photos/1.jpg',
		'#',
		null
	);
	$theme->defineGalleryShowCase(
		'Titre du produit',
		'Description du produit',
		'http://localhost/autoSlide/img/photos/3.jpg',
		'http://localhost/autoSlide/img/photos/3.jpg',
		'#',
		null
	);
	$theme->defineGalleryShowCase(
		'Titre du produit',
		'Description du produit',
		'http://localhost/autoSlide/img/photos/1.jpg',
		'http://localhost/autoSlide/img/photos/1.jpg',
		'#',
		null
	);
	$theme->defineGalleryShowCase(
		'Titre du produit',
		'Description du produit',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'http://localhost/autoSlide/img/photos/2.jpg',
		'#',
		null
	);
	
	$theme->defineIndexAboutUs('mon contenu un nouveau contenu, un autre contenu');
	$theme->defineIndexAboutUsTitle('A propos de nous');
	
	$theme->defineTextList('un titre','un contenu aun aoie eoae e dla eoaie doei ','http://localhost/autoSlide/img/photos/2.jpg','#',null);
	$theme->defineTextList('un titre','un contenu aun aoie eoae e dla eoaie doei ','http://localhost/autoSlide/img/photos/2.jpg','#',null);
	$theme->defineTextList('un titre','un contenu aun aoie eoae e dla eoaie doei ','http://localhost/autoSlide/img/photos/2.jpg','#',null);
	$theme->defineTextList('un titre','un contenu aun aoie eoae e dla eoaie doei ','http://localhost/autoSlide/img/photos/2.jpg','#',null);
	$theme->defineTextList('un titre','un contenu aun aoie eoae e dla eoaie doei ','http://localhost/autoSlide/img/photos/2.jpg','#',null);
	$theme->defineTextList('un titre','un contenu aun aoie eoae e dla eoaie doei ','http://localhost/autoSlide/img/photos/2.jpg','#',null);
	$theme->defineTextList('un titre','un contenu aun aoie eoae e dla eoaie doei ','http://localhost/autoSlide/img/photos/2.jpg','#',null);
	$theme->defineTextList('un titre','un contenu aun aoie eoae e dla eoaie doei ','http://localhost/autoSlide/img/photos/2.jpg','#',null);
	
	
	$theme->defineOnTopContent('http://localhost/autoSlide/img/photos/2.jpg','Un titre','Un contenu','#',null); // Ok
	$theme->defineOnTopContent('http://localhost/autoSlide/img/photos/2.jpg','Un titre','Un contenu','#',null); // Ok
	$theme->defineOnTopContent('http://localhost/autoSlide/img/photos/2.jpg','Un titre','Un contenu','#',null); // Ok
	$theme->defineOnTopContent('http://localhost/autoSlide/img/photos/2.jpg','Un titre','Un contenu','#',null); // Ok
	$theme->defineOnTopContent('http://localhost/autoSlide/img/photos/2.jpg','Un titre','Un contenu','#',null); // Ok
	$theme->defineOnTopContent('http://localhost/autoSlide/img/photos/2.jpg','Un titre','Un contenu','#',null); // Ok
	
	$theme->defineTabShowCaseTitle('This is a tab Show case');
	$theme->defineTabShowCase('Une superbe soirée','un noude a oe keoe oa eoe idoeo aodpe eid o');
	$theme->defineTabShowCase('Une superbe soirée','un noude a oe keoe oa eoe idoeo aodpe eid o');
	$theme->defineTabShowCase('Une superbe soirée','un noude a oe keoe oa eoe idoeo aodpe eid o');
	$theme->defineTabShowCase('Une superbe soirée','un noude a oe keoe oa eoe idoeo aodpe eid o');
	
	
		$theme->definePageTitle('Une nouvelle page c\'est cool non ?');
		$theme->defineFeaturedProductTitle('Un titre');
		$theme->defineFeaturedProducts('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#');
		$theme->defineFeaturedProducts('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#');
		$theme->defineFeaturedProducts('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#');
		$theme->defineFeaturedProducts('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#');
		$theme->defineFeaturedProducts('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#');
		$theme->defineFeaturedProducts('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#');
		$theme->defineFeaturedProducts('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#');

	$theme->defineProductListingCaroussel('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#','10000');
	$theme->defineProductListingCaroussel('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#','10000');
	$theme->defineProductListingCaroussel('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#','10000');
	$theme->defineProductListingCaroussel('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#','10000');
	$theme->defineProductListingCaroussel('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#','10000');
	$theme->defineProductListingCaroussel('TItre','Contenu','http://localhost/autoSlide/img/photos/1.jpg','200','#','10000');*/
	
	/*$theme->parseIndex();*/
		/*$theme->defineContactAddress('Notre contact', 'utilisez ces num&eacute;ros pour nous contacter');
		$theme->defineContactContent('besoin d\'aide ? contactez nous');
		$theme->defineContactAddressItem('phone','3992039394');
		$theme->defineContactAddressItem('phone','2304958576');
		$theme->defineContactAddressItem('email','fakecontact@fakebox.com');
		$theme->defineContactFormHeader();
		$theme->parseContact();*/
		
		
				
		/*$theme->defineCartListPanelButton('Un bouton','#');
		$theme->defineCartListPanelButton('Un bouton','#');
		$theme->defineCartListPanelButton('Un bouton','#');
		$theme->defineCartListPanelButton('Un bouton','#');
		$theme->defineCartListDatas('Réduction promotionnel',10000,'Frais de transport','30000','Prix des produits',100000,'Cout Total',200000);
		for($i = 0;$i < 10;$i++)
		{
			$theme->defineCartListElement('Un produit','Une description lorem ipso doloe a  eoie eaeo eua eu aeu oeaia d oqinc ei rlap e dcu e ehaue ahsg eor ;dp xmqp epaoei ruty x,e hdiq e ','http://localhost/autoSlide/img/photos/1.jpg','300','',$cancel_link = '#',$cancel_text = 'retirer',$add_link = '#',$add_text = 'Ajouter',$price_total_per_item = '',$item_code= "",$item_quantity = 0);
		}
		$theme->parseListing();*/
		
		/*$theme->defineIndexAboutUs('Ce que nous sommes et ce que nous faisons');
		$titres		=	array('Poison Rouge delux','Poison Orange argentée', 'Poison bleu des princes','Meduse Sacré', 'Plume d\'or+ Elixir de vie');
		for($i = 1;$i < 5;$i++)
		{
			$theme->defineTextList($titres[rand(0,4)],'Lorem ipso dolor content is very suitable','http://localhost/autoSlide/img/photos/'.$i.'.jpg','#',null);		
			$theme->defineProductListingCaroussel($titres[rand(0,4)],'Et sa descriptoin','http://localhost/autoSlide/img/photos/'.$i.'.jpg','1039394','#',1000+rand(500,800));
		}
		$theme->parseIndex()*/;
		/*$theme->defineProductView(
			'titre du produit',
			'contenu du produit',
			'http://localhost/autoSlide/img/photos/2.jpg',
			'http://localhost/autoSlide/img/photos/2.jpg',
			'1',
			null,
			'#',
			'Un lien',
			'Une categorie',
			'#',
			'10000',$add_button_text = 'Ajouter au panier',$add_button_link = '#',$remove_button_text= "Retirer du panier", $remove_button_link = '#',$login_button_text = 'Connectez-vous',$login_button_link	=	'#'
		);
		$theme->defineProductView(
			'titre du produit',
			'contenu du produit',
			'http://localhost/autoSlide/img/photos/2.jpg',
			'http://localhost/autoSlide/img/photos/2.jpg',
			'1',
			null,
			'#',
			'Un lien',
			'Une categorie',
			'#',
			'10000',$add_button_text = 'Ajouter au panier',$add_button_link = '#',$remove_button_text= "Retirer du panier", $remove_button_link = '#',$login_button_text = 'Connectez-vous',$login_button_link	=	'#'
		);
		$theme->parseListing();*/
		/*$theme->defineSingleProductView('Wo Whoo','Whoo content','http://localhost/autoSlide/img/photos/2.jpg','http://localhost/autoSlide/img/photos/2.jpg','Auteur',12233455923,'Category','#category',10250,$other_preview = array(
			array(
				'THUMB'	=>	'http://localhost/autoSlide/img/photos/2.jpg',
				'FULL'	=>	'http://localhost/autoSlide/img/photos/2.jpg'
			),
			array(
				'THUMB'	=>	'http://localhost/autoSlide/img/photos/3.jpg',
				'FULL'	=>	'http://localhost/autoSlide/img/photos/3.jpg'
			),
			array(
				'THUMB'	=>	'http://localhost/autoSlide/img/photos/1.jpg',
				'FULL'	=>	'http://localhost/autoSlide/img/photos/1.jpg'
			)
		),$add_button_text = 'Ajouter au panier',$add_button_link = '#',$remove_button_text = 'Retirer du panier', $remove_button_link = '#',$check_button_text	=	'Consulter mon panier',$check_button_link	=	'#',$login_button_text = 'Connectez-vous', $login_button_link = '#');*/
		//$theme->parseListing();
		/*$theme->defineUnique('Admin Post author March 29, 2013 at 1:17 pm | Reply↓ | Edit
Donec sed odio dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed odio dui. Cras mattis consectetur purus sit amet fermentum. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum.
LEAVE A REPLY
Your email address will not be published. Required fields are marked *
 




You may use these HTML tags and attributes:


THANK YOU FOR COMMENT

SIMILAR PRODUCTS

     
');
		$theme->parseUnique();*/
		$theme->defineContactAddress('Nos adresses','HA ha ha');
		$theme->defineContactContent('Donec sed odio dui. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sed odio dui. Cras mattis consectetur purus sit amet fermentum. Aenean eu leo quam. Pellentesque ornare sem lacinia quam venenatis vestibulum.');
		$theme->defineContactAddressItem('email','edyteaet]yahzid');
		$theme->defineContactAddressItem('adress','azdazdaz');
		$theme->defineContactAddressItem('mobile','343220334');
		$theme->defineForm(array(
			'type'	=>	'input',
			'name'	=>	'bonjour',
			'placeholder'	=>	'hahah'
		));
		$theme->defineForm(array(
			'type'	=>	'input',
			'name'	=>	'bonjour',
			'placeholder'	=>	'hahah',
			'text'	=>	'votre email'
		));
		$theme->defineForm(array(
			'type'	=>	'textarea',
			'name'	=>	'bonjour',
			'placeholder'	=>	'hahah'
		));
		$theme->defineForm(array(
			'type'	=>	'input',
			'subtype'	=>	'submit',
			'value'	=>	'Envoyer',
			'placeholder'	=>	'hahah'
		));
		$theme->defineContactFormHeader($action="",$enctype="multipart/form-data",$method="POST");
		$theme->parseContact();