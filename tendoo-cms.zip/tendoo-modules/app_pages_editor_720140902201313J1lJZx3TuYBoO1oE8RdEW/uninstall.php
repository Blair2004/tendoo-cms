<?php
get_db()->query('DROP TABLE IF EXISTS `'.DB_ROOT.'tendoo_pages`');