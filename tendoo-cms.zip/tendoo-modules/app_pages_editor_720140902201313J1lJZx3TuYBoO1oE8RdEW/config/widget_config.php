<?php
$WIDGET_CONFIG		=	array();
$WIDGET_CONFIG['hierarchy']	=	array(
	'WIDGET_NAME'		=>	'Afficher la hiérarchie des pages',	// nom du widget
	'WIDGET_NAMESPACE'		=>	'hierarchy', // Espace nom du widget, il doit être unique.
	'WIDGET_FILES'			=>	'/widgets/show_page_hierarchy.php',	//  Chemin d'acces au fichier
	'MODULE_NAMESPACE'		=>	'pages_editor',
	'WIDGET_MORE'			=>	'/more/show_page_hierarchy_config.php'
);