<?php
/*
	vars
		$modules : all about module
*/
$ICON_CONFIG		=	array(
	'ICON_NAME'		=>	'Librarie Multimedia',	// nom du widget
	'ICON_NAMESPACE'		=>	'main_icon', // Espace nom du widget, il doit être unique.
	'ICON'					=>	'/app_icon.jpg',
	'ICON_MODULE_NAMESPACE'	=>	$modules['namespace'],	// Espace nom du module de l'icône.
	'ICON_MODULE'			=>	$modules
);