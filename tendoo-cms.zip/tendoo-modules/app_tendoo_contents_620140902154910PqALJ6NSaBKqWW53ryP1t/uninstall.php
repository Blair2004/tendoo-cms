<?php
get_db()->query('DROP TABLE IF EXISTS `tendoo_contents`');