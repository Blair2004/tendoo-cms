<body lang="en" class="page page-id-112 page-template page-template-portfolio-page-php group-blog">
	<div id="page" class="hfeed site">
		<?php echo $head;?>
		<!-- MAIN -->
		<?php echo $module_content;?>
		<!-- ENDS MAIN -->
		<?php echo $footer;?>
	</div>
</body>