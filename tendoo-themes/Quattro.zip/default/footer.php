<div id="bottom">
	<div class="container">
		<div class="row">
			<?php $theme->parseBottomWidgets();?>
		</div>
	</div>
</div>
<footer role="contentinfo" class="site-footer" id="colophon">
	<div class="container">
		<div class="site-info wrap row">
			<div class="fcred col-12">
				Copyright &copy; 2014 <a title="revera" href="http://demo.fabthemes.com/revera">Revera</a> - Th&egrave;me Tendoo.<br>
				 | <a href="http://topwpthemes.com/Revera/">Revera Theme</a> <br>| <a href="https://github.com/Blair2004/tendoo-cms"><?php echo $this->core->tendoo->getVersion();?></a>
			</div>		

		</div><!-- .site-info -->
	</div>	
</footer>
