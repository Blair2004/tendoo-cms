<!-- social -->
<?php $this->socialBar();?>
<!-- ENDS social -->
<!-- Content -->
<!-- slider -->
<?php $this->parseCaroussel();?>
<?php $this->parseProductListingCaroussel();?>
<!-- ENDS slider -->
<?php $this->parseIndexAboutUs();?>
<div id="content" class="site-content ">
	<div class="container">
<?php $this->parseOnTopContent();?>
<?php $this->parseFeaturedProducts();?>
<?php $this->parseLastestElements();?>
<?php $this->parseGalleryShowCase();?>
	</div>
</div>
<?php $this->parseTabShowCase();?>
<!-- text-posts -->
<?php $this->parseTextList();?>

<?php $this->parsePartners();?>
<!-- ENDS featured -->
<!-- Features Products -->
<!-- ENDS Features Products -->
<!-- ENDS text-posts -->
<!-- home-gallery -->
<!-- Headline -->
<!-- ENDS Headline -->
<!-- ENDS home-gallery -->
