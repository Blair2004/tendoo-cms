<li class="dropdown-submenu"> <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
	<i class="icon-desktop"></i> <span>Modus Menu</span> </a> 
    <ul class="dropdown-menu">
        <li> <a href="<?php echo $this->core->url->site_url('admin/themes/config/'.$Spetheme['ID'].'/index');?>">Param&egrave;tres</a> </li>
        <li> <a href="<?php echo $this->core->url->site_url('admin/themes/config/'.$Spetheme['ID'].'/about');?>">A propos de MODUS</a> </li>
    </ul>
</li>