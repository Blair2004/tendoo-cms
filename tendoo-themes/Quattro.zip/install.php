﻿<?php
$this->installSession();
$this->appType('THEME');
$this->appVers(0.1);
$this->appTendooVers(0.96);
$this->appTableField(array(
	'NAMESPACE'		=> 'Tendoo_quattro',
	'HUMAN_NAME'	=> 'Tendoo - Quattro',
	'AUTHOR'		=> 'Blair Jersyer',
	'DESCRIPTION'	=> 'Un autre thème développé pour les hébergeurs.',
	'TENDOO_VERS'	=> 0.96
));