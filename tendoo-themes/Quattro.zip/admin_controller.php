<?php
class Tendoo_quattro_theme_admin_controller
{
	public function __construct($data)
	{
		__extends($this);
	}
	public function index()
	{
		
	}
}