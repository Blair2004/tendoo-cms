<?php 
declare_theme( 'flaty' , array(
	'human_name' 	=>		'Flaty',
	'author'		=>		'Blair Jersyer',
	'description'	=>		"Flaty est un th&egrave;me conçu avec le framework Twitter Bootstrap, il est flexible et responsible. C'est le premier th&egrave;me r&eacute;alis&eacute; dans le respect des normes LUMINAX.",
	'version'		=>		0.1,
	'compatible'	=>		1.3
) );