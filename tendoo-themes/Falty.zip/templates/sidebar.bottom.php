<section id="bottom" class="wet-asphalt">
    <div class="container">
        <div class="row">
        	<?php get_widgets( 'bottom' );?>
        </div>
    </div>
</section>