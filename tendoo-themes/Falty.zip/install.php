<?php $this->installSession();
$this->appType('THEME');
$this->appVers(0.1);
$this->appTendooVers(1.2);
$this->appTableField(array(
	'NAMESPACE'				=> "flaty",
	'HUMAN_NAME'			=> "Flaty",
	'AUTHOR'				=> "Blair Jersyer",
	'DESCRIPTION'			=> "Flaty est un th&egrave;me conçu avec le framework Twitter Bootstrap, il est flexible et responsible. C'est le premier th&egrave;me r&eacute;alis&eacute; dans le respect des normes LUMINAX.",
	'TENDOO_VERS'			=> 1.2,
	'HAS_PASSIVE_SCRIPTING'	=>	1
));